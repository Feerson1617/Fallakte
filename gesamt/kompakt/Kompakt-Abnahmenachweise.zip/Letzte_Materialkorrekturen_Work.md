# Letzte Materialkorrekturen für Work

Softwarestand `b166bce`. Die Seitenzahlen beziehen sich auf die gelieferten kompakten Druckfassungen. Gleichlautende Felder beider Niveaus sind zusammen aufgeführt.

## 02.12. · Celina auf MSA und AHR

**02_Freiwillig/Celina_MSA.pdf und 02_Freiwillig/Celina_AHR.pdf, Seiten 1 und 2, jeweils die Arbeitsanweisung über dem ersten Abschnitt.**

Bisher: „Beantworte die Frage und kreise A, B oder C ein. Gib den Buchstaben ein → „Code prüfen“ → „Nachricht senden“.“

Neu: „Lies die Frage auf diesem Bogen. Lies A, B und C zu deiner Wahl am iPad. Schreibe deine Begründung auf diesen Bogen. Kreise hier den Buchstaben der passenden Aussage ein. Gib den Buchstaben am iPad ein. Tippe auf „Code prüfen“. Ist der Code richtig, tippe auf „Nachricht senden“.“

**Dieselben PDFs, Seiten 1 und 2, Antwortfelder.** Die Fachfrage jedes Abschnitts und die vorhandenen Schreibzeilen bleiben stehen. Ersetze in jeder Tabellenzeile die drei bisher fest gedruckten Aussagen durch dasselbe neutrale Feld: „Meine Begründung:“ [Schreibzeilen] und darunter „Meine Wahl:   A     B     C“. Kein Buchstabe ist markiert.

| Seite | Feld | Bisher gedruckte Aussagen A / B / C |
|---|---|---|
| 1 | Celina 1 – Ohne zusätzliche Hormone | A Auch das Kondom enthält Hormone. / B Kondome wirken als Barriere ohne zusätzliche Hormone. / C Hormonfreie Methoden können keine Schwangerschaft verhindern. |
| 1 | Celina 2 – Schutz über längere Zeit | A Bei jedem Sex ist ein neues Kondom nötig. Die Anwendung lässt sich später beenden. / B Ein Kondom kann mehrere Tage verwendet werden. / C Langfristiger Schutz bedeutet endgültige Unfruchtbarkeit. |
| 1 | Celina 3 – Sorge vor dem Einsetzen | A Auch ein Kondom muss ärztlich eingesetzt werden. / B Dein Rat ersetzt Celinas eigene Entscheidung. / C Das Kondom wird beim Sex benutzt. Dafür ist keine Einlage nötig. |
| 2 | Celina 4 – Schutz in der Beziehung | A Ein Kondom verhindert jede STI. / B Das Kondom senkt bei richtiger Anwendung das Risiko vieler STI. Ein Restrisiko bleibt. / C Schwangerschaftsschutz schützt immer auch vor Infektionen. |
| 2 | Celina 5 – Dein Rat an Celina | A Bei richtiger Anwendung bietet das Kondom vollständigen Schutz. / B Die zuverlässigste Methode passt unabhängig von Celinas Grenzen. / C Ein neues Kondom bei jedem Sex passt zu beiden Schutzzielen. Die richtige Anwendung bleibt entscheidend. |

**03_Ausfall/Freiwillige_Faelle_ohne_iPad_MSA.pdf und 03_Ausfall/Freiwillige_Faelle_ohne_iPad_AHR.pdf, Seite 1, jeweils der letzte Satz unter Celina 1 bis Celina 5.**

Bisher in jedem Abschnitt: „Bearbeite die Frage auf deinem Zusatzbogen. Zur Kontrolle hilft die Lehrkraft.“

Neu in jedem Abschnitt: „Nenne deinen Vorschlag. Suche auf dem Ersatzblatt deinen Abschnitt und deinen Vorschlag. Lies die drei Aussagen. Schreibe deine Begründung auf den Celina-Bogen. Kreise dort A, B oder C ein. Bitte die Lehrkraft, deine Wahl zu prüfen.“

Setze für beide Niveaus dasselbe Ersatzblatt aus **Celina_Ausfall_Aussagen.tsv**. Jede Zeile enthält eine eigene Überschrift aus Abschnitt und Vorschlag sowie die drei unveränderten Aussagen in Bildschirmreihenfolge. Ist ein Vorschlag im Abschnitt nicht aufgeführt, nutzt die Lehrkraft die zugehörige Rückmeldung in **Celina_Ausfall_Rueckmeldungen_Lehrkraft.tsv** und lässt erneut wählen. Die vorhandenen Abschnittscodes B, A, C, B, C dienen ausschließlich der Lehrkraft. Im durchgehenden Geräteausfall führt die Lehrkraft nach der Kontrolle zum nächsten Abschnitt.

## 08.12. · Lauras Frage

**01_Pflicht/Pflichtlernbogen_Foerder.pdf, Seite 2, „Lauras Frage – Meine Antwort“, Punkt 4.**

Bisher: „4. Warum hilft der Fakt Laura?“ und „„Das hilft Laura, weil …“ Wenn du beide wählst, erkläre beide.“

Neu, entsprechend dem Bildschirmauftrag: „4. Warum hilft die Nachricht Laura bei ihrer Frage? Nutze den biologischen Fakt. Beginne so: „Die Nachricht hilft Laura, weil …“ Wählst du beide Nachrichten, erkläre beide.“

**01_Pflicht/Pflichtlernbogen_Foerder.pdf, Pflichtlernbogen_ESA.pdf, Pflichtlernbogen_MSA.pdf und Pflichtlernbogen_AHR.pdf, jeweils Seite 2, Feld „Festhalten“, Hinweis vor der Statusmarkierung.**

Bisher: „Prüfung am iPad noch offen? Tippe auf „Lauras Frage – Prüfen“.“

Neu: „Sieh auf Seite 2 unter „Festhalten“ nach. Ist „digital geprüft“ oder „analog geprüft“ angekreuzt? Lies deine erste Antwort. Möchtest du etwas genauer erklären, schreibe es nur in „Festhalten“. Deine erste Antwort bleibt stehen. Fehlt das Kreuz oder ist „noch offen“ angekreuzt? Tippe auf „Lauras Frage – Prüfen“.“

Die drei vorhandenen Statusfelder bleiben unmarkiert. Die erste eigene Antwort bleibt lesbar. Unter „Festhalten“ ist Platz für eine freiwillige Präzisierung. Die Einschätzung der eigenen Begründung erfolgt im Unterricht.
