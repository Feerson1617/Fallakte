# Bildschirmtextvertrag

Softwarecommit 562ea2566dd80e31c093f313b925adcb31e22c9a. Vergleichsstand 3565a45d8688ce002b29dcb2dd04b54750e187f0.

Medienwechselmatrix.csv enthält die Papieraufträge mit einer vollständig ausgeschriebenen beobachteten Bildschirmansicht. Bildschirmzustaende.jsonl erfasst weitere Varianten mit Fallnachrichten, individuellen Rückfragen, Hilfeaufrufen und Fehlern. Die Ansichtskennung verknüpft beide Dateien. Die Matrix enthält auch die sichtbare Navigation der Elternrahmen. Bei einem offenen Dialog nennt sie den aktiven Dialog und die äußere Navigation. Eine frühere Nachricht im Verlauf kann den Gesamtwortlaut verlängern.

Quellfundstellen.csv inventarisiert die gebauten Moduldaten, JavaScript-Werte und Vorlagen, HTML-Beschriftungen und SVG-Texte. Komplette gerenderte Zeilen sind, wo wortgleich beobachtet, zusätzlich über eine Ansichtskennung belegt. Texte aus mehreren DOM-Knoten sind im Gesamtbildschirm nachlesbar. Der Prüfgrund beschreibt die redaktionelle oder technische Einordnung. Einzelfreigaben-SHA256.json bindet Wortlaut, Fundstelle und Prüfgrund der Schülertexte je Modul an diese Fassung. Technische Werte und Planungsangaben sind gesondert benannt. Als Quellenverweise dienen Modul, Adresse und Inhalt; identische Texte können an mehreren Stellen verwendet werden.

Rueckverfolgung-3565a45.csv verbindet alle 13.436 Einträge der früheren Übergabe mit dem neuen Inventar. Alt-Offen-3571.csv enthält die ehemals offenen Einträge. Die beim direkten Einstieg entfernte Selbstauskunft und die entfallenen Teamanzeigen sind ausdrücklich ausgewiesen.

Die ursprünglichen Druck-PDFs gelten für den Vergleich der Karten und der beiden unteren Pflichtbögen. Die Matrix gibt die Seiten für den Neusatz verbindlich an. Keine Schülerdaten, nur simulierte Testeingaben.
