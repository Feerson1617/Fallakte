# Satzauftrag für Work

Software 562ea2566dd80e31c093f313b925adcb31e22c9a. Die Medienwechselmatrix enthält je Niveau die verbindliche Seite, Überschrift, das Feld, den Bildschirmwortlaut, die Handlung und den Rückweg. Die vier Schüler-PDFs und die beiden geprüften Pflichtbögen sind Referenzen. In dieser Runde wurde kein PDF bearbeitet.

## Alle Materialien

- Schüleraufträge durchgehend im Singular schreiben. Personenwahl, Nummern 1 und 2 für Lernende, Rollen, Vorlesewechsel, Reihenfolgen zwischen Personen und verpflichtende Gespräche streichen. Das gilt auch für Ausfallbögen, Hilfen, Übersichten und Neustartkästen.
- Eine persönliche Antwort bleibt sichtbar, wenn sie später überprüft oder ergänzt wird. Die Software prüft auswählbare Fachinformationen. Eine freie Begründung erhält im Programm kein fachliches Urteil.
- Jeder Rückweg trägt die Beschriftung des tatsächlichen Knopfs. Steht in der Matrix eine Antwort als Rückweg, ist genau diese Auswahl die digitale Handlung. Bei der Besprechung auf Papier gibt es keinen zusätzlichen Abschlussknopf.

## Vorbereitung

- Seite 1 trägt Kondom und Kombinationspille, Seite 2 Kupfer- und Hormonspirale. Die 64 Einträge, ihre Nummern und die 16 Musterkarten aus den Druckreferenzen wortgleich übernehmen. Das Kartenblatt bleibt doppelseitig.
- Der separate Laufzettel steht auf Seite 3 für 1A bis 2B und auf Seite 4 für 3A bis 4B. In den A-Kapiteln mit Papier-Fachcheck bleiben A, B, C und das Feld „Begründung“ in ihrer geprüften Reihenfolge. Der genaue Abgleich der digitalen Ersatzanzeige steht im Bildschirmvertrag.
- In B-Kapiteln zuerst „Vollständige Karte vergleichen“, danach „Karte kontrolliert“ auf dem Laufzettel ankreuzen und „Weiter im Chat“ antippen. „Nach 2B“ enthält „Hier arbeite ich weiter“. Am Ende alle vier Methodenflächen prüfen, ergänzen und einmal durch die Mittellinie schneiden. Beide doppelseitigen Karten aufbewahren.

## 02.12. · Beratung

- Für den Satz je eine Seite für Laura 1 bis 5 vorsehen. „Mein erster Rat“ steht auf Seite 1, „Mein Schlussrat“ auf Seite 5. Die ersten vier Seiten tragen die jeweilige Laura-Überschrift aus der Matrix. Auf MSA und AHR die freien Zeilen, A/B/C-Aussagen und deren Prüfcodes beibehalten.
- Den Schlussrat nach Niveau in den kurzen Schritten des Softwarevertrags setzen. Beim Stopp der Lehrkraft kann auf Seite 5 geschrieben werden, auch wenn im Chat noch Abschnitte offen sind. Dafür ist kein Prüfcode nötig. Beide Abstimmungen mit dem Empfehlungsrad ausschließlich im Lehrkraftmaterial anleiten.
- Tom erhält einen freiwilligen Zusatzbogen mit drei Abschnittsseiten, Celina einen mit fünf. Die Zuordnung gilt für den Neusatz. Bei MSA und AHR pro Abschnitt „Begründung“ und A/B/C vorsehen. Auf Förder und ESA entsteht daraus keine neue Schreibaufgabe. Toms Forschungsartikel und Studienkästen bleiben zugänglich.

## Konkrete Druckkorrekturen in den Pflichtbögen vom 25.11.

| Seite | Bisheriger Druckhinweis | Verbindlicher Neusatz |
|---|---|---|
| 2 | „Öffnet“, „Wählt euer Niveau bei Person 1 …“, „Tippt“ | „1. Öffne Dienstag, 08.12.2026. 2. Wähle dein Niveau. 3. Tippe auf Mutter – Nachricht öffnen.“ |
| 2–3 | „Lest die Nachricht. Bearbeitet den Argumenten-Check.“ | „Lies die Nachricht. Bearbeite den Argumenten-Check.“ |
| 2–3 | „Bei Dein Lernbogen … jede Person für sich“ | Den konkreten Hinweis „Pflichtlernbogen · Seite 2“ bzw. „Pflichtlernbogen · Seite 3“ und den Feldnamen aus der Matrix übernehmen. |
| 2–3 | „Erste Antwort allein ankreuzen“ | „Setze dein erstes Kreuz links in Meine erste Antwort.“ Rechts bleibt Platz für den geprüften Fakt. |
| 3 | „Wechselt: Wer gelesen hat, tippt jetzt.“ / „Behaltet eure Personennummer und euer Niveau.“ | Beide Zeilen streichen. Es gibt keine Ersatzhandlung. |
| 4 | „Jede Person antwortet zuerst allein.“ | „Meine Antwort“ und darunter die nummerierten Schritte des jeweiligen Niveaus. |
| 4 | „Prüft nacheinander unter eurer Personennummer.“ | „Tippe auf Meine Antwort prüfen.“ |
| 4 | „Prüfe deinen Fakt …“ bzw. „Prüfe Fakt und Grund …“ | Den zustandsabhängigen Auftrag für „Festhalten“ aus der Matrix übernehmen. Erste Antwort lesbar lassen. |
| 2–4 | „gleiche Niveaus“, „eigene Person“ | „Nach Neustart“ → dein Niveau → Nachricht bzw. „Lauras Frage“ → Abschnitt → „Hier weiterarbeiten“. Prüfabschnitt und Festhalten unterscheiden. |

## 08.12. · Familiennachrichten

- Pflichtbogen Seite 1 für die Orientierung, Seite 2 „Mutter – Fakt“, Seite 3 „Freundin – Fakt“, Seite 4 für Lauras persönliche Antwort, Prüfung und „Festhalten“. Auf Seiten 2 und 3 stehen dieselben Aussagen nur einmal. Links „Meine erste Antwort“, rechts „Nach dem Prüfen“. Das erste Kreuz bleibt. Auf MSA und AHR die getrennten Schreibfelder erhalten.
- Auf Seite 4 für Förder die Fragen nach Beschwerden und späteren Kindern, M und F vor der passenden biologischen Information, die Wahl einer oder beider Nachrichten und die persönliche Begründung erhalten. Bei ESA gelten die vorhandenen Schreibfelder für Wahl und Frage, passenden Fakt und Erklärung. Bei MSA bleibt die Begründung in zwei bis drei Sätzen, bei AHR der Vergleich samt Aussagegrenze.
- Auf „Meine Antwort prüfen“ folgt LA-03. Dort bleiben Wahl der Frage, Zuordnung der Information und Grenze dieser Information unterscheidbar. Bei beiden Nachrichten werden beide Bezüge geprüft.
- LA-04 hat zwei Zustände. Nach digitaler Prüfung die erste Antwort lesen und eine mögliche Verbesserung im Feld „Festhalten“ eintragen. Beim direkten Einstieg ohne digitale Prüfung führt „Lauras Frage – Prüfen“ zu LA-03. Den alten Druckauftrag „Prüfe deinen Fakt“ und alle Verweise auf eine Personennummer entfernen. Ein auf Papier bereits vorhandenes Ergebnis bleibt lesbar. Die Einträge „digital geprüft“, „analog geprüft“ und „noch offen“ dürfen unterschiedliche Nachweise bezeichnen.
- Freiwilliger Vertiefungsbogen, Seite 1 „Großmutter – Wert“, Seite 2 „Vater – Norm“. Auch hier den ersten und den geprüften Eintrag trennen. Die Frage nach dem persönlichen Wert bzw. der allgemeinen Regel verwenden. Die Arbeitsaufträge zum biologischen Fakt der Mutter oder Freundin passen hier nicht.
- Für Ausfallbögen dieselben Überschriften, Seitenverweise und Hilfestufen verwenden. Platz und Zeilenumbrüche der neu gesetzten Seiten anschließend am Ausdruck prüfen. Der Abgleich gegen die vorliegenden Förder-/ESA-Pflichtbögen betrifft Seiten 2 bis 4. Die übrigen Seitenvorgaben sind Satzvorgaben für Work.
