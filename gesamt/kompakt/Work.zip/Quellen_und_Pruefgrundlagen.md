# Prüfgrundlagen
Materialseite vom 26.11.2026, Bezug auf den Softwarecommit 562ea2566dd80e31c093f313b925adcb31e22c9a. Die Schriften stehen unter der SIL Open Font License. Beide Schulausgaben enthalten die Lizenzen.

## Fachlicher Gegencheck
- BIÖG, familienplanung.de, Kondom – Schwangerschaftsverhütung und Risikosenkung bei Infektionen. https://www.familienplanung.de/verhuetung/verhuetungsmethoden/kondom/
- IQWiG, Medikamentöser Schwangerschaftsabbruch – Ablauf, Blutungen und mögliche Schmerzen. https://www.gesundheitsinformation.de/medikamentoeser-schwangerschaftsabbruch.html
- IQWiG, Nach einem Schwangerschaftsabbruch – spätere Fruchtbarkeit. https://www.gesundheitsinformation.de/nach-einem-schwangerschaftsabbruch.html
- Forschungsbeispiele aus Toms Fall: Behre et al., 2016, https://doi.org/10.1210/jc.2016-2141 ; Mannowetz et al., 2025, https://doi.org/10.1038/s43856-025-01004-4. Verträglichkeit von Einzeldosen ist ein anderer Endpunkt als eine beobachtete Schwangerschaft.
- Schulinterne Zuordnung: ETS, Fachcurriculum 2025/26, Sexualkunde II. Im Schwerpunkt begründet bewerten unter Verwendung biologischer Informationen. Förder ist die schulische Unterstützungsfassung. Die 4. Auflage 2026 wird in SH ab 2026/27 aufwachsend ab dem Fachbeginn eingeführt. Für diesen Jahrgang mit früherem Fachbeginn ist die auslaufende Sek-I-Fassung maßgeblich. Leitfaden 2017 als methodische Orientierung. https://fachportal.lernnetz.de/sh/fachanforderungen/biologie.html

## Vergleichsstand · SHA-256
Die beiden ausgelieferten index.html stimmen jeweils byteweise mit der zugehörigen Einzel-HTML überein.
```
34a8255eb0d6ce8f3c24b9ee9baab8cdc58e72baa345d6c908dd30eb68d2d12b  UB_02-12-2026_Materialpaket_optimiert.zip
3906fe40d24803a7d5f6e3c738ae8fbb3f898ef0772b41fdbf360fc98978d01f  UB_08-12-2026_Materialpaket_optimiert.zip
ad057861a6bcaa02254641097e2e9201add0928be358edfd8c5cba917ba53c24  Pflichtlernboegen_Foerder_ESA_25-11-2026.zip
02fb08892ebddafbf6cf3df7cbc4d3df22cee49ed075ad5c567a5be61c732f58  Fallakte-02-12-SCORM12.zip
469ec5b092951c8829577f44fe14d6b224697691cad245864388224dd24b661b  Fallakte-08-12-SCORM12.zip
5c8819c29f3389280b837ac3b1f7a7bd62a356aac8364492b604e94ed7004289  Fallakte-02-12.html
d205b8510f30d6655f744d4c0ccd23339a100131e4b955ff36e31506e1f3a9fb  Fallakte-08-12.html
dba9a682ec0a508fe982c8dde397ebc71df3964753b23b904736dd01e0b0b219  Fallakte-Bildschirmtextvertrag.zip
f2744c2f3a1fb1cbfa06b0a82a099164e1e8ddf152298c977646fce4ed49b21c  Fallakte-Sichtpruefung.zip
b44693535debaf276e94b9de93083a6fd6cc63c1df264a0be21c38cf11f4df96  Medienwechselmatrix.csv
d9630bb166e119d627d63693e3a1dcf47f832efeb5cae09dca207c3fd90c1bad  Materialaenderungen-Work.md
0d752ea942b745c8e997d622465815f3cd7ecc4d64965d62c19d9de357d84857  Fallakte-Vorbereitung-SCORM12.zip
```
