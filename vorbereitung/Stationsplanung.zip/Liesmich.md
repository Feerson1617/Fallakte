# Übergabe für Codex und Work

Maßgeblich: Stationsvertrag.json (Vorbereitung-Stationen-1.0) und der unveränderte Kartenvertrag.json. Stationsplanung_komplett.md ist die vollständig lesbare Fassung der Aufgaben, Informationen, Hilfen und Medienwege. Pruefprotokoll_Planung.md beschreibt die tatsächlich ausgeführte Datenprüfung. Karten/ enthält die vorhandenen Entwürfe und Referenzen; endgültige Druckfreigabe nach Browserprüfung des neuen separaten Vorbereitungspakets. Die beiden UB-Module bleiben unverändert. Keine Software ist in diesem Planungspaket enthalten.
