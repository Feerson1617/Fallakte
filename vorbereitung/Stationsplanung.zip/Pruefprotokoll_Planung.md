# Planungsprüfung – Kartenvertrag und Stationsvertrag

Diese Prüfung betrifft die Daten und die fachliche Planung, nicht eine neue Browserauslieferung. Es wurde keine Software implementiert. Der Kartenvertrag wurde direkt aus dem hochgeladenen Planungspaket gelesen und unverändert übernommen.

| Niveau | Teilkapitel | Fachabschnitte | digitale Hauptfragen (inkl. Einführung) | Karteneinträge | Papierchecks |
|---|---:|---:|---:|---:|---:|
| Foerder | 8 | 20/20 | 16 + 1 | 16/16 | 0 |
| ESA | 8 | 20/20 | 16 + 1 | 16/16 | 0 |
| MSA | 8 | 20/20 | 16 + 1 | 16/16 | 4 |
| AHR | 8 | 20/20 | 16 + 1 | 16/16 | 4 |

**Summen:** 32 Kapitel-Niveau-Wege, 80 Fachabschnitte, 68 digitale Hauptfragen (davon 4 Pearl-Einführungen), 8 Papier-Fachchecks, 64 wortgleiche Karteneinträge, 135 konkrete Fehlantworten mit jeweils fünf Hilfestufen (Hauptfragen und Papierchecks). Alle 76 Haupt-/Papierchecks verfügen über eine gesonderte Anwendungsfrage nach Lösungsoffenlegung. Diese sind keine zusätzlichen Pflichtfragen.

Automatisch geprüft: Kapitelreihenfolge; exakte Feld-IDs und Lösungen; vollständige Übereinstimmung der 80 Informationsabschnitte und 16 Vollkarten mit dem Kartenvertrag; passender Informationsbezug; eindeutige korrekte Auswahl; 2/3 Antwortmöglichkeiten je Niveau; vollständige Hilfen; unveränderte Papierfragen/A/B/C-Reihenfolge/Codes; eindeutige IDs; ausgewogene, nicht zyklisch wechselnde Antwortpositionen; kein Laura/Toni/Celina/Tom-Bezug in den geprüften Aufgaben- und Infotexten.

Die Fragen prüfen repräsentative Wirkweisen, Bedingungen und Fehlvorstellungen. Ergänzende Hinweise in 2A, 3A, 4A und 4B sichern auch beim Direkteinstieg den nötigen Informationsstand; insbesondere kann der gedruckte AHR-Fachcheck zur Kupferspirale bereits die unzulässige Gleichsetzung von Hormonfreiheit und Beschwerdefreiheit prüfen. Nicht jeder vorgedruckte Satz hat eine separate Pflichtfrage. Beispielsweise bleibt beim Kondom der Hinweis auf ärztliche Abklärung ungeklärter Regelschmerzen im Informationsmaterial und in der vollständigen Karte; eigene Abschrift oder richtiges Ankreuzen beweist kein vollständiges individuelles Verständnis. Für die Lehrkraft: Bei Bedarf kurze Rückfrage dazu statt zusätzliche Pflichtquizschritte.

Die Quellenbasis und Zahlen bleiben an den Kartenvertrag gebunden. pro familia: https://www.profamilia.de/themen/verhuetung/pearl-index (Abruf 24.11.2026; Zahlenbasis teilweise DGGG 2004; Richtwerte). IQWiG: https://www.gesundheitsinformation.de/verhuetungsmittel.html (perfekte vs. typische Anwendung; Erstjahresraten NICHT mit Pearl-Index gleichsetzen). Fachliche Gegenprüfung: BIÖG, https://www.familienplanung.de/verhuetung/verhuetungsmethoden/kupferspirale/ und https://www.familienplanung.de/verhuetung/verhuetungsmethoden/die-hormonspirale/; CDC, https://www.cdc.gov/hiv/prevention/condoms.html (Material, Grenzen der Schutzwirkung). Schulinterner Bezug: Jahrgang 8, Sexualkunde II, Beschreiben und Erklären verschiedener Möglichkeiten der Empfängnisverhütung sowie gesundheitlicher Risiken; der UB bleibt die mehrkriterielle fallbezogene Bewertung.

Offene Abnahme: tatsächliche Grafiken, Browserlogik, Manifest und SCORM, sichtbare Kapitel-/Papierverweise, Zeitbedarf mit Lernenden, Schul-iPad/itslearning, Layout und Probedruck. Das Tempo von rund 15 Minuten pro Methode ist eine begründete Planungsannahme, keine empirische Messung. Kein digitaler Erfolg beweist die richtige Abschrift auf Papier. Musterkarten und Rückfallweg sichern das Lernprodukt ohne fingierten Lernerfolg.

Zusätzliche direkte Quellenprüfung: Alle 80 Abschnittstitel und die jeweils zugeordneten Original-Fachtexte (`shortText` Förder/ESA; `text` MSA/AHR) des unveränderten Kartenvertrags stimmen mit `02-12/Materialvertrag.json` aus dem tatsächlich ausgelieferten `Fallakte-Release-8b50305b.zip` überein. Die neuen Stationsinformationen verwenden die daraus bereits abgeleiteten, vollständig ausgefüllten Kartentexte und die ausdrücklich ausgewiesenen ergänzenden Fachhinweise.
