# Vorbereitung zum 02.12. – verbindliche Stationsplanung
Planungsstand 1.0. Noch keine Softwareauslieferung.

Kartenvertrag: `Vorbereitung-Kartenentwurf-1.0` · SHA256 `5a887c895d9564de4c9ab3eb7cc5e3386e57e3a9c7a55c70c89bc57ae4306c6e`
Bestandsschutz: `d24308f4a0eca8ed39f0f75b04b890b78bcc8332` (beide UB-Tage), `8b50305b6d98a19e1771a842ea9917c67282ecb9` (02.12.-Referenz).

## Ablauf und Bedienung

**regular:** Jedes Kapitel beginnt mit Markierung der Kapitelkennung auf dem Papier. Informationen und Abbildung bleiben während der Aufgaben jederzeit erreichbar. Kein bloßes Öffnen/Schließen als Wissensnachweis. Zwei digitale Fragen nacheinander. Antworten vor einem weiteren Schritt bewusst prüfen. Korrekte Antwort oder nach Lösungshilfe korrekte zusätzliche Anwendung erforderlich. Erst dann Kartenfelder anzeigen. Kein Lösungsstreifen im regulären Weg vor der Wissensprüfung.

**help:** Fehlantwort bleibt als gewählte Aussage sichtbar. Unmittelbar antwortspezifische Rückmeldung, freie erneute Auswahl. Weitere Hilfe schrittweise, fünf aufeinander aufbauende Stufen. Nach neuer Auswahl keine veraltete Fehlantwort-Hilfe; bisherige Hilfenutzung im Sitzungsstatus erhalten. Vor Auswahl nur allgemeine Hilfe. Stufe 5 legt die korrekte Aussage mit Erklärung offen. Nach Stufe 5 die ursprüngliche Aussage richtig auswählen und die gesonderte Anwendungsfrage korrekt beantworten. Falsche Anwendungsantwort ist korrigierbar. Wenn weiterhin nicht lösbar: getrennten Musterkarten-/Ausfallweg nutzen, keine bestandene Wissensprüfung vortäuschen.

**paper:** Felder nach Kapitel und Niveau exakt anzeigen, je zwei. Schüler ergänzen auf der Karte, vergleichen mit den vorgegebenen Wörtern. MSA/AHR zusätzlich in A-Kapiteln passende gedruckte Aussage markieren und stichwortartig selbst begründen, dann Buchstaben eingeben. Nur A/B/C, trim und Groß-/Kleinschreibung tolerant. Kein Code auf Förder/ESA oder B-Kapiteln. Falscher Code: Rückmeldung zum konkret markierten Satz, Hilfen und neuer Versuch. Richtiger Code: noch bewusst Nachricht senden. Code prüft nur die markierte Aussage, nie fachlich den Freitext oder die Abschrift.

**return:** Förder/ESA und alle B-Kapitel: nach tatsächlichem Vergleich „Weiter im Chat“. MSA/AHR nach A-Code „Nachricht senden“, kurze fachliche Bestätigung, danach „Weiter im Chat“. In B vollständige Musterkarte erst nach regulär bestandener Prüfung dieses Kapitels als Vergleich anzeigen; vorherige A-Felder nach Direkteinstieg nicht als digital bestanden ausgeben. Auf Papier „Karte kontrolliert“ markieren. Kein automatischer Erfolgsstatus durch Öffnen, Abschreiben oder Direktwahl.

**recovery:** RAM-Stand getrennt je Niveau innerhalb der Sitzung. Neu beginnen setzt nur gewählten Vorbereitungsweg zurück, mit Bestätigung bei vorhandenem Stand. Vollständiges Neuladen löscht sämtliche digitalen Lernzustände. Nach Reload Niveau wählen, Abschnitt auswählen, zuletzt markiertes oder nächstes noch offenes Kapitel beginnen. Aktueller Fachcheck frisch; frühere Kapitel bleiben unbekannt, keine fingierten Erfolge. Direktstart in 3A zur zweiten Stunde ohne Wiederholung von 1A–2B oder Pearl-Einführung möglich. Papier ist Fortschrittsanker. Bereits gefüllte Felder vergleichen, nicht neu abschreiben.

**reference:** Optionaler klar als Unterstützung gekennzeichneter Wiederholungs-/Ausfallweg mit vollständigen Referenzkarten auf dem eigenen Niveau. Nie als selbstständige Erledigung zählen. Auf Papier Karte kontrollieren; bei Zeitnot druckfertige Referenzkarten verteilen. Keine zusätzliche Freitextbewertung oder Punkte.

**privacy:** Keine Anmeldung, keine persönlichen Angaben oder Fragen zu eigenen Sexualerfahrungen, keine Netzwerkabhängigkeit, kein localStorage, keine Cookies und keine SCORM-Lernstandsspeicherung. Zustände nur im RAM; SCORM nur technischer Start/Ende ohne Weitergabe von Schülerantworten.

**boundary:** Nur Methodenwissen, fachliche Fehlschlüsse und Bedienung. Kein Fall Laura/Toni oder persönlicher mehrkriterieller Beratungsfall. Kein Vorgriff auf den UB-Schlussrat. Beide fertig geprüften UB-Module und die gemeinsame Auslieferung unangetastet lassen.

## Zeitraster (Planungswerte)
| Zeit | Stunde 1 |
|---|---|
| 0–5 | Material bereitlegen, Niveau wählen |
| 5–10 | Pearl-Index und erster Medienwechsel |
| 10–25 | 1A und 1B |
| 25–40 | 2A und 2B |
| 40–45 | Karten prüfen, Papierfortschritt markieren, Material sichern |

| Zeit | Stunde 2 |
|---|---|
| 0–4 | Niveau und Abschnitt wählen, Karten bereitlegen |
| 4–19 | 3A und 3B |
| 19–34 | 4A und 4B |
| 34–40 | Vier Karten prüfen, fehlende Einträge mit Referenz sichern |
| 40–45 | Ausschneiden und aufbewahren |

## Bilder – verbindliche fachliche Briefings (noch keine Grafiken)

### 1A · Eine Hülle hält Sperma zurück
Zwei neutrale, beschriftete Materialproben/Packungshinweise (Latex und synthetisch latexfrei, beide zur Verhütung geeignet). Daneben vergrößerte schematische intakte Kondomhülle mit wenigen Spermien-Symbolen innerhalb. Kein vollständiger Schutz behauptet, keine Sexualhandlung dargestellt.
Beschriftungen: Material, zur Verhütung geeignet, intakte Hülle, Spermien
Alternativtext: Zwei geeignete Materialien können eine mechanische Hülle bilden. In der intakten Hülle bleiben die gezeichneten Spermien zurück.

### 1B · Beginn und Grenze der Barriere
Zwei vereinfachte schematische Flächen: bedeckter und unbedeckter Bereich (ohne Körperdarstellung möglich). Daneben eine Zeitleiste „Beginn → weiterer Kontakt“ mit korrekt ab Beginn bestehender Barriere und im Vergleich verspätet entstehender Barriere. Keine grafische Garantie oder quantitative Risikodaten.
Beschriftungen: bedeckt, unbedeckt, von Anfang an, später Beginn
Alternativtext: Die Hülle bedeckt nur einen Teil einer Kontaktfläche. Ein späterer Beginn lässt davor Kontakt zu.

### 2A · Eisprung und Befruchtung
Anatomisch vereinfachte Gebärmutter, Eileiter und Eierstock. Zwei kleine Vergleichsbilder: Freisetzung einer Eizelle Richtung Eileiter und bei wirksamer Kombinationspille gehemmter Eisprung; keinen verschlossenen Eileiter zeichnen. Kennzeichnen, dass dies ein Modell des hauptsächlichen Wirkprinzips ist.
Beschriftungen: Eierstock, Eileiter, Eizelle, Eisprung, Eisprung gehemmt
Alternativtext: Im ersten Modell wird eine Eizelle aus dem Eierstock freigesetzt. Im zweiten Modell bleibt der Eisprung unter wirksamer hormoneller Anwendung aus.

### 2B · Anwendung und persönliche Reaktionen
Vereinfachte Abfolge von drei generischen Tagen: regelmäßige Einnahme nach Plan gegenüber einer Lücke. Keine konkreten medizinischen Dosierungs- oder Nachholanweisungen. Darunter zwei gleichwertige, sachliche Beispielnotizen zu möglichen unterschiedlichen Reaktionen; keine Diagnose oder garantierte Folge.
Beschriftungen: nach Plan, Einnahme vergessen, mögliche Beschwerden, unterschiedliche Reaktionen
Alternativtext: Eine ausgelassene Einnahme weicht vom Plan ab. Personen können unterschiedlich auf dasselbe Präparat reagieren.

### 3A · Kupferwirkung in der Gebärmutter
Anatomisch plausibler Schnitt mit Gebärmutter, Gebärmutterhals, Eileitern und einer T-förmigen Kupferspirale in der Gebärmutterhöhle. Schematische Kupferabgabe und beeinträchtigte Spermienbewegung mit wenigen Pfeilen; keine vollständige Blockade und keine Verschlusskappe zeichnen.
Beschriftungen: Gebärmutter, Gebärmutterhals, Kupferspirale, Kupfer, Spermien
Alternativtext: Die Kupferspirale liegt in der Gebärmutter. Abgegebenes Kupfer beeinträchtigt die Spermien. Der Gebärmutterhals ist nicht mechanisch verschlossen.

### 3B · Einlage und Wirkung über längere Zeit
Ablaufgrafik mit drei Punkten: Eignung und Zustimmung in der Arztpraxis → ärztliches Einsetzen → längerfristige Wirkung und Lagekontrollen. Neben dem Ablauf ein ausdrücklich als Möglichkeit bezeichnetes Symbol „Blutung/Schmerzen können stärker werden“. Keine vorhersagende Kurve oder Häufigkeitsangaben.
Beschriftungen: Eignung und Zustimmung, Einsetzen, längere Wirkung, Lagekontrolle, mögliche stärkere Beschwerden
Alternativtext: Vor dem ärztlichen Einsetzen stehen Eignung und freiwillige Zustimmung. Danach ist keine tägliche Einnahme nötig. Beschwerden können stärker werden.

### 4A · Gestagen und Schleim am Gebärmutterhals
Gleiche anatomische Grundform wie bei 3A, aber mit Hormonspirale und hervorgehobenem Gebärmutterhals. Vereinfachte vergrößerte Detaildarstellung normaler und durch Gestagen schwerer durchlässiger Schleimstruktur mit Spermienpfeilen. Kein vollständiger mechanischer Verschluss; keine Erregerzeichnung, die sicheren STI-Schutz suggeriert.
Beschriftungen: Hormonspirale, Gestagen, Gebärmutterhals, Schleim, Spermien
Alternativtext: Die Hormonspirale gibt Gestagen ab. Der Schleim am Gebärmutterhals wird für Spermien schwerer durchlässig.

### 4B · Langfristige Hormonabgabe und mögliche Veränderungen
Ablaufgrafik wie 3B: Eignung und freiwillige Zustimmung → ärztliches Einsetzen → längerfristige Gestagenabgabe und Lagekontrollen. Separate qualitative Hinweise: Blutung kann anfangs unregelmäßig sein, später können Blutung und Schmerz nachlassen. Keine Garantie, keine numerischen Verläufe.
Beschriftungen: ärztliches Einsetzen, längerfristige Hormonabgabe, Lagekontrolle, mögliche Veränderungen
Alternativtext: Die Hormonspirale bleibt nach dem Einsetzen in der Gebärmutter und gibt über längere Zeit ein Hormon ab. Blutung und Schmerzen können sich verändern.

# Förder

## Pearl-Index
Der Pearl-Index ist eine Zahl zum Schutz vor Schwangerschaft. Beispiel: 100 Frauen verhüten ein Jahr. Drei werden trotzdem schwanger. Der Pearl-Index ist in diesem vereinfachten Beispiel 3. Kleine Zahl: weniger Schwangerschaften. Die Zahl ist ein Richtwert, keine Garantie. Sie sagt nichts über Infektionen beim Sex aus.
**PI-Q1-Foerder** – Was bedeutet ein kleiner Pearl-Index?
- 1: Mehr Schwangerschaften trotz Verhütung. **(falsch)** – Du hast die Richtung verwechselt.
  - Hilfe 1: Lies im Informationsmaterial: Pearl-Index (Definition auf jeder Karte).
  - Hilfe 2: Kleinere Zahl: weniger Schwangerschaften.
  - Hilfe 3: Welche Zahl ist kleiner: 2 oder 10?
  - Hilfe 4: Es geht um Schwangerschaften, nicht um Infektionen.
  - Hilfe 5: Passende Aussage: Weniger Schwangerschaften trotz Verhütung. Der Pearl-Index beschreibt, wie häufig Schwangerschaften trotz Verhütung auftreten.
- 2: Weniger Schwangerschaften trotz Verhütung. **(richtig)** – Der Pearl-Index beschreibt, wie häufig Schwangerschaften trotz Verhütung auftreten.
- Hilfen ohne Auswahl: Lies im Informationsmaterial: Pearl-Index (Definition auf jeder Karte). → Vergleiche die Aussagen mit dem beschriebenen biologischen Mechanismus. → Welche Zahl ist kleiner: 2 oder 10? → Es geht um Schwangerschaften, nicht um Infektionen. → Passende Aussage: Weniger Schwangerschaften trotz Verhütung. Der Pearl-Index beschreibt, wie häufig Schwangerschaften trotz Verhütung auftreten.
- **Nach Lösungshilfe:** Welche Zahl spricht unter vergleichbaren Bedingungen für weniger Schwangerschaften trotz Verhütung?
  - 2 statt 8. (richtig) – Ein kleinerer Pearl-Index steht für weniger Schwangerschaften bezogen auf die Anwendungszeit.
  - 8 statt 2. (falsch) – Die Richtung ist vertauscht. Vergleiche die kleinere mit der größeren Zahl.

## 1A – Kondom: Material und Barriere

Informationsmaterial (auf dem iPad sichtbar, beim Antworten wieder aufrufbar):
- **Material und Allergie:** Es gibt geeignete Kondome aus Kunststoff ohne Latex. Achte auf die Packung.
- **Barriere und Schwangerschaft:** Das Kondom fängt Sperma auf. Es hält Spermien zurück, wenn es richtig sitzt und heil bleibt. Es enthält keine Hormone.

Bildimpuls: Zeige auf die Hülle: Wo sind die Spermien?

**1A-Q1-Foerder** – Jemand verträgt Latex nicht. Was stimmt?
- 1: Alle Kondome bestehen aus Latex. **(falsch)** – Du setzt ein Material mit allen Kondomen gleich.
  - Hilfe 1: Lies im Informationsmaterial: Material und Allergie.
  - Hilfe 2: In der Materialbeschreibung werden verschiedene Stoffe genannt.
  - Hilfe 3: Muss jede Hülle aus demselben Stoff bestehen?
  - Hilfe 4: Suche auf der Packung nach Material und Eignung.
  - Hilfe 5: Passende Aussage: Es gibt passende Kondome ohne Latex. Die Allergie betrifft das Material. Geeignete Kondome gibt es auch ohne Latex.
- 2: Es gibt passende Kondome ohne Latex. **(richtig)** – Die Allergie betrifft das Material. Geeignete Kondome gibt es auch ohne Latex.
- Hilfen ohne Auswahl: Lies im Informationsmaterial: Material und Allergie. → Vergleiche die Aussagen mit dem beschriebenen biologischen Mechanismus. → Muss jede Hülle aus demselben Stoff bestehen? → Suche auf der Packung nach Material und Eignung. → Passende Aussage: Es gibt passende Kondome ohne Latex. Die Allergie betrifft das Material. Geeignete Kondome gibt es auch ohne Latex.
- **Nach Lösungshilfe:** Auf einer anderen Packung steht „Kunststoff, latexfrei, zur Verhütung geeignet“. Was ist möglich?
  - Ein geeignetes Kondom ohne Latex. (richtig) – Die Packung nennt das latexfreie Material und die Eignung zur Verhütung.
  - Nur ein Latexkondom. (falsch) – Prüfe den Stoffnamen. „Latexfrei“ bedeutet ohne Latex.

**1A-Q2-Foerder** – Was hält ein richtig sitzendes, heiles Kondom zurück?
- 1: Sperma mit Spermien. **(richtig)** – Die Hülle fängt Sperma auf.
- 2: Die Eizelle im Eierstock. **(falsch)** – Du verwechselst den Ort der Eizelle mit dem Kondom.
  - Hilfe 1: Lies im Informationsmaterial: Barriere und Schwangerschaft.
  - Hilfe 2: Sieh dir die Hülle und den Weg der Spermien an.
  - Hilfe 3: Stell dir die Hülle vor. Was bleibt darin?
  - Hilfe 4: Die Eizelle befindet sich nicht in dieser Hülle.
  - Hilfe 5: Passende Aussage: Sperma mit Spermien. Die Hülle fängt Sperma auf.
- Hilfen ohne Auswahl: Lies im Informationsmaterial: Barriere und Schwangerschaft. → Vergleiche die Aussagen mit dem beschriebenen biologischen Mechanismus. → Stell dir die Hülle vor. Was bleibt darin? → Die Eizelle befindet sich nicht in dieser Hülle. → Passende Aussage: Sperma mit Spermien. Die Hülle fängt Sperma auf.
- **Nach Lösungshilfe:** Eine Hülle bekommt ein Loch. Was kann dann passieren?
  - Sperma kann aus der Hülle gelangen. (richtig) – Die Barriere ist nicht mehr intakt.
  - Die Eizelle wird dadurch im Eierstock festgehalten. (falsch) – Das Kondom verändert den Eierstock nicht. Denke an das Loch in der Hülle.

**Nach bestandener Prüfung – Papier:** Papier · 1A – Kondom: Ergänze die Felder 1, 2 genau wie angezeigt. Vergleiche deine Einträge.
- Feld 1 (1A-1, Material und Allergie): **ohne Latex**
- Feld 2 (1A-2, Barriere und Schwangerschaft): **Spermien**
Kein Code. Nach Vergleich „Weiter im Chat“.
Nächstes Kapitel: 1B

## 1B – Kondom: Schutz und Alltag

Informationsmaterial (auf dem iPad sichtbar, beim Antworten wieder aufrufbar):
- **Schutz vor Infektionen:** Ein geeignetes Kondom senkt das Risiko vieler Infektionen beim Sex (STI). Ein Teil der Haut bleibt frei. Das Risiko sinkt, ist aber nicht null. Kondome aus Naturmembran (Tierdarm) schützen nicht zuverlässig vor STI.
- **Bei jedem Sex:** Bei jedem Sex ein neues Kondom von Anfang an richtig benutzen. Es kann reißen oder abrutschen.
- **Regelschmerzen:** Ein Kondom verändert die Regel nicht. Starke Schmerzen ohne bekannte Ursache: in der Arztpraxis abklären lassen.

Bildimpuls: Welche Stelle bleibt frei?

**1B-Q1-Foerder** – Schützt ein geeignetes Kondom vor allen Infektionen beim Sex?
- 1: Das Risiko sinkt. Es bleibt aber ein Risiko. **(richtig)** – Das Kondom vermindert viele Übertragungen; ein Teil der Haut bleibt frei.
- 2: Ja, dann ist keine Infektion mehr möglich. **(falsch)** – Du machst aus Risikominderung einen sicheren Schutz.
  - Hilfe 1: Lies im Informationsmaterial: Schutz vor Infektionen.
  - Hilfe 2: Schau in der Karte, welche Haut frei bleibt.
  - Hilfe 3: Ist die ganze Haut bedeckt?
  - Hilfe 4: Eine Hülle deckt nur einen Teil des Körpers ab.
  - Hilfe 5: Passende Aussage: Das Risiko sinkt. Es bleibt aber ein Risiko. Das Kondom vermindert viele Übertragungen; ein Teil der Haut bleibt frei.
- Hilfen ohne Auswahl: Lies im Informationsmaterial: Schutz vor Infektionen. → Vergleiche die Aussagen mit dem beschriebenen biologischen Mechanismus. → Ist die ganze Haut bedeckt? → Eine Hülle deckt nur einen Teil des Körpers ab. → Passende Aussage: Das Risiko sinkt. Es bleibt aber ein Risiko. Das Kondom vermindert viele Übertragungen; ein Teil der Haut bleibt frei.
- **Nach Lösungshilfe:** Warum kann trotz Kondom eine Infektion möglich sein?
  - Ein Teil der Haut bleibt frei. (richtig) – Die Barriere ist räumlich begrenzt.
  - Weil Kondome immer den Eisprung auslösen. (falsch) – Das ist keine Kondomwirkung. Lies die Stelle zum Infektionsschutz.

**1B-Q2-Foerder** – Wann wird ein neues Kondom benutzt?
- 1: Erst kurz vor dem Samenerguss. **(falsch)** – Der Schutz würde dann zu spät beginnen.
  - Hilfe 1: Lies im Informationsmaterial: Bei jedem Sex; Regelschmerzen.
  - Hilfe 2: Denke an den Kontakt vor dem Samenerguss.
  - Hilfe 3: Wann können Körperflüssigkeiten schon in Kontakt kommen?
  - Hilfe 4: „Am Ende“ lässt vorherigen Kontakt zu.
  - Hilfe 5: Passende Aussage: Bei jedem Sex von Anfang an. Die Hülle muss schon vor möglichem Kontakt mit Sperma und vielen Erregern richtig sitzen.
- 2: Bei jedem Sex von Anfang an. **(richtig)** – Die Hülle muss schon vor möglichem Kontakt mit Sperma und vielen Erregern richtig sitzen.
- Hilfen ohne Auswahl: Lies im Informationsmaterial: Bei jedem Sex; Regelschmerzen. → Vergleiche die Aussagen mit dem beschriebenen biologischen Mechanismus. → Wann können Körperflüssigkeiten schon in Kontakt kommen? → „Am Ende“ lässt vorherigen Kontakt zu. → Passende Aussage: Bei jedem Sex von Anfang an. Die Hülle muss schon vor möglichem Kontakt mit Sperma und vielen Erregern richtig sitzen.
- **Nach Lösungshilfe:** Ein Kondom wurde richtig angelegt, rutscht aber ab. Was gilt?
  - Der Schutz bleibt sicher gleich. (falsch) – Der Sitz ist verändert. Denke an die Voraussetzung für die Barriere.
  - Der Schutz kann geringer sein. (richtig) – Die Hülle sitzt nicht mehr richtig.

**Nach bestandener Prüfung – Papier:** Papier · 1B – Kondom: Ergänze die Felder 3, 4 genau wie angezeigt. Vergleiche deine Einträge.
- Feld 3 (1B-3, Schutz vor Infektionen): **Risiko**
- Feld 4 (1B-4, Bei jedem Sex): **von Anfang an**
Kein Code. Nach Vergleich „Weiter im Chat“.
Vergleich mit vollständiger Karte des eigenen Niveaus. Auf Papier „Karte kontrolliert“ markieren. Keine rückwirkende digitale Freigabe.
Nächstes Kapitel: 2A

## 2A – Kombinationspille: Hormone und Schutzwirkung

Informationsmaterial (auf dem iPad sichtbar, beim Antworten wieder aufrufbar):
- **Hormone und Eisprung:** Die Kombinationspille enthält zwei Hormone. Sie verhindert meist den Eisprung. Ohne Eisprung kann keine Eizelle befruchtet werden.
- **Schutz vor Infektionen:** Die Pille hält keine Krankheitserreger zurück. Sie bietet keinen Schutz vor STI.

Ergänzender kurzer Fachhinweis: Die Pille wirkt nur zuverlässig bei richtiger Anwendung nach Plan. Die Einnahme besprechen wir in 2B.

Bildimpuls: Woher kommt die Eizelle?

**2A-Q1-Foerder** – Was verhindert die Kombinationspille vor allem?
- 1: Den Eisprung. **(richtig)** – Die Hormone hemmen vor allem die Freisetzung einer Eizelle.
- 2: Dass Sperma außen am Körper ankommt. **(falsch)** – Du beschreibst das Kondom.
  - Hilfe 1: Lies im Informationsmaterial: Hormone und Eisprung.
  - Hilfe 2: Die Pille wirkt auf den Zyklus im Körper.
  - Hilfe 3: Was muss aus dem Eierstock kommen, damit eine Eizelle befruchtet werden kann?
  - Hilfe 4: Suche im Bild den Pfeil vom Eierstock zum Eileiter.
  - Hilfe 5: Passende Aussage: Den Eisprung. Die Hormone hemmen vor allem die Freisetzung einer Eizelle.
- Hilfen ohne Auswahl: Lies im Informationsmaterial: Hormone und Eisprung. → Vergleiche die Aussagen mit dem beschriebenen biologischen Mechanismus. → Was muss aus dem Eierstock kommen, damit eine Eizelle befruchtet werden kann? → Suche im Bild den Pfeil vom Eierstock zum Eileiter. → Passende Aussage: Den Eisprung. Die Hormone hemmen vor allem die Freisetzung einer Eizelle.
- **Nach Lösungshilfe:** Welche Folge hat ein unterdrückter Eisprung?
  - Es wird keine Eizelle zur Befruchtung freigesetzt. (richtig) – Die Eizelle bleibt für die Befruchtung in diesem Zyklus nicht verfügbar.
  - Ein Kondom bildet sich im Körper. (falsch) – Die Pille bildet keine Hülle. Denke an die Eizelle.

**2A-Q2-Foerder** – Die Pille wirkt auf den Zyklus. Was bedeutet das für den Infektionsschutz?
- 1: Die Pille schützt deshalb auch vor STI. **(falsch)** – Du verwechselst Schutz vor Schwangerschaft mit Schutz vor Infektionen.
  - Hilfe 1: Lies im Informationsmaterial: Schutz vor Infektionen.
  - Hilfe 2: Lies, worauf die Pille wirkt.
  - Hilfe 3: Hat die Pille eine Hülle beim Sex?
  - Hilfe 4: Denke an den Unterschied zur Kondomhülle.
  - Hilfe 5: Passende Aussage: Die Pille schützt nicht vor STI. Die Pille wirkt auf den Zyklus und bildet keine Erregerbarriere.
- 2: Die Pille schützt nicht vor STI. **(richtig)** – Die Pille wirkt auf den Zyklus und bildet keine Erregerbarriere.
- Hilfen ohne Auswahl: Lies im Informationsmaterial: Schutz vor Infektionen. → Vergleiche die Aussagen mit dem beschriebenen biologischen Mechanismus. → Hat die Pille eine Hülle beim Sex? → Denke an den Unterschied zur Kondomhülle. → Passende Aussage: Die Pille schützt nicht vor STI. Die Pille wirkt auf den Zyklus und bildet keine Erregerbarriere.
- **Nach Lösungshilfe:** Die Pille wird nach Plan genommen. Was gilt trotzdem?
  - Alle Infektionen werden verhindert. (falsch) – Das Schutzziel ist falsch übertragen. Denke an den Wirkungsort.
  - Sie schützt nicht vor STI. (richtig) – Die regelmäßige Einnahme schafft keine Erregerbarriere.

**Nach bestandener Prüfung – Papier:** Papier · 2A – Kombinationspille: Ergänze die Felder 1, 2 genau wie angezeigt. Vergleiche deine Einträge.
- Feld 1 (2A-1, Hormone und Eisprung): **Eisprung**
- Feld 2 (2A-2, Schutz vor Infektionen): **keinen**
Kein Code. Nach Vergleich „Weiter im Chat“.
Nächstes Kapitel: 2B

## 2B – Kombinationspille: Anwendung und Verträglichkeit

Informationsmaterial (auf dem iPad sichtbar, beim Antworten wieder aufrufbar):
- **Regelmäßige Einnahme:** Die Pille regelmäßig nach Plan nehmen. Vergessene Tabletten können den Schutz vor Schwangerschaft verringern.
- **Persönliche Verträglichkeit:** Menschen vertragen die Pille unterschiedlich. Beschwerden, z. B. Übelkeit, sind möglich. In der Arztpraxis klären, ob sie passt.
- **Blutung und Regelschmerzen:** Blutungen und Regelschmerzen können schwächer werden. Das ist nicht sicher. Starke ungeklärte Schmerzen ärztlich abklären lassen.

Bildimpuls: Wo fehlt die Einnahme?

**2B-Q1-Foerder** – Wie wird die Kombinationspille angewendet?
- 1: Nur direkt vor dem Sex. **(falsch)** – Du behandelst die Pille wie eine Methode für einen einzelnen Sexualkontakt.
  - Hilfe 1: Lies im Informationsmaterial: Regelmäßige Einnahme.
  - Hilfe 2: Lies den Einnahmeplan-Hinweis.
  - Hilfe 3: Muss die Pille nur in einem Moment wirken?
  - Hilfe 4: Ein Einnahmeplan bedeutet wiederkehrende Einnahmen.
  - Hilfe 5: Passende Aussage: Regelmäßig nach Plan. Vergessene Tabletten können den Schwangerschaftsschutz verringern.
- 2: Regelmäßig nach Plan. **(richtig)** – Vergessene Tabletten können den Schwangerschaftsschutz verringern.
- Hilfen ohne Auswahl: Lies im Informationsmaterial: Regelmäßige Einnahme. → Vergleiche die Aussagen mit dem beschriebenen biologischen Mechanismus. → Muss die Pille nur in einem Moment wirken? → Ein Einnahmeplan bedeutet wiederkehrende Einnahmen. → Passende Aussage: Regelmäßig nach Plan. Vergessene Tabletten können den Schwangerschaftsschutz verringern.
- **Nach Lösungshilfe:** Was muss bei der Pille beachtet werden?
  - Sie muss nur beim Sex angelegt werden. (falsch) – Du beschreibst eine andere Methode. Die Pille wird eingenommen.
  - Der Einnahmeplan. (richtig) – Regelmäßige Einnahme ist wichtig für den Schutz.

**2B-Q2-Foerder** – Eine Person bekommt von der Pille Übelkeit. Was weiß man über eine andere Person?
- 1: Sie kann die Pille anders vertragen. **(richtig)** – Verträglichkeit ist bei Menschen unterschiedlich; ärztlich klären lassen.
- 2: Sie bekommt sicher auch Übelkeit. **(falsch)** – Du überträgst eine Erfahrung auf alle Menschen.
  - Hilfe 1: Lies im Informationsmaterial: Persönliche Verträglichkeit; Blutung und Regelschmerzen.
  - Hilfe 2: Lies den Abschnitt zur Verträglichkeit.
  - Hilfe 3: Reagieren alle Körper gleich?
  - Hilfe 4: Die Erfahrung einer Person sagt nicht sicher voraus, was bei anderen passiert.
  - Hilfe 5: Passende Aussage: Sie kann die Pille anders vertragen. Verträglichkeit ist bei Menschen unterschiedlich; ärztlich klären lassen.
- Hilfen ohne Auswahl: Lies im Informationsmaterial: Persönliche Verträglichkeit; Blutung und Regelschmerzen. → Vergleiche die Aussagen mit dem beschriebenen biologischen Mechanismus. → Reagieren alle Körper gleich? → Die Erfahrung einer Person sagt nicht sicher voraus, was bei anderen passiert. → Passende Aussage: Sie kann die Pille anders vertragen. Verträglichkeit ist bei Menschen unterschiedlich; ärztlich klären lassen.
- **Nach Lösungshilfe:** Mit der Pille können Regelschmerzen schwächer werden. Ist das sicher?
  - Nein, Menschen reagieren unterschiedlich. (richtig) – Eine mögliche Linderung ist keine Garantie.
  - Ja, bei allen Personen. (falsch) – Du machst aus „können“ ein „immer“. Vergleiche die Begriffe.

**Nach bestandener Prüfung – Papier:** Papier · 2B – Kombinationspille: Ergänze die Felder 3, 4 genau wie angezeigt. Vergleiche deine Einträge.
- Feld 3 (2B-3, Regelmäßige Einnahme): **regelmäßig**
- Feld 4 (2B-4, Persönliche Verträglichkeit): **unterschiedlich**
Kein Code. Nach Vergleich „Weiter im Chat“.
Vergleich mit vollständiger Karte des eigenen Niveaus. Auf Papier „Karte kontrolliert“ markieren. Keine rückwirkende digitale Freigabe.
Nächstes Kapitel: 3A

## 3A – Kupferspirale: Kupfer und Schutzwirkung

Informationsmaterial (auf dem iPad sichtbar, beim Antworten wieder aufrufbar):
- **Kupfer und Spermien:** Kupfer stört die Spermien. Sie bewegen sich schlechter und können eine Eizelle schlechter befruchten. Die Spirale wirkt ohne Hormone.
- **Schutz vor Infektionen:** Die Kupferspirale hält keine Krankheitserreger zurück. Sie bietet keinen STI-Schutz.

Ergänzender kurzer Fachhinweis: Ohne Hormone heißt nicht ohne mögliche Beschwerden. Mehr dazu in 3B.

Bildimpuls: Was gibt die Spirale ab?

**3A-Q1-Foerder** – Worauf wirkt das Kupfer der Spirale?
- 1: Auf den Eisprung durch Hormone. **(falsch)** – Du beschreibst eine hormonelle Methode.
  - Hilfe 1: Lies im Informationsmaterial: Kupfer und Spermien.
  - Hilfe 2: Suche nach dem Wort „Kupfer“ und seinem Ziel.
  - Hilfe 3: Was muss sich zur Eizelle bewegen können?
  - Hilfe 4: Kupfer ist kein Hormon.
  - Hilfe 5: Passende Aussage: Auf Spermien. Kupfer stört Beweglichkeit und Befruchtungsfähigkeit der Spermien.
- 2: Auf Spermien. **(richtig)** – Kupfer stört Beweglichkeit und Befruchtungsfähigkeit der Spermien.
- Hilfen ohne Auswahl: Lies im Informationsmaterial: Kupfer und Spermien. → Vergleiche die Aussagen mit dem beschriebenen biologischen Mechanismus. → Was muss sich zur Eizelle bewegen können? → Kupfer ist kein Hormon. → Passende Aussage: Auf Spermien. Kupfer stört Beweglichkeit und Befruchtungsfähigkeit der Spermien.
- **Nach Lösungshilfe:** Welche Folge kann die Kupferwirkung haben?
  - Spermien können schlechter eine Eizelle befruchten. (richtig) – Kupfer beeinträchtigt ihre Befruchtungsfähigkeit.
  - Die Spirale gibt Östrogen ab. (falsch) – Kupfer ist kein Hormon. Betrachte die betroffenen Spermien.

**3A-Q2-Foerder** – Kupfer stört Spermien. Welche Schutzwirkung hat die Spirale?
- 1: Sie schützt vor Schwangerschaft, nicht vor STI. **(richtig)** – Kupfer wirkt auf Spermien; es gibt keine Erregerbarriere beim Sex.
- 2: Sie schützt vor Schwangerschaft und vor STI. **(falsch)** – Du setzt Schwangerschaftsschutz mit Infektionsschutz gleich.
  - Hilfe 1: Lies im Informationsmaterial: Schutz vor Infektionen.
  - Hilfe 2: Lies die Karte zum Schutz vor Infektionen.
  - Hilfe 3: Sind Spermien und Krankheitserreger dasselbe?
  - Hilfe 4: Die Spirale bildet keine Hülle wie ein Kondom.
  - Hilfe 5: Passende Aussage: Sie schützt vor Schwangerschaft, nicht vor STI. Kupfer wirkt auf Spermien; es gibt keine Erregerbarriere beim Sex.
- Hilfen ohne Auswahl: Lies im Informationsmaterial: Schutz vor Infektionen. → Vergleiche die Aussagen mit dem beschriebenen biologischen Mechanismus. → Sind Spermien und Krankheitserreger dasselbe? → Die Spirale bildet keine Hülle wie ein Kondom. → Passende Aussage: Sie schützt vor Schwangerschaft, nicht vor STI. Kupfer wirkt auf Spermien; es gibt keine Erregerbarriere beim Sex.
- **Nach Lösungshilfe:** Kupfer stört Spermien. Was gilt für STI?
  - Sie verhindert dadurch jede STI. (falsch) – Erregerübertragung ist ein anderer Vorgang. Trenne die beiden Ziele.
  - Die Kupferspirale schützt nicht vor STI. (richtig) – Spermienwirkung ist keine Erregerbarriere.

**Nach bestandener Prüfung – Papier:** Papier · 3A – Kupferspirale: Ergänze die Felder 1, 2 genau wie angezeigt. Vergleiche deine Einträge.
- Feld 1 (3A-1, Kupfer und Spermien): **Spermien**
- Feld 2 (3A-2, Schutz vor Infektionen): **keinen**
Kein Code. Nach Vergleich „Weiter im Chat“.
Nächstes Kapitel: 3B

## 3B – Kupferspirale: Alltag und Einlage

Informationsmaterial (auf dem iPad sichtbar, beim Antworten wieder aufrufbar):
- **Schutz im Alltag:** Sie wirkt lange und sehr zuverlässig. Tägliche Tabletten sind nicht nötig. Die Lage wird in der Praxis kontrolliert.
- **Einsetzen und Entscheidung:** Die Spirale wird in der Arztpraxis in die Gebärmutter eingesetzt. Das kann wehtun. Vorher klären, ob sie passt. Die Person entscheidet selbst.
- **Blutung und Regelschmerzen:** Blutungen und Regelschmerzen können stärker werden. Starke ungeklärte Schmerzen ärztlich abklären lassen.

Bildimpuls: Muss die liegende Spirale jeden Tag neu angewendet werden?

**3B-Q1-Foerder** – Braucht man bei einer eingesetzten Kupferspirale jeden Tag eine Tablette?
- 1: Ja, sonst wirkt das Kupfer nicht. **(falsch)** – Du überträgst die Einnahmeregel der Pille auf die Spirale.
  - Hilfe 1: Lies im Informationsmaterial: Schutz im Alltag; Einsetzen und Entscheidung.
  - Hilfe 2: Lies „Schutz im Alltag“.
  - Hilfe 3: Wo bleibt die Spirale nach dem Einsetzen?
  - Hilfe 4: Das Einsetzen erfolgt in der Arztpraxis.
  - Hilfe 5: Passende Aussage: Nein. Sie wirkt über längere Zeit. Die Spirale liegt in der Gebärmutter; tägliche Tabletten sind nicht nötig.
- 2: Nein. Sie wirkt über längere Zeit. **(richtig)** – Die Spirale liegt in der Gebärmutter; tägliche Tabletten sind nicht nötig.
- Hilfen ohne Auswahl: Lies im Informationsmaterial: Schutz im Alltag; Einsetzen und Entscheidung. → Vergleiche die Aussagen mit dem beschriebenen biologischen Mechanismus. → Wo bleibt die Spirale nach dem Einsetzen? → Das Einsetzen erfolgt in der Arztpraxis. → Passende Aussage: Nein. Sie wirkt über längere Zeit. Die Spirale liegt in der Gebärmutter; tägliche Tabletten sind nicht nötig.
- **Nach Lösungshilfe:** Wer setzt die Kupferspirale in die Gebärmutter ein?
  - Die Person setzt sie jeden Morgen selbst ein. (falsch) – Das ist keine tägliche Anwendung. Schau auf das Bild der liegenden Spirale.
  - Eine Ärztin oder ein Arzt. (richtig) – Das Einsetzen und die Eignung gehören in die Arztpraxis.

**3B-Q2-Foerder** – Was kann sich mit der Kupferspirale verändern?
- 1: Regelschmerzen können stärker werden. **(richtig)** – Blutungen und Schmerzen können zunehmen, aber nicht bei jeder Person.
- 2: Regelschmerzen verschwinden immer. **(falsch)** – Du machst eine falsche sichere Vorhersage.
  - Hilfe 1: Lies im Informationsmaterial: Blutung und Regelschmerzen; Einsetzen und Entscheidung.
  - Hilfe 2: Lies die möglichen Auswirkungen auf die Regel.
  - Hilfe 3: Was bedeutet „können“?
  - Hilfe 4: Suche auf der Karte „stärker“ oder „schwächer“.
  - Hilfe 5: Passende Aussage: Regelschmerzen können stärker werden. Blutungen und Schmerzen können zunehmen, aber nicht bei jeder Person.
- Hilfen ohne Auswahl: Lies im Informationsmaterial: Blutung und Regelschmerzen; Einsetzen und Entscheidung. → Vergleiche die Aussagen mit dem beschriebenen biologischen Mechanismus. → Was bedeutet „können“? → Suche auf der Karte „stärker“ oder „schwächer“. → Passende Aussage: Regelschmerzen können stärker werden. Blutungen und Schmerzen können zunehmen, aber nicht bei jeder Person.
- **Nach Lösungshilfe:** Was ist bei starken Regelschmerzen ohne bekannte Ursache wichtig?
  - Sie immer ignorieren. (falsch) – Ungeklärte starke Schmerzen sollten nicht ignoriert werden. Lies den Hinweis am Kartenende.
  - Die Ursache in der Arztpraxis abklären lassen. (richtig) – Die Stärke und Ursache der Beschwerden müssen gesondert geklärt werden.

**Nach bestandener Prüfung – Papier:** Papier · 3B – Kupferspirale: Ergänze die Felder 3, 4 genau wie angezeigt. Vergleiche deine Einträge.
- Feld 3 (3B-3, Schutz im Alltag): **Tägliche Tabletten**
- Feld 4 (3B-4, Blutung und Regelschmerzen): **stärker**
Kein Code. Nach Vergleich „Weiter im Chat“.
Vergleich mit vollständiger Karte des eigenen Niveaus. Auf Papier „Karte kontrolliert“ markieren. Keine rückwirkende digitale Freigabe.
Nächstes Kapitel: 4A

## 4A – Hormonspirale: Hormon und Schutzwirkung

Informationsmaterial (auf dem iPad sichtbar, beim Antworten wieder aufrufbar):
- **Hormon und Schleim am Gebärmutterhals:** Die Spirale gibt ein Hormon ab. Der Schleim am Gebärmutterhals wird zäher. Spermien kommen schwerer hindurch.
- **Schutz vor Infektionen:** Der zähe Schleim schützt nicht vor STI.

Bildimpuls: Wo müssen die Spermien hindurch?

**4A-Q1-Foerder** – Was verändert das Hormon der Hormonspirale vor allem?
- 1: Den Schleim am Gebärmutterhals. **(richtig)** – Der Schleim wird zäher. Spermien kommen schwerer hindurch.
- 2: Das Material eines Kondoms. **(falsch)** – Du verwechselst die Methoden.
  - Hilfe 1: Lies im Informationsmaterial: Hormon und Schleim am Gebärmutterhals.
  - Hilfe 2: Die Spirale liegt in der Gebärmutter.
  - Hilfe 3: Welchen Weg müssen Spermien Richtung Gebärmutter nehmen?
  - Hilfe 4: Suche im Bild den Gebärmutterhals.
  - Hilfe 5: Passende Aussage: Den Schleim am Gebärmutterhals. Der Schleim wird zäher. Spermien kommen schwerer hindurch.
- Hilfen ohne Auswahl: Lies im Informationsmaterial: Hormon und Schleim am Gebärmutterhals. → Vergleiche die Aussagen mit dem beschriebenen biologischen Mechanismus. → Welchen Weg müssen Spermien Richtung Gebärmutter nehmen? → Suche im Bild den Gebärmutterhals. → Passende Aussage: Den Schleim am Gebärmutterhals. Der Schleim wird zäher. Spermien kommen schwerer hindurch.
- **Nach Lösungshilfe:** Der Schleim am Gebärmutterhals wird zäher. Was bedeutet das für Spermien?
  - Sie kommen schwerer hindurch. (richtig) – Der veränderte Schleim erschwert ihren Weg.
  - Sie kommen sicher schneller hindurch. (falsch) – Du deutest die Veränderung in die falsche Richtung. Denke an zähen Schleim.

**4A-Q2-Foerder** – Der Schleim wird zäher. Welche Aussage stimmt?
- 1: Spermien kommen schwerer hindurch. Alle STI werden verhindert. **(falsch)** – Du überträgst eine Wirkung auf Spermien auf Infektionen.
  - Hilfe 1: Lies im Informationsmaterial: Schutz vor Infektionen.
  - Hilfe 2: Lies „Schutz vor Infektionen“.
  - Hilfe 3: Sind Spermien und Krankheitserreger dasselbe?
  - Hilfe 4: Die Hormonspirale bildet beim Sex keine Kondomhülle.
  - Hilfe 5: Passende Aussage: Spermien kommen schwerer hindurch. STI-Schutz fehlt. Die Hormonspirale erschwert Spermien den Weg, schützt aber nicht vor STI.
- 2: Spermien kommen schwerer hindurch. STI-Schutz fehlt. **(richtig)** – Die Hormonspirale erschwert Spermien den Weg, schützt aber nicht vor STI.
- Hilfen ohne Auswahl: Lies im Informationsmaterial: Schutz vor Infektionen. → Vergleiche die Aussagen mit dem beschriebenen biologischen Mechanismus. → Sind Spermien und Krankheitserreger dasselbe? → Die Hormonspirale bildet beim Sex keine Kondomhülle. → Passende Aussage: Spermien kommen schwerer hindurch. STI-Schutz fehlt. Die Hormonspirale erschwert Spermien den Weg, schützt aber nicht vor STI.
- **Nach Lösungshilfe:** Spermien gelangen schwerer durch den Schleim. Was gilt trotzdem?
  - Alle STI werden verhindert. (falsch) – Das folgt nicht aus dem Mechanismus. Trenne die Schutzwirkungen.
  - Es besteht kein STI-Schutz durch die Hormonspirale. (richtig) – Spermienwirkung und Infektionsschutz sind verschieden.

**Nach bestandener Prüfung – Papier:** Papier · 4A – Hormonspirale: Ergänze die Felder 1, 2 genau wie angezeigt. Vergleiche deine Einträge.
- Feld 1 (4A-1, Hormon und Schleim am Gebärmutterhals): **zäher**
- Feld 2 (4A-2, Schutz vor Infektionen): **nicht**
Kein Code. Nach Vergleich „Weiter im Chat“.
Nächstes Kapitel: 4B

## 4B – Hormonspirale: Alltag und Einlage

Informationsmaterial (auf dem iPad sichtbar, beim Antworten wieder aufrufbar):
- **Schutz im Alltag:** Sie wirkt lange und sehr zuverlässig. Tägliche Tabletten sind nicht nötig. Die Lage wird in der Praxis kontrolliert.
- **Einsetzen und Entscheidung:** Die Spirale wird in der Arztpraxis in die Gebärmutter eingesetzt. Das kann wehtun. Vorher klären, ob sie passt. Die Person entscheidet selbst.
- **Blutung und Regelschmerzen:** Die Blutung kann unregelmäßig sein. Später können Blutungen und Schmerzen schwächer werden. Das ist nicht sicher. Starke ungeklärte Schmerzen ärztlich abklären lassen.

Bildimpuls: Woher kommt das Hormon jeden Tag?

**4B-Q1-Foerder** – Braucht man bei einer Hormonspirale täglich eine Tablette?
- 1: Nein. Die Spirale gibt lange ein Hormon ab. **(richtig)** – Nach dem Einsetzen wirkt die Spirale über längere Zeit.
- 2: Ja, weil jede hormonelle Methode täglich geschluckt wird. **(falsch)** – Du überträgst die Anwendung der Pille auf alle hormonellen Methoden.
  - Hilfe 1: Lies im Informationsmaterial: Schutz im Alltag; Einsetzen und Entscheidung.
  - Hilfe 2: Vergleiche Pille und liegende Spirale.
  - Hilfe 3: Wo bleibt die Spirale nach dem Einsetzen?
  - Hilfe 4: Das Hormon wird aus der Spirale abgegeben.
  - Hilfe 5: Passende Aussage: Nein. Die Spirale gibt lange ein Hormon ab. Nach dem Einsetzen wirkt die Spirale über längere Zeit.
- Hilfen ohne Auswahl: Lies im Informationsmaterial: Schutz im Alltag; Einsetzen und Entscheidung. → Vergleiche die Aussagen mit dem beschriebenen biologischen Mechanismus. → Wo bleibt die Spirale nach dem Einsetzen? → Das Hormon wird aus der Spirale abgegeben. → Passende Aussage: Nein. Die Spirale gibt lange ein Hormon ab. Nach dem Einsetzen wirkt die Spirale über längere Zeit.
- **Nach Lösungshilfe:** Wo wird die Hormonspirale eingesetzt?
  - In die Gebärmutter, in der Arztpraxis. (richtig) – Sie bleibt dort und gibt längerfristig ein Hormon ab.
  - Jeden Morgen selbst außerhalb des Körpers. (falsch) – Die Spirale ist keine tägliche äußerliche Methode. Sieh dir das Modell an.

**4B-Q2-Foerder** – Wie können sich Regelschmerzen mit der Hormonspirale verändern?
- 1: Sie verschwinden bei allen sicher. **(falsch)** – Du machst aus einer Möglichkeit eine Garantie.
  - Hilfe 1: Lies im Informationsmaterial: Blutung und Regelschmerzen; Einsetzen und Entscheidung.
  - Hilfe 2: Lies die Aussage zu Schmerzen noch einmal.
  - Hilfe 3: Was ist der Unterschied zwischen „kann“ und „immer“?
  - Hilfe 4: Die Karte beschreibt eine Möglichkeit, keine Garantie.
  - Hilfe 5: Passende Aussage: Sie können schwächer werden. Das ist nicht sicher. Blutungen können zunächst unregelmäßig sein; eine spätere Linderung ist möglich.
- 2: Sie können schwächer werden. Das ist nicht sicher. **(richtig)** – Blutungen können zunächst unregelmäßig sein; eine spätere Linderung ist möglich.
- Hilfen ohne Auswahl: Lies im Informationsmaterial: Blutung und Regelschmerzen; Einsetzen und Entscheidung. → Vergleiche die Aussagen mit dem beschriebenen biologischen Mechanismus. → Was ist der Unterschied zwischen „kann“ und „immer“? → Die Karte beschreibt eine Möglichkeit, keine Garantie. → Passende Aussage: Sie können schwächer werden. Das ist nicht sicher. Blutungen können zunächst unregelmäßig sein; eine spätere Linderung ist möglich.
- **Nach Lösungshilfe:** Kann eine Hormonspirale die Blutung verändern?
  - Ja, sie kann zunächst unregelmäßig sein und später schwächer werden. (richtig) – Diese möglichen Veränderungen sind individuell.
  - Nein, die Blutung bleibt immer genau gleich. (falsch) – Du schließt mögliche Veränderungen aus. Lies die Kartenstelle zur Blutung.

**Nach bestandener Prüfung – Papier:** Papier · 4B – Hormonspirale: Ergänze die Felder 3, 4 genau wie angezeigt. Vergleiche deine Einträge.
- Feld 3 (4B-3, Schutz im Alltag): **Tägliche Tabletten**
- Feld 4 (4B-4, Blutung und Regelschmerzen): **schwächer**
Kein Code. Nach Vergleich „Weiter im Chat“.
Vergleich mit vollständiger Karte des eigenen Niveaus. Auf Papier „Karte kontrolliert“ markieren. Keine rückwirkende digitale Freigabe.
Nächstes Kapitel: Abschluss; Karten vollständig prüfen.

# ESA

## Pearl-Index
Der Pearl-Index beschreibt Schwangerschaften pro 100 Frauen bei einjähriger Anwendung einer Methode. Im vereinfachten Beispiel ergeben drei Schwangerschaften bei 100 Frauen in einem Jahr den Wert 3. Je kleiner der Wert unter vergleichbaren Bedingungen, desto zuverlässiger der Schwangerschaftsschutz. Die Zahlen sind Richtwerte und hängen unter anderem von der Anwendung ab. Kein Maß für STI-Schutz.
**PI-Q1-ESA** – Was bedeutet ein Pearl-Index von 3 in einem vereinfachten Beispiel?
- 1: Bei jedem Sex werden 3 von 100 Frauen schwanger. **(falsch)** – Du verwechselst den Bezugszeitraum mit einem einzelnen Kontakt.
  - Hilfe 1: Lies im Informationsmaterial: Pearl-Index (Definition auf jeder Karte).
  - Hilfe 2: Lies die Definition auf der Karte.
  - Hilfe 3: Auf wie viele Frauen und welche Zeit bezieht sich das Beispiel?
  - Hilfe 4: Es geht nicht um drei Schwangerschaften pro Sexualkontakt.
  - Hilfe 5: Passende Aussage: Bei 100 Frauen, die ein Jahr so verhüten, treten im Mittel etwa 3 Schwangerschaften auf. Der Wert bezieht sich auf 100 Frauenjahre der Anwendung und ist ein statistischer Richtwert.
- 2: 3 von 100 Personen bekommen STI. **(falsch)** – Du verwechselst zwei Messgrößen.
  - Hilfe 1: Lies im Informationsmaterial: Pearl-Index (Definition auf jeder Karte).
  - Hilfe 2: Der Pearl-Index erfasst Schwangerschaften.
  - Hilfe 3: Auf wie viele Frauen und welche Zeit bezieht sich das Beispiel?
  - Hilfe 4: Es geht nicht um drei Schwangerschaften pro Sexualkontakt.
  - Hilfe 5: Passende Aussage: Bei 100 Frauen, die ein Jahr so verhüten, treten im Mittel etwa 3 Schwangerschaften auf. Der Wert bezieht sich auf 100 Frauenjahre der Anwendung und ist ein statistischer Richtwert.
- 3: Bei 100 Frauen, die ein Jahr so verhüten, treten im Mittel etwa 3 Schwangerschaften auf. **(richtig)** – Der Wert bezieht sich auf 100 Frauenjahre der Anwendung und ist ein statistischer Richtwert.
- Hilfen ohne Auswahl: Lies im Informationsmaterial: Pearl-Index (Definition auf jeder Karte). → Vergleiche die Aussagen mit dem beschriebenen biologischen Mechanismus. → Auf wie viele Frauen und welche Zeit bezieht sich das Beispiel? → Es geht nicht um drei Schwangerschaften pro Sexualkontakt. → Passende Aussage: Bei 100 Frauen, die ein Jahr so verhüten, treten im Mittel etwa 3 Schwangerschaften auf. Der Wert bezieht sich auf 100 Frauenjahre der Anwendung und ist ein statistischer Richtwert.
- **Nach Lösungshilfe:** Welche Zahl spricht unter vergleichbaren Bedingungen für weniger Schwangerschaften trotz Verhütung?
  - 2 statt 8. (richtig) – Ein kleinerer Pearl-Index steht für weniger Schwangerschaften bezogen auf die Anwendungszeit.
  - 8 statt 2. (falsch) – Die Richtung ist vertauscht. Vergleiche die kleinere mit der größeren Zahl.

## 1A – Kondom: Material und Barriere

Informationsmaterial (auf dem iPad sichtbar, beim Antworten wieder aufrufbar):
- **Material und Allergie:** Geeignete synthetische Kondome, z. B. aus Polyurethan, gibt es ohne Latex. Material und Eignung stehen auf der Packung.
- **Barriere und Schwangerschaft:** Das Kondom fängt Sperma auf. Die intakte, richtig sitzende Hülle hält Spermien zurück. Es wirkt ohne Hormone.

Bildimpuls: Vergleiche die beiden Materialien und die Hüllenfunktion.

**1A-Q1-ESA** – Auf einer Kondompackung steht „Polyurethan, zur Verhütung geeignet“. Welche Aussage passt?
- 1: Polyurethan ist ein anderes Wort für Latex. **(falsch)** – Du verwechselst die Materialien.
  - Hilfe 1: Lies im Informationsmaterial: Material und Allergie.
  - Hilfe 2: Prüfe die Beispiele in „Material und Allergie“.
  - Hilfe 3: Wofür ist das Material der Hülle wichtig?
  - Hilfe 4: Vergleiche das Wort „Latex“ mit „Polyurethan“ und beachte die Zweckangabe.
  - Hilfe 5: Passende Aussage: Das Kondom kann eine geeignete latexfreie Barriere sein. Polyurethan ist ein synthetisches Material; die Eignung zur Verhütung ist wichtig.
- 2: Ein Kondom ohne Latex kann keine Schwangerschaft verhindern. **(falsch)** – Du verwechselst Material und Wirkprinzip.
  - Hilfe 1: Lies im Informationsmaterial: Material und Allergie.
  - Hilfe 2: Überlege, ob auch eine andere geeignete Hülle dicht sein kann.
  - Hilfe 3: Wofür ist das Material der Hülle wichtig?
  - Hilfe 4: Vergleiche das Wort „Latex“ mit „Polyurethan“ und beachte die Zweckangabe.
  - Hilfe 5: Passende Aussage: Das Kondom kann eine geeignete latexfreie Barriere sein. Polyurethan ist ein synthetisches Material; die Eignung zur Verhütung ist wichtig.
- 3: Das Kondom kann eine geeignete latexfreie Barriere sein. **(richtig)** – Polyurethan ist ein synthetisches Material; die Eignung zur Verhütung ist wichtig.
- Hilfen ohne Auswahl: Lies im Informationsmaterial: Material und Allergie. → Vergleiche die Aussagen mit dem beschriebenen biologischen Mechanismus. → Wofür ist das Material der Hülle wichtig? → Vergleiche das Wort „Latex“ mit „Polyurethan“ und beachte die Zweckangabe. → Passende Aussage: Das Kondom kann eine geeignete latexfreie Barriere sein. Polyurethan ist ein synthetisches Material; die Eignung zur Verhütung ist wichtig.
- **Nach Lösungshilfe:** Auf einer anderen Packung steht „Kunststoff, latexfrei, zur Verhütung geeignet“. Was ist möglich?
  - Ein geeignetes Kondom ohne Latex. (richtig) – Die Packung nennt das latexfreie Material und die Eignung zur Verhütung.
  - Nur ein Latexkondom. (falsch) – Prüfe den Stoffnamen. „Latexfrei“ bedeutet ohne Latex.

**1A-Q2-ESA** – Ein Kondom bleibt heil und sitzt richtig. Warum kann es eine Schwangerschaft verhindern?
- 1: Die Hülle verhindert, dass Sperma in die Scheide gelangt. **(richtig)** – Eine mechanische Barriere hält Sperma zurück.
- 2: Es verhindert durch Hormone den Eisprung. **(falsch)** – Du beschreibst eine hormonelle Methode.
  - Hilfe 1: Lies im Informationsmaterial: Barriere und Schwangerschaft.
  - Hilfe 2: Ein Kondom wirkt durch seine Hülle, nicht durch Hormone.
  - Hilfe 3: Was müsste zuerst passieren, damit Spermien zur Eizelle gelangen?
  - Hilfe 4: Die Methode verändert den Zyklus nicht.
  - Hilfe 5: Passende Aussage: Die Hülle verhindert, dass Sperma in die Scheide gelangt. Eine mechanische Barriere hält Sperma zurück.
- 3: Es macht Spermien im Körper unbeweglich. **(falsch)** – Du verwechselst das Zurückhalten mit einer Wirkung auf Spermien.
  - Hilfe 1: Lies im Informationsmaterial: Barriere und Schwangerschaft.
  - Hilfe 2: Wo befindet sich das Sperma bei intakter Hülle?
  - Hilfe 3: Was müsste zuerst passieren, damit Spermien zur Eizelle gelangen?
  - Hilfe 4: Die Methode verändert den Zyklus nicht.
  - Hilfe 5: Passende Aussage: Die Hülle verhindert, dass Sperma in die Scheide gelangt. Eine mechanische Barriere hält Sperma zurück.
- Hilfen ohne Auswahl: Lies im Informationsmaterial: Barriere und Schwangerschaft. → Vergleiche die Aussagen mit dem beschriebenen biologischen Mechanismus. → Was müsste zuerst passieren, damit Spermien zur Eizelle gelangen? → Die Methode verändert den Zyklus nicht. → Passende Aussage: Die Hülle verhindert, dass Sperma in die Scheide gelangt. Eine mechanische Barriere hält Sperma zurück.
- **Nach Lösungshilfe:** Eine Hülle bekommt ein Loch. Was kann dann passieren?
  - Sperma kann aus der Hülle gelangen. (richtig) – Die Barriere ist nicht mehr intakt.
  - Die Eizelle wird dadurch im Eierstock festgehalten. (falsch) – Das Kondom verändert den Eierstock nicht. Denke an das Loch in der Hülle.

**Nach bestandener Prüfung – Papier:** Papier · 1A – Kondom: Ergänze die Felder 1, 2 genau wie angezeigt. Vergleiche deine Einträge.
- Feld 1 (1A-1, Material und Allergie): **ohne Latex**
- Feld 2 (1A-2, Barriere und Schwangerschaft): **Spermien**
Kein Code. Nach Vergleich „Weiter im Chat“.
Nächstes Kapitel: 1B

## 1B – Kondom: Schutz und Alltag

Informationsmaterial (auf dem iPad sichtbar, beim Antworten wieder aufrufbar):
- **Schutz vor Infektionen:** Die Barriere senkt das Risiko vieler sexuell übertragbarer Infektionen (STI). Ein Restrisiko bleibt: Nicht die ganze Haut ist bedeckt. Naturmembran ist dafür nicht gleichwertig.
- **Bei jedem Sex:** Bei jedem Sex von Anfang an ein neues Kondom richtig benutzen. Reißen oder Abrutschen mindert den Schutz.
- **Regelschmerzen:** Das Kondom verändert die Regel nicht. Starke, ungeklärte Regelschmerzen ärztlich abklären lassen.

Bildimpuls: Warum bleibt ein Risiko bestehen?

**1B-Q1-ESA** – Warum bleibt trotz richtig benutztem Kondom ein STI-Risiko?
- 1: Das Kondom verhindert nur den Eisprung. **(falsch)** – Du beschreibst eine andere Verhütungsmethode.
  - Hilfe 1: Lies im Informationsmaterial: Schutz vor Infektionen.
  - Hilfe 2: Das Kondom wirkt als Hülle gegen Kontakt.
  - Hilfe 3: Welche Körperstellen liegen außerhalb der Barriere?
  - Hilfe 4: Nicht jede STI wird ausschließlich über Sperma übertragen.
  - Hilfe 5: Passende Aussage: Ein Teil der Haut bleibt unbedeckt. Viele Erregerübertragungen werden erschwert, aber nicht alle Übertragungswege sind abgedeckt.
- 2: Es bleibt kein Risiko, wenn es heil ist. **(falsch)** – Auch die intakte Hülle bedeckt nicht die gesamte Haut.
  - Hilfe 1: Lies im Informationsmaterial: Schutz vor Infektionen.
  - Hilfe 2: Prüfe die räumliche Grenze der Barriere.
  - Hilfe 3: Welche Körperstellen liegen außerhalb der Barriere?
  - Hilfe 4: Nicht jede STI wird ausschließlich über Sperma übertragen.
  - Hilfe 5: Passende Aussage: Ein Teil der Haut bleibt unbedeckt. Viele Erregerübertragungen werden erschwert, aber nicht alle Übertragungswege sind abgedeckt.
- 3: Ein Teil der Haut bleibt unbedeckt. **(richtig)** – Viele Erregerübertragungen werden erschwert, aber nicht alle Übertragungswege sind abgedeckt.
- Hilfen ohne Auswahl: Lies im Informationsmaterial: Schutz vor Infektionen. → Vergleiche die Aussagen mit dem beschriebenen biologischen Mechanismus. → Welche Körperstellen liegen außerhalb der Barriere? → Nicht jede STI wird ausschließlich über Sperma übertragen. → Passende Aussage: Ein Teil der Haut bleibt unbedeckt. Viele Erregerübertragungen werden erschwert, aber nicht alle Übertragungswege sind abgedeckt.
- **Nach Lösungshilfe:** Warum kann trotz Kondom eine Infektion möglich sein?
  - Ein Teil der Haut bleibt frei. (richtig) – Die Barriere ist räumlich begrenzt.
  - Weil Kondome immer den Eisprung auslösen. (falsch) – Das ist keine Kondomwirkung. Lies die Stelle zum Infektionsschutz.

**1B-Q2-ESA** – Was verändert sich, wenn ein Kondom erst spät angelegt wird?
- 1: Es beeinflusst dadurch die nächste Regelblutung. **(falsch)** – Du verwechselst Anwendung und Wirkung auf den Zyklus.
  - Hilfe 1: Lies im Informationsmaterial: Bei jedem Sex; Regelschmerzen.
  - Hilfe 2: Das Kondom verändert die Regel nicht.
  - Hilfe 3: Kann vor dem Anlegen schon ein Kontakt stattgefunden haben?
  - Hilfe 4: Die Schutzwirkung beginnt erst mit der Barriere.
  - Hilfe 5: Passende Aussage: Der Schutz ist beeinträchtigt, weil vorher bereits Kontakt möglich ist. Für die Schutzwirkung ist die korrekte Anwendung von Anfang an wichtig.
- 2: Der Schutz ist beeinträchtigt, weil vorher bereits Kontakt möglich ist. **(richtig)** – Für die Schutzwirkung ist die korrekte Anwendung von Anfang an wichtig.
- 3: Es schützt genauso sicher wie von Anfang an. **(falsch)** – Du übersiehst den vorherigen Kontakt.
  - Hilfe 1: Lies im Informationsmaterial: Bei jedem Sex; Regelschmerzen.
  - Hilfe 2: Vergleiche Anfang und Ende der Anwendung.
  - Hilfe 3: Kann vor dem Anlegen schon ein Kontakt stattgefunden haben?
  - Hilfe 4: Die Schutzwirkung beginnt erst mit der Barriere.
  - Hilfe 5: Passende Aussage: Der Schutz ist beeinträchtigt, weil vorher bereits Kontakt möglich ist. Für die Schutzwirkung ist die korrekte Anwendung von Anfang an wichtig.
- Hilfen ohne Auswahl: Lies im Informationsmaterial: Bei jedem Sex; Regelschmerzen. → Vergleiche die Aussagen mit dem beschriebenen biologischen Mechanismus. → Kann vor dem Anlegen schon ein Kontakt stattgefunden haben? → Die Schutzwirkung beginnt erst mit der Barriere. → Passende Aussage: Der Schutz ist beeinträchtigt, weil vorher bereits Kontakt möglich ist. Für die Schutzwirkung ist die korrekte Anwendung von Anfang an wichtig.
- **Nach Lösungshilfe:** Ein Kondom wurde richtig angelegt, rutscht aber ab. Was gilt?
  - Der Schutz bleibt sicher gleich. (falsch) – Der Sitz ist verändert. Denke an die Voraussetzung für die Barriere.
  - Der Schutz kann geringer sein. (richtig) – Die Hülle sitzt nicht mehr richtig.

**Nach bestandener Prüfung – Papier:** Papier · 1B – Kondom: Ergänze die Felder 3, 4 genau wie angezeigt. Vergleiche deine Einträge.
- Feld 3 (1B-3, Schutz vor Infektionen): **Restrisiko**
- Feld 4 (1B-4, Bei jedem Sex): **von Anfang an**
Kein Code. Nach Vergleich „Weiter im Chat“.
Vergleich mit vollständiger Karte des eigenen Niveaus. Auf Papier „Karte kontrolliert“ markieren. Keine rückwirkende digitale Freigabe.
Nächstes Kapitel: 2A

## 2A – Kombinationspille: Hormone und Schutzwirkung

Informationsmaterial (auf dem iPad sichtbar, beim Antworten wieder aufrufbar):
- **Hormone und Eisprung:** Östrogen und Gestagen verhindern vor allem den Eisprung. Ohne Eisprung kann keine Eizelle befruchtet werden.
- **Schutz vor Infektionen:** Die Pille wirkt auf den Zyklus. Sie bildet keine Barriere gegen Krankheitserreger: kein STI-Schutz.

Ergänzender kurzer Fachhinweis: Die Pillenwirkung setzt die korrekte Anwendung nach Einnahmeplan voraus. Dazu folgt 2B.

Bildimpuls: Vergleiche den Weg der Eizelle in beiden Bildern.

**2A-Q1-ESA** – Warum kann ohne Eisprung keine Eizelle befruchtet werden?
- 1: Die Gebärmutter wird mechanisch verschlossen. **(falsch)** – Du beschreibst einen Verschluss, den die Pille nicht bewirkt.
  - Hilfe 1: Lies im Informationsmaterial: Hormone und Eisprung.
  - Hilfe 2: Schau auf den Weg der Eizelle.
  - Hilfe 3: Wo müsste die Eizelle für eine Befruchtung sein?
  - Hilfe 4: Ohne Freisetzung fehlt die Eizelle im Eileiter.
  - Hilfe 5: Passende Aussage: Es wird keine Eizelle aus dem Eierstock freigesetzt. Die Hormone der Kombinationspille hemmen vor allem den Eisprung.
- 2: Es wird keine Eizelle aus dem Eierstock freigesetzt. **(richtig)** – Die Hormone der Kombinationspille hemmen vor allem den Eisprung.
- 3: Spermien werden schon außerhalb des Körpers aufgefangen. **(falsch)** – Das ist eine mechanische Barriere.
  - Hilfe 1: Lies im Informationsmaterial: Hormone und Eisprung.
  - Hilfe 2: Die Pille verändert den Zyklus.
  - Hilfe 3: Wo müsste die Eizelle für eine Befruchtung sein?
  - Hilfe 4: Ohne Freisetzung fehlt die Eizelle im Eileiter.
  - Hilfe 5: Passende Aussage: Es wird keine Eizelle aus dem Eierstock freigesetzt. Die Hormone der Kombinationspille hemmen vor allem den Eisprung.
- Hilfen ohne Auswahl: Lies im Informationsmaterial: Hormone und Eisprung. → Vergleiche die Aussagen mit dem beschriebenen biologischen Mechanismus. → Wo müsste die Eizelle für eine Befruchtung sein? → Ohne Freisetzung fehlt die Eizelle im Eileiter. → Passende Aussage: Es wird keine Eizelle aus dem Eierstock freigesetzt. Die Hormone der Kombinationspille hemmen vor allem den Eisprung.
- **Nach Lösungshilfe:** Welche Folge hat ein unterdrückter Eisprung?
  - Es wird keine Eizelle zur Befruchtung freigesetzt. (richtig) – Die Eizelle bleibt für die Befruchtung in diesem Zyklus nicht verfügbar.
  - Ein Kondom bildet sich im Körper. (falsch) – Die Pille bildet keine Hülle. Denke an die Eizelle.

**2A-Q2-ESA** – Warum schützt die Pille nicht vor STI?
- 1: Sie verändert den Zyklus, bildet aber keine Barriere gegen Erreger. **(richtig)** – Der Eisprung und die Übertragung von Krankheitserregern sind verschiedene biologische Vorgänge.
- 2: Weil die Pille keine Schwangerschaft verhindern kann. **(falsch)** – Die Pille kann Schwangerschaften verhindern.
  - Hilfe 1: Lies im Informationsmaterial: Schutz vor Infektionen.
  - Hilfe 2: Prüfe getrennt den Infektionsschutz.
  - Hilfe 3: Braucht eine Infektion eine Eizelle?
  - Hilfe 4: Vergleiche den Wirkungsort mit einer mechanischen Hülle.
  - Hilfe 5: Passende Aussage: Sie verändert den Zyklus, bildet aber keine Barriere gegen Erreger. Der Eisprung und die Übertragung von Krankheitserregern sind verschiedene biologische Vorgänge.
- 3: Sie schützt nur dann vor STI, wenn sie regelmäßig genommen wird. **(falsch)** – Du überträgst die Einnahmeregel auf ein anderes Schutzziel.
  - Hilfe 1: Lies im Informationsmaterial: Schutz vor Infektionen.
  - Hilfe 2: Regelmäßige Einnahme verbessert nicht die Erregerbarriere.
  - Hilfe 3: Braucht eine Infektion eine Eizelle?
  - Hilfe 4: Vergleiche den Wirkungsort mit einer mechanischen Hülle.
  - Hilfe 5: Passende Aussage: Sie verändert den Zyklus, bildet aber keine Barriere gegen Erreger. Der Eisprung und die Übertragung von Krankheitserregern sind verschiedene biologische Vorgänge.
- Hilfen ohne Auswahl: Lies im Informationsmaterial: Schutz vor Infektionen. → Vergleiche die Aussagen mit dem beschriebenen biologischen Mechanismus. → Braucht eine Infektion eine Eizelle? → Vergleiche den Wirkungsort mit einer mechanischen Hülle. → Passende Aussage: Sie verändert den Zyklus, bildet aber keine Barriere gegen Erreger. Der Eisprung und die Übertragung von Krankheitserregern sind verschiedene biologische Vorgänge.
- **Nach Lösungshilfe:** Die Pille wird nach Plan genommen. Was gilt trotzdem?
  - Sie schützt nicht vor STI. (richtig) – Die regelmäßige Einnahme schafft keine Erregerbarriere.
  - Alle Infektionen werden verhindert. (falsch) – Das Schutzziel ist falsch übertragen. Denke an den Wirkungsort.

**Nach bestandener Prüfung – Papier:** Papier · 2A – Kombinationspille: Ergänze die Felder 1, 2 genau wie angezeigt. Vergleiche deine Einträge.
- Feld 1 (2A-1, Hormone und Eisprung): **Eisprung**
- Feld 2 (2A-2, Schutz vor Infektionen): **kein STI-Schutz**
Kein Code. Nach Vergleich „Weiter im Chat“.
Nächstes Kapitel: 2B

## 2B – Kombinationspille: Anwendung und Verträglichkeit

Informationsmaterial (auf dem iPad sichtbar, beim Antworten wieder aufrufbar):
- **Regelmäßige Einnahme:** Die Tabletten regelmäßig nach Einnahmeplan nehmen. Vergessen kann den Schwangerschaftsschutz mindern.
- **Persönliche Verträglichkeit:** Übelkeit und andere Beschwerden sind möglich. Menschen vertragen die Pille unterschiedlich. Die ärztliche Beratung klärt die Eignung.
- **Blutung und Regelschmerzen:** Blutungen und Regelschmerzen können schwächer werden, aber nicht bei allen. Starke, ungeklärte Schmerzen ärztlich abklären lassen.

Bildimpuls: Was ist der Unterschied zwischen den Einnahmefolgen?

**2B-Q1-ESA** – Was kann passieren, wenn Tabletten vergessen werden?
- 1: Die Pille schützt dann besser vor STI. **(falsch)** – Die Pille bietet unabhängig von der Einnahme keinen STI-Schutz.
  - Hilfe 1: Lies im Informationsmaterial: Regelmäßige Einnahme.
  - Hilfe 2: Trenne das Anwendungsproblem von den Schutzzielen.
  - Hilfe 3: Welche Voraussetzung für die Hormonwirkung kann wegfallen?
  - Hilfe 4: Vergessen bedeutet eine Abweichung vom Plan.
  - Hilfe 5: Passende Aussage: Der Schwangerschaftsschutz kann geringer werden. Die Wirkung ist an die korrekte Anwendung nach Einnahmeplan gebunden.
- 2: Der Schutz bleibt unabhängig von der Einnahme immer gleich. **(falsch)** – Du ignorierst die Anwendungsvoraussetzung.
  - Hilfe 1: Lies im Informationsmaterial: Regelmäßige Einnahme.
  - Hilfe 2: Vergleiche regelmäßige und vergessene Einnahme.
  - Hilfe 3: Welche Voraussetzung für die Hormonwirkung kann wegfallen?
  - Hilfe 4: Vergessen bedeutet eine Abweichung vom Plan.
  - Hilfe 5: Passende Aussage: Der Schwangerschaftsschutz kann geringer werden. Die Wirkung ist an die korrekte Anwendung nach Einnahmeplan gebunden.
- 3: Der Schwangerschaftsschutz kann geringer werden. **(richtig)** – Die Wirkung ist an die korrekte Anwendung nach Einnahmeplan gebunden.
- Hilfen ohne Auswahl: Lies im Informationsmaterial: Regelmäßige Einnahme. → Vergleiche die Aussagen mit dem beschriebenen biologischen Mechanismus. → Welche Voraussetzung für die Hormonwirkung kann wegfallen? → Vergessen bedeutet eine Abweichung vom Plan. → Passende Aussage: Der Schwangerschaftsschutz kann geringer werden. Die Wirkung ist an die korrekte Anwendung nach Einnahmeplan gebunden.
- **Nach Lösungshilfe:** Was muss bei der Pille beachtet werden?
  - Der Einnahmeplan. (richtig) – Regelmäßige Einnahme ist wichtig für den Schutz.
  - Sie muss nur beim Sex angelegt werden. (falsch) – Du beschreibst eine andere Methode. Die Pille wird eingenommen.

**2B-Q2-ESA** – Welche Aussage zu Beschwerden und Regelschmerzen ist richtig?
- 1: Die Pille kann Beschwerden verursachen oder Regelschmerzen lindern; das ist individuell. **(richtig)** – Mögliche Nebenwirkungen und mögliche Linderung sind keine sicheren Vorhersagen. Starke ungeklärte Schmerzen gehören in die Arztpraxis.
- 2: Wenn eine Person Übelkeit hat, passiert das bei allen. **(falsch)** – Eine einzelne Erfahrung ist keine allgemeine Vorhersage.
  - Hilfe 1: Lies im Informationsmaterial: Persönliche Verträglichkeit; Blutung und Regelschmerzen.
  - Hilfe 2: Prüfe „Persönliche Verträglichkeit“.
  - Hilfe 3: Was bedeutet in der Information das Wort „können“?
  - Hilfe 4: Unterscheide Möglichkeit und Gewissheit.
  - Hilfe 5: Passende Aussage: Die Pille kann Beschwerden verursachen oder Regelschmerzen lindern; das ist individuell. Mögliche Nebenwirkungen und mögliche Linderung sind keine sicheren Vorhersagen. Starke ungeklärte Schmerzen gehören in die Arztpraxis.
- 3: Mit der Pille verschwinden Regelschmerzen garantiert. **(falsch)** – Du machst aus einer möglichen Linderung eine Garantie.
  - Hilfe 1: Lies im Informationsmaterial: Persönliche Verträglichkeit; Blutung und Regelschmerzen.
  - Hilfe 2: Vergleiche „können“ und „immer“.
  - Hilfe 3: Was bedeutet in der Information das Wort „können“?
  - Hilfe 4: Unterscheide Möglichkeit und Gewissheit.
  - Hilfe 5: Passende Aussage: Die Pille kann Beschwerden verursachen oder Regelschmerzen lindern; das ist individuell. Mögliche Nebenwirkungen und mögliche Linderung sind keine sicheren Vorhersagen. Starke ungeklärte Schmerzen gehören in die Arztpraxis.
- Hilfen ohne Auswahl: Lies im Informationsmaterial: Persönliche Verträglichkeit; Blutung und Regelschmerzen. → Vergleiche die Aussagen mit dem beschriebenen biologischen Mechanismus. → Was bedeutet in der Information das Wort „können“? → Unterscheide Möglichkeit und Gewissheit. → Passende Aussage: Die Pille kann Beschwerden verursachen oder Regelschmerzen lindern; das ist individuell. Mögliche Nebenwirkungen und mögliche Linderung sind keine sicheren Vorhersagen. Starke ungeklärte Schmerzen gehören in die Arztpraxis.
- **Nach Lösungshilfe:** Mit der Pille können Regelschmerzen schwächer werden. Ist das sicher?
  - Nein, Menschen reagieren unterschiedlich. (richtig) – Eine mögliche Linderung ist keine Garantie.
  - Ja, bei allen Personen. (falsch) – Du machst aus „können“ ein „immer“. Vergleiche die Begriffe.

**Nach bestandener Prüfung – Papier:** Papier · 2B – Kombinationspille: Ergänze die Felder 3, 4 genau wie angezeigt. Vergleiche deine Einträge.
- Feld 3 (2B-3, Regelmäßige Einnahme): **regelmäßig**
- Feld 4 (2B-4, Persönliche Verträglichkeit): **unterschiedlich**
Kein Code. Nach Vergleich „Weiter im Chat“.
Vergleich mit vollständiger Karte des eigenen Niveaus. Auf Papier „Karte kontrolliert“ markieren. Keine rückwirkende digitale Freigabe.
Nächstes Kapitel: 3A

## 3A – Kupferspirale: Kupfer und Schutzwirkung

Informationsmaterial (auf dem iPad sichtbar, beim Antworten wieder aufrufbar):
- **Kupfer und Spermien:** Kupfer beeinträchtigt die Beweglichkeit und Befruchtungsfähigkeit der Spermien. Die Spirale enthält keine Hormone.
- **Schutz vor Infektionen:** Kupfer wirkt auf Spermien, bildet aber keine Barriere gegen Krankheitserreger: kein STI-Schutz.

Ergänzender kurzer Fachhinweis: Hormonfreiheit sagt nicht, ob Regelschmerzen auftreten oder sich verändern. Mehr dazu in 3B.

Bildimpuls: Worauf wirkt das Kupfer?

**3A-Q1-ESA** – Wie kann Kupfer eine Befruchtung erschweren?
- 1: Es verschließt die Gebärmutter wie ein Deckel. **(falsch)** – Die Spirale bildet keinen solchen Verschluss.
  - Hilfe 1: Lies im Informationsmaterial: Kupfer und Spermien.
  - Hilfe 2: Betrachte das Bild der liegenden Spirale.
  - Hilfe 3: Welche Fähigkeiten brauchen Spermien für eine Befruchtung?
  - Hilfe 4: Die Kupferspirale gibt keine Hormone ab.
  - Hilfe 5: Passende Aussage: Spermien bewegen sich schlechter und können schlechter befruchten. Kupfer beeinträchtigt die Beweglichkeit und Befruchtungsfähigkeit der Spermien.
- 2: Spermien bewegen sich schlechter und können schlechter befruchten. **(richtig)** – Kupfer beeinträchtigt die Beweglichkeit und Befruchtungsfähigkeit der Spermien.
- 3: Es verhindert den Eisprung mit Östrogen. **(falsch)** – Du verwechselst die Kupferspirale mit der Pille.
  - Hilfe 1: Lies im Informationsmaterial: Kupfer und Spermien.
  - Hilfe 2: Lies, welche Zellen von Kupfer betroffen sind.
  - Hilfe 3: Welche Fähigkeiten brauchen Spermien für eine Befruchtung?
  - Hilfe 4: Die Kupferspirale gibt keine Hormone ab.
  - Hilfe 5: Passende Aussage: Spermien bewegen sich schlechter und können schlechter befruchten. Kupfer beeinträchtigt die Beweglichkeit und Befruchtungsfähigkeit der Spermien.
- Hilfen ohne Auswahl: Lies im Informationsmaterial: Kupfer und Spermien. → Vergleiche die Aussagen mit dem beschriebenen biologischen Mechanismus. → Welche Fähigkeiten brauchen Spermien für eine Befruchtung? → Die Kupferspirale gibt keine Hormone ab. → Passende Aussage: Spermien bewegen sich schlechter und können schlechter befruchten. Kupfer beeinträchtigt die Beweglichkeit und Befruchtungsfähigkeit der Spermien.
- **Nach Lösungshilfe:** Welche Folge kann die Kupferwirkung haben?
  - Spermien können schlechter eine Eizelle befruchten. (richtig) – Kupfer beeinträchtigt ihre Befruchtungsfähigkeit.
  - Die Spirale gibt Östrogen ab. (falsch) – Kupfer ist kein Hormon. Betrachte die betroffenen Spermien.

**3A-Q2-ESA** – Warum schützt die Kupferspirale nicht vor STI?
- 1: Kupfer verhindert jede Infektion, weil es Spermien hemmt. **(falsch)** – Du überträgst eine Wirkung auf Spermien auf Erreger.
  - Hilfe 1: Lies im Informationsmaterial: Schutz vor Infektionen.
  - Hilfe 2: Unterscheide die beiden biologischen Ziele.
  - Hilfe 3: Welche Organismen oder Zellen werden beim Wirkprinzip genannt?
  - Hilfe 4: Die Spirale verhindert keinen Körperkontakt beim Sex.
  - Hilfe 5: Passende Aussage: Ihre Wirkung auf Spermien ist keine Barriere gegen Krankheitserreger. Eine beeinträchtigte Befruchtungsfähigkeit bedeutet keinen Schutz vor Erregerübertragung.
- 2: Eine hormonfreie Methode schützt immer vor STI. **(falsch)** – Hormonfreiheit belegt keinen Infektionsschutz.
  - Hilfe 1: Lies im Informationsmaterial: Schutz vor Infektionen.
  - Hilfe 2: Prüfe, ob eine geeignete Erregerbarriere vorliegt.
  - Hilfe 3: Welche Organismen oder Zellen werden beim Wirkprinzip genannt?
  - Hilfe 4: Die Spirale verhindert keinen Körperkontakt beim Sex.
  - Hilfe 5: Passende Aussage: Ihre Wirkung auf Spermien ist keine Barriere gegen Krankheitserreger. Eine beeinträchtigte Befruchtungsfähigkeit bedeutet keinen Schutz vor Erregerübertragung.
- 3: Ihre Wirkung auf Spermien ist keine Barriere gegen Krankheitserreger. **(richtig)** – Eine beeinträchtigte Befruchtungsfähigkeit bedeutet keinen Schutz vor Erregerübertragung.
- Hilfen ohne Auswahl: Lies im Informationsmaterial: Schutz vor Infektionen. → Vergleiche die Aussagen mit dem beschriebenen biologischen Mechanismus. → Welche Organismen oder Zellen werden beim Wirkprinzip genannt? → Die Spirale verhindert keinen Körperkontakt beim Sex. → Passende Aussage: Ihre Wirkung auf Spermien ist keine Barriere gegen Krankheitserreger. Eine beeinträchtigte Befruchtungsfähigkeit bedeutet keinen Schutz vor Erregerübertragung.
- **Nach Lösungshilfe:** Kupfer stört Spermien. Was gilt für STI?
  - Sie verhindert dadurch jede STI. (falsch) – Erregerübertragung ist ein anderer Vorgang. Trenne die beiden Ziele.
  - Die Kupferspirale schützt nicht vor STI. (richtig) – Spermienwirkung ist keine Erregerbarriere.

**Nach bestandener Prüfung – Papier:** Papier · 3A – Kupferspirale: Ergänze die Felder 1, 2 genau wie angezeigt. Vergleiche deine Einträge.
- Feld 1 (3A-1, Kupfer und Spermien): **Befruchtungsfähigkeit**
- Feld 2 (3A-2, Schutz vor Infektionen): **kein STI-Schutz**
Kein Code. Nach Vergleich „Weiter im Chat“.
Nächstes Kapitel: 3B

## 3B – Kupferspirale: Alltag und Einlage

Informationsmaterial (auf dem iPad sichtbar, beim Antworten wieder aufrufbar):
- **Schutz im Alltag:** Längerfristiger, sehr zuverlässiger Schwangerschaftsschutz ohne tägliche Einnahme. Dauer je nach Modell; Lagekontrolle in der Praxis.
- **Einsetzen und Entscheidung:** Ärztliches Einsetzen in die Gebärmutter. Das kann wehtun. Eignung und persönliche Zustimmung vorher klären.
- **Blutung und Regelschmerzen:** Blutungen und Regelschmerzen können stärker werden. Starke, ungeklärte Regelschmerzen ärztlich abklären lassen.

Bildimpuls: Was muss vor dem Einsetzen geklärt werden?

**3B-Q1-ESA** – Welche Beschreibung der Anwendung stimmt?
- 1: Sie wird ärztlich eingesetzt und wirkt lange ohne tägliche Einnahme. **(richtig)** – Die liegende Spirale wirkt über längere Zeit; medizinische Eignung, Zustimmung und Lagekontrolle gehören dazu.
- 2: Man setzt sie vor jedem Sex selbst ein. **(falsch)** – Du verwechselst die Langzeitmethode mit einer Methode für jeden Sexualkontakt.
  - Hilfe 1: Lies im Informationsmaterial: Schutz im Alltag; Einsetzen und Entscheidung.
  - Hilfe 2: Betrachte den Ort und das ärztliche Einsetzen.
  - Hilfe 3: Was geschieht beim Einsetzen und was danach?
  - Hilfe 4: Eine Spirale ist kein täglich einzunehmendes Mittel.
  - Hilfe 5: Passende Aussage: Sie wird ärztlich eingesetzt und wirkt lange ohne tägliche Einnahme. Die liegende Spirale wirkt über längere Zeit; medizinische Eignung, Zustimmung und Lagekontrolle gehören dazu.
- 3: Kupfer muss jeden Tag als Tablette ergänzt werden. **(falsch)** – Du überträgst die Pillenanwendung auf die Spirale.
  - Hilfe 1: Lies im Informationsmaterial: Schutz im Alltag; Einsetzen und Entscheidung.
  - Hilfe 2: Die Kupferspirale bleibt in der Gebärmutter.
  - Hilfe 3: Was geschieht beim Einsetzen und was danach?
  - Hilfe 4: Eine Spirale ist kein täglich einzunehmendes Mittel.
  - Hilfe 5: Passende Aussage: Sie wird ärztlich eingesetzt und wirkt lange ohne tägliche Einnahme. Die liegende Spirale wirkt über längere Zeit; medizinische Eignung, Zustimmung und Lagekontrolle gehören dazu.
- Hilfen ohne Auswahl: Lies im Informationsmaterial: Schutz im Alltag; Einsetzen und Entscheidung. → Vergleiche die Aussagen mit dem beschriebenen biologischen Mechanismus. → Was geschieht beim Einsetzen und was danach? → Eine Spirale ist kein täglich einzunehmendes Mittel. → Passende Aussage: Sie wird ärztlich eingesetzt und wirkt lange ohne tägliche Einnahme. Die liegende Spirale wirkt über längere Zeit; medizinische Eignung, Zustimmung und Lagekontrolle gehören dazu.
- **Nach Lösungshilfe:** Wer setzt die Kupferspirale in die Gebärmutter ein?
  - Eine Ärztin oder ein Arzt. (richtig) – Das Einsetzen und die Eignung gehören in die Arztpraxis.
  - Die Person setzt sie jeden Morgen selbst ein. (falsch) – Das ist keine tägliche Anwendung. Schau auf das Bild der liegenden Spirale.

**3B-Q2-ESA** – Welche Aussage zu Blutung und Schmerzen ist richtig?
- 1: Die Kupferspirale lindert Regelschmerzen garantiert. **(falsch)** – Du verwechselst mögliche Auswirkungen verschiedener Methoden.
  - Hilfe 1: Lies im Informationsmaterial: Blutung und Regelschmerzen; Einsetzen und Entscheidung.
  - Hilfe 2: Prüfe den Abschnitt zur Blutung.
  - Hilfe 3: Ist hormonfreie Verhütung automatisch beschwerdefrei?
  - Hilfe 4: Mögliche Verstärkung ist keine sichere Vorhersage.
  - Hilfe 5: Passende Aussage: Sie können stärker werden. Starke ungeklärte Schmerzen gehören in die Arztpraxis. Die Kupferspirale kann Beschwerden verstärken; individuelle Auswirkungen sind offen.
- 2: Sie können stärker werden. Starke ungeklärte Schmerzen gehören in die Arztpraxis. **(richtig)** – Die Kupferspirale kann Beschwerden verstärken; individuelle Auswirkungen sind offen.
- 3: Ohne Hormone können keine Beschwerden entstehen. **(falsch)** – Du setzt Hormonfreiheit mit Beschwerdefreiheit gleich.
  - Hilfe 1: Lies im Informationsmaterial: Blutung und Regelschmerzen; Einsetzen und Entscheidung.
  - Hilfe 2: Auch hormonfreie Methoden können Auswirkungen haben.
  - Hilfe 3: Ist hormonfreie Verhütung automatisch beschwerdefrei?
  - Hilfe 4: Mögliche Verstärkung ist keine sichere Vorhersage.
  - Hilfe 5: Passende Aussage: Sie können stärker werden. Starke ungeklärte Schmerzen gehören in die Arztpraxis. Die Kupferspirale kann Beschwerden verstärken; individuelle Auswirkungen sind offen.
- Hilfen ohne Auswahl: Lies im Informationsmaterial: Blutung und Regelschmerzen; Einsetzen und Entscheidung. → Vergleiche die Aussagen mit dem beschriebenen biologischen Mechanismus. → Ist hormonfreie Verhütung automatisch beschwerdefrei? → Mögliche Verstärkung ist keine sichere Vorhersage. → Passende Aussage: Sie können stärker werden. Starke ungeklärte Schmerzen gehören in die Arztpraxis. Die Kupferspirale kann Beschwerden verstärken; individuelle Auswirkungen sind offen.
- **Nach Lösungshilfe:** Was ist bei starken Regelschmerzen ohne bekannte Ursache wichtig?
  - Die Ursache in der Arztpraxis abklären lassen. (richtig) – Die Stärke und Ursache der Beschwerden müssen gesondert geklärt werden.
  - Sie immer ignorieren. (falsch) – Ungeklärte starke Schmerzen sollten nicht ignoriert werden. Lies den Hinweis am Kartenende.

**Nach bestandener Prüfung – Papier:** Papier · 3B – Kupferspirale: Ergänze die Felder 3, 4 genau wie angezeigt. Vergleiche deine Einträge.
- Feld 3 (3B-3, Schutz im Alltag): **tägliche Einnahme**
- Feld 4 (3B-4, Blutung und Regelschmerzen): **stärker**
Kein Code. Nach Vergleich „Weiter im Chat“.
Vergleich mit vollständiger Karte des eigenen Niveaus. Auf Papier „Karte kontrolliert“ markieren. Keine rückwirkende digitale Freigabe.
Nächstes Kapitel: 4A

## 4A – Hormonspirale: Hormon und Schutzwirkung

Informationsmaterial (auf dem iPad sichtbar, beim Antworten wieder aufrufbar):
- **Hormon und Schleim am Gebärmutterhals:** Ein Gestagen macht den Schleim am Gebärmutterhals zäher. Spermien können ihn schwerer durchdringen.
- **Schutz vor Infektionen:** Der veränderte Schleim erschwert Spermien den Weg, bietet aber keinen STI-Schutz.

Bildimpuls: Was verändert sich durch das Hormon?

**4A-Q1-ESA** – Warum kommen Spermien bei der Hormonspirale schwerer zur Eizelle?
- 1: Sie fängt Sperma außerhalb des Körpers auf. **(falsch)** – Du beschreibst die Kondomhülle.
  - Hilfe 1: Lies im Informationsmaterial: Hormon und Schleim am Gebärmutterhals.
  - Hilfe 2: Die Spirale wirkt im Körper am Gebärmutterhals.
  - Hilfe 3: An welcher engen Stelle des Weges wirkt das Hormon besonders?
  - Hilfe 4: Vergleiche dünneren und zäheren Schleim.
  - Hilfe 5: Passende Aussage: Ein Gestagen macht den Schleim am Gebärmutterhals zäher. Der Schleim wird schwerer durchlässig für Spermien.
- 2: Ein Gestagen macht den Schleim am Gebärmutterhals zäher. **(richtig)** – Der Schleim wird schwerer durchlässig für Spermien.
- 3: Kupfer verändert die Spermien wie bei der Kupferspirale. **(falsch)** – Du verwechselst die Spiralen.
  - Hilfe 1: Lies im Informationsmaterial: Hormon und Schleim am Gebärmutterhals.
  - Hilfe 2: Die Hormonspirale gibt ein Gestagen ab.
  - Hilfe 3: An welcher engen Stelle des Weges wirkt das Hormon besonders?
  - Hilfe 4: Vergleiche dünneren und zäheren Schleim.
  - Hilfe 5: Passende Aussage: Ein Gestagen macht den Schleim am Gebärmutterhals zäher. Der Schleim wird schwerer durchlässig für Spermien.
- Hilfen ohne Auswahl: Lies im Informationsmaterial: Hormon und Schleim am Gebärmutterhals. → Vergleiche die Aussagen mit dem beschriebenen biologischen Mechanismus. → An welcher engen Stelle des Weges wirkt das Hormon besonders? → Vergleiche dünneren und zäheren Schleim. → Passende Aussage: Ein Gestagen macht den Schleim am Gebärmutterhals zäher. Der Schleim wird schwerer durchlässig für Spermien.
- **Nach Lösungshilfe:** Der Schleim am Gebärmutterhals wird zäher. Was bedeutet das für Spermien?
  - Sie kommen schwerer hindurch. (richtig) – Der veränderte Schleim erschwert ihren Weg.
  - Sie kommen sicher schneller hindurch. (falsch) – Du deutest die Veränderung in die falsche Richtung. Denke an zähen Schleim.

**4A-Q2-ESA** – Welche Schutzwirkung folgt aus dem zäheren Schleim?
- 1: Spermien gelangen schwerer hindurch; ein STI-Schutz folgt daraus nicht. **(richtig)** – Der veränderte Schleim erschwert den Weg der Spermien und ist kein verlässlicher Schutz vor STI.
- 2: Jede Übertragung von Erregern wird verhindert. **(falsch)** – Du verallgemeinerst die Wirkung auf Spermien.
  - Hilfe 1: Lies im Informationsmaterial: Schutz vor Infektionen.
  - Hilfe 2: Prüfe den Unterschied zwischen beiden Schutzzielen.
  - Hilfe 3: An welcher Stelle des Weges wirkt der Schleim?
  - Hilfe 4: Ein veränderter Schleim ist keine Erregerbarriere wie ein geeignetes Kondom.
  - Hilfe 5: Passende Aussage: Spermien gelangen schwerer hindurch; ein STI-Schutz folgt daraus nicht. Der veränderte Schleim erschwert den Weg der Spermien und ist kein verlässlicher Schutz vor STI.
- 3: Die Hormonspirale schützt vor STI, aber nicht vor Schwangerschaft. **(falsch)** – Du kehrst die Schutzwirkungen um.
  - Hilfe 1: Lies im Informationsmaterial: Schutz vor Infektionen.
  - Hilfe 2: Lies den Wirkmechanismus.
  - Hilfe 3: An welcher Stelle des Weges wirkt der Schleim?
  - Hilfe 4: Ein veränderter Schleim ist keine Erregerbarriere wie ein geeignetes Kondom.
  - Hilfe 5: Passende Aussage: Spermien gelangen schwerer hindurch; ein STI-Schutz folgt daraus nicht. Der veränderte Schleim erschwert den Weg der Spermien und ist kein verlässlicher Schutz vor STI.
- Hilfen ohne Auswahl: Lies im Informationsmaterial: Schutz vor Infektionen. → Vergleiche die Aussagen mit dem beschriebenen biologischen Mechanismus. → An welcher Stelle des Weges wirkt der Schleim? → Ein veränderter Schleim ist keine Erregerbarriere wie ein geeignetes Kondom. → Passende Aussage: Spermien gelangen schwerer hindurch; ein STI-Schutz folgt daraus nicht. Der veränderte Schleim erschwert den Weg der Spermien und ist kein verlässlicher Schutz vor STI.
- **Nach Lösungshilfe:** Spermien gelangen schwerer durch den Schleim. Was gilt trotzdem?
  - Es besteht kein STI-Schutz durch die Hormonspirale. (richtig) – Spermienwirkung und Infektionsschutz sind verschieden.
  - Alle STI werden verhindert. (falsch) – Das folgt nicht aus dem Mechanismus. Trenne die Schutzwirkungen.

**Nach bestandener Prüfung – Papier:** Papier · 4A – Hormonspirale: Ergänze die Felder 1, 2 genau wie angezeigt. Vergleiche deine Einträge.
- Feld 1 (4A-1, Hormon und Schleim am Gebärmutterhals): **zäher**
- Feld 2 (4A-2, Schutz vor Infektionen): **keinen STI-Schutz**
Kein Code. Nach Vergleich „Weiter im Chat“.
Nächstes Kapitel: 4B

## 4B – Hormonspirale: Alltag und Einlage

Informationsmaterial (auf dem iPad sichtbar, beim Antworten wieder aufrufbar):
- **Schutz im Alltag:** Längerfristiger, sehr zuverlässiger Schwangerschaftsschutz ohne tägliche Einnahme. Lagekontrolle in der Praxis.
- **Einsetzen und Entscheidung:** Ärztliches Einsetzen in die Gebärmutter. Das kann wehtun. Eignung und persönliche Zustimmung vorher klären.
- **Blutung und Regelschmerzen:** Blutungen können unregelmäßig sein. Später können Blutungen und Schmerzen schwächer werden; das ist nicht sicher. Starke ungeklärte Schmerzen ärztlich abklären lassen.

Bildimpuls: Warum braucht man keine tägliche Tablette?

**4B-Q1-ESA** – Warum braucht die Hormonspirale keine tägliche Einnahme?
- 1: Sie wirkt hormonfrei wie die Kupferspirale. **(falsch)** – Du verwechselst die Wirkstoffe.
  - Hilfe 1: Lies im Informationsmaterial: Schutz im Alltag; Einsetzen und Entscheidung.
  - Hilfe 2: Lies, was die Hormonspirale abgibt.
  - Hilfe 3: Woher stammt das Hormon nach dem Einsetzen?
  - Hilfe 4: Eine liegende Spirale und eine Tablette haben unterschiedliche Anwendungsformen.
  - Hilfe 5: Passende Aussage: Sie gibt nach dem Einsetzen über längere Zeit ein Hormon ab. Die Hormonabgabe erfolgt aus der liegenden Spirale; ärztliches Einsetzen und Lagekontrolle gehören dazu.
- 2: Sie wird jeden Tag vor dem Sex selbst neu eingesetzt. **(falsch)** – Du verwechselst eine Langzeitmethode mit einer Methode pro Sexualkontakt.
  - Hilfe 1: Lies im Informationsmaterial: Schutz im Alltag; Einsetzen und Entscheidung.
  - Hilfe 2: Lies die Hinweise zum ärztlichen Einsetzen.
  - Hilfe 3: Woher stammt das Hormon nach dem Einsetzen?
  - Hilfe 4: Eine liegende Spirale und eine Tablette haben unterschiedliche Anwendungsformen.
  - Hilfe 5: Passende Aussage: Sie gibt nach dem Einsetzen über längere Zeit ein Hormon ab. Die Hormonabgabe erfolgt aus der liegenden Spirale; ärztliches Einsetzen und Lagekontrolle gehören dazu.
- 3: Sie gibt nach dem Einsetzen über längere Zeit ein Hormon ab. **(richtig)** – Die Hormonabgabe erfolgt aus der liegenden Spirale; ärztliches Einsetzen und Lagekontrolle gehören dazu.
- Hilfen ohne Auswahl: Lies im Informationsmaterial: Schutz im Alltag; Einsetzen und Entscheidung. → Vergleiche die Aussagen mit dem beschriebenen biologischen Mechanismus. → Woher stammt das Hormon nach dem Einsetzen? → Eine liegende Spirale und eine Tablette haben unterschiedliche Anwendungsformen. → Passende Aussage: Sie gibt nach dem Einsetzen über längere Zeit ein Hormon ab. Die Hormonabgabe erfolgt aus der liegenden Spirale; ärztliches Einsetzen und Lagekontrolle gehören dazu.
- **Nach Lösungshilfe:** Wo wird die Hormonspirale eingesetzt?
  - Jeden Morgen selbst außerhalb des Körpers. (falsch) – Die Spirale ist keine tägliche äußerliche Methode. Sieh dir das Modell an.
  - In die Gebärmutter, in der Arztpraxis. (richtig) – Sie bleibt dort und gibt längerfristig ein Hormon ab.

**4B-Q2-ESA** – Welche Aussage zu Blutungen und Schmerzen passt?
- 1: Jede Blutung wird sofort regelmäßig. **(falsch)** – Du versprichst eine nicht garantierte Wirkung.
  - Hilfe 1: Lies im Informationsmaterial: Blutung und Regelschmerzen; Einsetzen und Entscheidung.
  - Hilfe 2: Lies den Hinweis zu anfangs unregelmäßigen Blutungen.
  - Hilfe 3: Was weiß man über die Ursache ungeklärter Schmerzen?
  - Hilfe 4: Eine mögliche Wirkung erlaubt keine sichere Prognose.
  - Hilfe 5: Passende Aussage: Sie können später schwächer werden; starke ungeklärte Schmerzen sollten trotzdem abgeklärt werden. Eine mögliche Linderung ersetzt keine medizinische Klärung.
- 2: Starke Schmerzen müssen wegen möglicher Linderung nie abgeklärt werden. **(falsch)** – Du verwechselst mögliche Wirkung und Abklärung.
  - Hilfe 1: Lies im Informationsmaterial: Blutung und Regelschmerzen; Einsetzen und Entscheidung.
  - Hilfe 2: Die Ursache ungeklärter Beschwerden bleibt offen.
  - Hilfe 3: Was weiß man über die Ursache ungeklärter Schmerzen?
  - Hilfe 4: Eine mögliche Wirkung erlaubt keine sichere Prognose.
  - Hilfe 5: Passende Aussage: Sie können später schwächer werden; starke ungeklärte Schmerzen sollten trotzdem abgeklärt werden. Eine mögliche Linderung ersetzt keine medizinische Klärung.
- 3: Sie können später schwächer werden; starke ungeklärte Schmerzen sollten trotzdem abgeklärt werden. **(richtig)** – Eine mögliche Linderung ersetzt keine medizinische Klärung.
- Hilfen ohne Auswahl: Lies im Informationsmaterial: Blutung und Regelschmerzen; Einsetzen und Entscheidung. → Vergleiche die Aussagen mit dem beschriebenen biologischen Mechanismus. → Was weiß man über die Ursache ungeklärter Schmerzen? → Eine mögliche Wirkung erlaubt keine sichere Prognose. → Passende Aussage: Sie können später schwächer werden; starke ungeklärte Schmerzen sollten trotzdem abgeklärt werden. Eine mögliche Linderung ersetzt keine medizinische Klärung.
- **Nach Lösungshilfe:** Kann eine Hormonspirale die Blutung verändern?
  - Ja, sie kann zunächst unregelmäßig sein und später schwächer werden. (richtig) – Diese möglichen Veränderungen sind individuell.
  - Nein, die Blutung bleibt immer genau gleich. (falsch) – Du schließt mögliche Veränderungen aus. Lies die Kartenstelle zur Blutung.

**Nach bestandener Prüfung – Papier:** Papier · 4B – Hormonspirale: Ergänze die Felder 3, 4 genau wie angezeigt. Vergleiche deine Einträge.
- Feld 3 (4B-3, Schutz im Alltag): **tägliche Einnahme**
- Feld 4 (4B-4, Blutung und Regelschmerzen): **schwächer**
Kein Code. Nach Vergleich „Weiter im Chat“.
Vergleich mit vollständiger Karte des eigenen Niveaus. Auf Papier „Karte kontrolliert“ markieren. Keine rückwirkende digitale Freigabe.
Nächstes Kapitel: Abschluss; Karten vollständig prüfen.

# MSA

## Pearl-Index
Der Pearl-Index setzt Schwangerschaften trotz Verhütung zur Anwendungszeit ins Verhältnis: Anzahl pro 100 Frauenjahre. Drei Schwangerschaften bei 100 Frauenjahren ergeben im vereinfachten Beispiel einen Pearl-Index von 3. Kleinere Werte sprechen unter vergleichbaren Bedingungen für höheren Schwangerschaftsschutz. Studien und Anwendungsbedingungen können abweichen. Die Kartenwerte sind historische Orientierungswerte, keine individuellen Garantien und kein Maß für STI-Schutz.
**PI-Q1-MSA** – Zwei Studien geben Pearl-Indizes von 2 und 8 an. Welche Aussage ist zulässig?
- 1: Unter vergleichbaren Bedingungen steht der kleinere Wert für einen zuverlässigeren Schwangerschaftsschutz. **(richtig)** – Die Kennzahl bezieht sich auf Schwangerschaften pro 100 Frauenjahre; die Bedingungen müssen vergleichbar sein.
- 2: Der kleinere Wert beweist auch besseren STI-Schutz. **(falsch)** – Der Index misst keine Infektionen.
  - Hilfe 1: Lies im Informationsmaterial: Pearl-Index (Definition auf jeder Karte).
  - Hilfe 2: Trenne die beiden Schutzziele.
  - Hilfe 3: Welche Messgröße und welcher Bezug werden verwendet?
  - Hilfe 4: Der Wert ist keine Garantie für eine einzelne Person.
  - Hilfe 5: Passende Aussage: Unter vergleichbaren Bedingungen steht der kleinere Wert für einen zuverlässigeren Schwangerschaftsschutz. Die Kennzahl bezieht sich auf Schwangerschaften pro 100 Frauenjahre; die Bedingungen müssen vergleichbar sein.
- 3: Die Werte sind unabhängig von der Anwendung für jede Person exakt gültig. **(falsch)** – Du deutest Studienwerte als individuelle Garantie.
  - Hilfe 1: Lies im Informationsmaterial: Pearl-Index (Definition auf jeder Karte).
  - Hilfe 2: Anwendungsbedingungen und Untersuchungen können sich unterscheiden.
  - Hilfe 3: Welche Messgröße und welcher Bezug werden verwendet?
  - Hilfe 4: Der Wert ist keine Garantie für eine einzelne Person.
  - Hilfe 5: Passende Aussage: Unter vergleichbaren Bedingungen steht der kleinere Wert für einen zuverlässigeren Schwangerschaftsschutz. Die Kennzahl bezieht sich auf Schwangerschaften pro 100 Frauenjahre; die Bedingungen müssen vergleichbar sein.
- Hilfen ohne Auswahl: Lies im Informationsmaterial: Pearl-Index (Definition auf jeder Karte). → Vergleiche die Aussagen mit dem beschriebenen biologischen Mechanismus. → Welche Messgröße und welcher Bezug werden verwendet? → Der Wert ist keine Garantie für eine einzelne Person. → Passende Aussage: Unter vergleichbaren Bedingungen steht der kleinere Wert für einen zuverlässigeren Schwangerschaftsschutz. Die Kennzahl bezieht sich auf Schwangerschaften pro 100 Frauenjahre; die Bedingungen müssen vergleichbar sein.
- **Nach Lösungshilfe:** Was müsste zusätzlich bekannt sein, um unterschiedliche Pearl-Index-Angaben sinnvoll zu vergleichen?
  - Die Zahl der STI allein. (falsch) – Diese Zahl gehört zu einer anderen Messgröße. Frage nach der Anwendung der Verhütungsmethode.
  - Nur, ob beide Werte auf 100 Frauenjahre bezogen sind. (falsch) – Die gleiche Bezugsgröße allein reicht nicht. Welche Bedingungen können sich trotz gleicher Einheit unterscheiden?
  - Die Studien- und Anwendungsbedingungen. (richtig) – Eine gleiche Bezugsgröße allein macht verschiedene Untersuchungen nicht vollständig vergleichbar.

## 1A – Kondom: Material und Barriere

Informationsmaterial (auf dem iPad sichtbar, beim Antworten wieder aufrufbar):
- **Material und Allergie:** Es gibt geeignete synthetische Kondome ohne Latex, z. B. Polyurethan oder Polyisopren. Eignung und Material auf der Packung prüfen.
- **Barriere und Schwangerschaft:** Das Kondom bildet eine mechanische Barriere: Bei intaktem, richtig sitzendem Kondom gelangt kein Sperma in die Scheide. Hormonfrei.

Bildimpuls: Trenne Materialeigenschaft und mechanische Funktion.

**1A-Q1-MSA** – Zwei Kondome sind zur Verhütung geeignet: eines aus Latex, eines aus Polyisopren. Welcher Schluss ist richtig?
- 1: Polyisopren ersetzt die Barriere durch eine Hormonwirkung. **(falsch)** – Du ordnest dem Material eine Hormonwirkung zu.
  - Hilfe 1: Lies im Informationsmaterial: Material und Allergie.
  - Hilfe 2: Suche die Wirkweise der Kondome, nicht die Wirkweise einer Pille.
  - Hilfe 3: Welche gemeinsame Aufgabe erfüllen beide Hüllen?
  - Hilfe 4: Wirkprinzip und Verträglichkeit sind zwei unterschiedliche Eigenschaften.
  - Hilfe 5: Passende Aussage: Beide können Sperma mechanisch zurückhalten; das Material muss individuell verträglich sein. Die mechanische Barriere hängt von Eignung, Zustand und korrekter Anwendung ab, nicht allein von Latex.
- 2: Beide können Sperma mechanisch zurückhalten; das Material muss individuell verträglich sein. **(richtig)** – Die mechanische Barriere hängt von Eignung, Zustand und korrekter Anwendung ab, nicht allein von Latex.
- 3: Nur Latex kann Spermien mechanisch zurückhalten. **(falsch)** – Du leitest die Barrierewirkung allein aus einem Material ab.
  - Hilfe 1: Lies im Informationsmaterial: Material und Allergie.
  - Hilfe 2: Vergleiche die beiden zugelassenen Materialien.
  - Hilfe 3: Welche gemeinsame Aufgabe erfüllen beide Hüllen?
  - Hilfe 4: Wirkprinzip und Verträglichkeit sind zwei unterschiedliche Eigenschaften.
  - Hilfe 5: Passende Aussage: Beide können Sperma mechanisch zurückhalten; das Material muss individuell verträglich sein. Die mechanische Barriere hängt von Eignung, Zustand und korrekter Anwendung ab, nicht allein von Latex.
- Hilfen ohne Auswahl: Lies im Informationsmaterial: Material und Allergie. → Vergleiche die Aussagen mit dem beschriebenen biologischen Mechanismus. → Welche gemeinsame Aufgabe erfüllen beide Hüllen? → Wirkprinzip und Verträglichkeit sind zwei unterschiedliche Eigenschaften. → Passende Aussage: Beide können Sperma mechanisch zurückhalten; das Material muss individuell verträglich sein. Die mechanische Barriere hängt von Eignung, Zustand und korrekter Anwendung ab, nicht allein von Latex.
- **Nach Lösungshilfe:** Ein latexfreies Produkt ist nicht zur Verhütung ausgewiesen. Was folgt aus dem Etikett allein?
  - Es schützt nachweislich vor Schwangerschaft. (falsch) – Die Angabe zur Eignung fehlt. Trenne Material von nachgewiesener Funktion.
  - Es muss Hormone enthalten. (falsch) – Latexfreiheit sagt nichts über Hormone aus. Prüfe, welche Eigenschaft überhaupt angegeben wurde.
  - Eine Verhütungswirkung ist daraus nicht nachgewiesen. (richtig) – Materialangabe und nachgewiesene Eignung sind nicht dasselbe.

**1A-Q2-MSA** – Ein Kondom hat einen Riss. Warum ist der Schwangerschaftsschutz beeinträchtigt?
- 1: Der Riss löst einen Eisprung aus. **(falsch)** – Du verwechselst Hüllenfunktion und Zyklus.
  - Hilfe 1: Lies im Informationsmaterial: Barriere und Schwangerschaft.
  - Hilfe 2: Das Kondom gibt keine Hormone ab.
  - Hilfe 3: Was verändert ein Riss an der Funktion einer Hülle?
  - Hilfe 4: Der Eisprung bleibt vom Kondom unbeeinflusst.
  - Hilfe 5: Passende Aussage: Die mechanische Barriere ist unterbrochen; Sperma kann austreten. Eine intakte Hülle ist Voraussetzung für das Zurückhalten von Spermien.
- 2: Die Spermien werden durch den Riss befruchtungsfähig. **(falsch)** – Du unterstellst dem Kondom eine Veränderung der Spermien.
  - Hilfe 1: Lies im Informationsmaterial: Barriere und Schwangerschaft.
  - Hilfe 2: Prüfe, ob die Methode Spermien verändert oder ihren Weg begrenzt.
  - Hilfe 3: Was verändert ein Riss an der Funktion einer Hülle?
  - Hilfe 4: Der Eisprung bleibt vom Kondom unbeeinflusst.
  - Hilfe 5: Passende Aussage: Die mechanische Barriere ist unterbrochen; Sperma kann austreten. Eine intakte Hülle ist Voraussetzung für das Zurückhalten von Spermien.
- 3: Die mechanische Barriere ist unterbrochen; Sperma kann austreten. **(richtig)** – Eine intakte Hülle ist Voraussetzung für das Zurückhalten von Spermien.
- Hilfen ohne Auswahl: Lies im Informationsmaterial: Barriere und Schwangerschaft. → Vergleiche die Aussagen mit dem beschriebenen biologischen Mechanismus. → Was verändert ein Riss an der Funktion einer Hülle? → Der Eisprung bleibt vom Kondom unbeeinflusst. → Passende Aussage: Die mechanische Barriere ist unterbrochen; Sperma kann austreten. Eine intakte Hülle ist Voraussetzung für das Zurückhalten von Spermien.
- **Nach Lösungshilfe:** Ein intaktes Kondom rutscht ab. Welche Voraussetzung ist verletzt?
  - Der Zyklus wird hormonell verändert. (falsch) – Abrutschen betrifft nicht den Zyklus. Denke an die Hüllenfunktion.
  - Die Spermien werden neu gebildet. (falsch) – Die Spermienbildung wird nicht verändert. Betrachte den Weg vorhandener Spermien.
  - Die Hülle sitzt nicht mehr richtig; Sperma kann austreten. (richtig) – Auch eine intakte Hülle schützt nur bei korrektem Sitz.

**Nach bestandener Prüfung – Papier:** Papier · 1A – Kondom: Ergänze die Felder 1, 2 genau wie angezeigt. Vergleiche deine Einträge.
- Feld 1 (1A-1, Material und Allergie): **ohne Latex**
- Feld 2 (1A-2, Barriere und Schwangerschaft): **Barriere**

**Gedruckter Fachcheck:** Wie wirkt ein intaktes Kondom ohne Latex?
Markiere die passende Aussage. Begründe in wenigen Stichwörtern. Kehre zum Chat zurück und gib den Buchstaben ein.
Erwarteter Grund: Geeignetes synthetisches Material kann Sperma mechanisch zurückhalten.
**1A-P-MSA** – Wie wirkt ein intaktes Kondom ohne Latex?
- A: Nur Latex hält Spermien zurück. **(falsch)** – Du machst die Barriere allein von Latex abhängig.
  - Hilfe 1: Lies auf deiner Karte: Material und Allergie; Barriere und Schwangerschaft.
  - Hilfe 2: Ein anderes geeignetes synthetisches Material kann ebenfalls eine intakte Hülle bilden.
  - Hilfe 3: Welche Aufgabe kann die Hülle unabhängig vom Material erfüllen?
  - Hilfe 4: Ein geeignetes Material hält Sperma mechanisch zurück. Hormonwirkung ist dafür nicht nötig.
  - Hilfe 5: Passende Aussage: B – Das geeignete Material bildet eine Barriere. Geeignetes synthetisches Material kann Sperma mechanisch zurückhalten.
- B: Das geeignete Material bildet eine Barriere. **(richtig)** – Die markierte biologische Aussage passt. Geeignetes synthetisches Material kann Sperma mechanisch zurückhalten. Deine eigene Begründung auf Papier wird nicht automatisch fachlich bewertet.
- C: Das Material hemmt den Eisprung. **(falsch)** – Du beschreibst eine Hormonwirkung statt einer Hülle.
  - Hilfe 1: Lies auf deiner Karte: Material und Allergie; Barriere und Schwangerschaft.
  - Hilfe 2: Das Kondom wirkt mechanisch, ohne den Eisprung zu verändern.
  - Hilfe 3: Welche Aufgabe kann die Hülle unabhängig vom Material erfüllen?
  - Hilfe 4: Ein geeignetes Material hält Sperma mechanisch zurück. Hormonwirkung ist dafür nicht nötig.
  - Hilfe 5: Passende Aussage: B – Das geeignete Material bildet eine Barriere. Geeignetes synthetisches Material kann Sperma mechanisch zurückhalten.
- Hilfen ohne Auswahl: Lies auf deiner Karte: Material und Allergie; Barriere und Schwangerschaft. → Prüfe, welche Aussage durch die biologische Wirkweise gedeckt ist. → Welche Aufgabe kann die Hülle unabhängig vom Material erfüllen? → Ein geeignetes Material hält Sperma mechanisch zurück. Hormonwirkung ist dafür nicht nötig. → Passende Aussage: B – Das geeignete Material bildet eine Barriere. Geeignetes synthetisches Material kann Sperma mechanisch zurückhalten.
- **Nach Lösungshilfe:** Ein als geeignet gekennzeichnetes latexfreies Kondom hat einen Riss. Was folgt?
  - Die mechanische Barriere kann beeinträchtigt sein. (richtig) – Materialeignung und Intaktheit sind getrennte Voraussetzungen.
  - Latexfreiheit garantiert trotzdem die Barriere. (falsch) – Die Hülle ist beschädigt. Prüfe die tatsächliche Barriere.
  - Das Kondom hemmt nun den Eisprung. (falsch) – Das ist keine Wirkung eines Kondoms. Trenne Hülle und Zyklus.
Kehre zum Chat zurück. Gib deinen Buchstaben ein, tippe auf „Code prüfen“ und danach auf „Nachricht senden“.
Nächstes Kapitel: 1B

## 1B – Kondom: Schutz und Alltag

Informationsmaterial (auf dem iPad sichtbar, beim Antworten wieder aufrufbar):
- **Schutz vor Infektionen:** Die Barriere vermindert das Risiko vieler STI (sexuell übertragbarer Infektionen). Unbedeckte Haut und Anwendungsfehler lassen ein Restrisiko. Naturmembran ist für STI-Schutz nicht gleichwertig.
- **Bei jedem Sex:** Bei jedem Sex von Anfang an ein neues Kondom richtig nutzen. Reißen oder Abrutschen mindert den Schwangerschafts- und Infektionsschutz.
- **Regelschmerzen:** Keine Veränderung der Regel. Starke, ungeklärte Regelschmerzen ärztlich abklären lassen.

Bildimpuls: Welche zwei Grenzen hat die Schutzwirkung?

**1B-Q1-MSA** – Ein Kondom aus Naturmembran wird zur Schwangerschaftsverhütung angeboten. Was gilt für den STI-Schutz?
- 1: Daraus folgt kein gleichwertiger STI-Schutz gegenüber geeigneten synthetischen Kondomen. **(richtig)** – Eine Hülle gegen Spermien ist nicht automatisch eine ausreichend wirksame Barriere gegen Krankheitserreger.
- 2: Jedes Verhütungskondom bietet gleichwertigen STI-Schutz. **(falsch)** – Du setzt zwei Schutzwirkungen gleich.
  - Hilfe 1: Lies im Informationsmaterial: Schutz vor Infektionen.
  - Hilfe 2: Prüfe die Besonderheit von Naturmembran.
  - Hilfe 3: Sind Spermien und Krankheitserreger dasselbe?
  - Hilfe 4: Schwangerschaftsschutz und Schutz vor Erregern müssen getrennt belegt sein.
  - Hilfe 5: Passende Aussage: Daraus folgt kein gleichwertiger STI-Schutz gegenüber geeigneten synthetischen Kondomen. Eine Hülle gegen Spermien ist nicht automatisch eine ausreichend wirksame Barriere gegen Krankheitserreger.
- 3: Naturmembran garantiert einen vollständigen Infektionsschutz. **(falsch)** – Du leitest eine Garantie aus einem Material ab.
  - Hilfe 1: Lies im Informationsmaterial: Schutz vor Infektionen.
  - Hilfe 2: Vergleiche den Hinweis zum verbleibenden Risiko.
  - Hilfe 3: Sind Spermien und Krankheitserreger dasselbe?
  - Hilfe 4: Schwangerschaftsschutz und Schutz vor Erregern müssen getrennt belegt sein.
  - Hilfe 5: Passende Aussage: Daraus folgt kein gleichwertiger STI-Schutz gegenüber geeigneten synthetischen Kondomen. Eine Hülle gegen Spermien ist nicht automatisch eine ausreichend wirksame Barriere gegen Krankheitserreger.
- Hilfen ohne Auswahl: Lies im Informationsmaterial: Schutz vor Infektionen. → Vergleiche die Aussagen mit dem beschriebenen biologischen Mechanismus. → Sind Spermien und Krankheitserreger dasselbe? → Schwangerschaftsschutz und Schutz vor Erregern müssen getrennt belegt sein. → Passende Aussage: Daraus folgt kein gleichwertiger STI-Schutz gegenüber geeigneten synthetischen Kondomen. Eine Hülle gegen Spermien ist nicht automatisch eine ausreichend wirksame Barriere gegen Krankheitserreger.
- **Nach Lösungshilfe:** Zwei Produkte haben einen ähnlichen Schwangerschaftsschutz. Welche Information fehlt für den STI-Vergleich?
  - Nur der Pearl-Index. (falsch) – Der Pearl-Index misst keinen STI-Schutz. Suche den Unterschied zwischen beiden Schutzzielen.
  - Ob beide dasselbe Hormon enthalten. (falsch) – Hormone allein begründen keinen Erregerschutz. Frage nach der Barriere und ihrer Eignung.
  - Ob sie Übertragungen von Krankheitserregern ausreichend vermindern. (richtig) – Schwangerschaftsschutz ist kein Beleg für Erregerschutz.

**1B-Q2-MSA** – Welche Erklärung trennt korrekte Anwendung und mögliche Wirkung auf den Zyklus?
- 1: Ein später Beginn ist gleichwertig; Regelschmerzen werden dadurch stärker. **(falsch)** – Du übersiehst die Barrieregrenze und schreibst dem Kondom eine Zykluswirkung zu.
  - Hilfe 1: Lies im Informationsmaterial: Bei jedem Sex; Regelschmerzen.
  - Hilfe 2: Prüfe Anwendung und Regelschmerzen getrennt.
  - Hilfe 3: Zu welchem Zeitpunkt entsteht die Barriere?
  - Hilfe 4: Die Regel hängt nicht von einer äußeren Hülle ab.
  - Hilfe 5: Passende Aussage: Jedes Mal von Anfang an anwenden; das Kondom verändert die Regel nicht. Die mechanische Methode wirkt beim Sex und greift nicht in den Zyklus ein.
- 2: Regelmäßiges Benutzen hemmt den Eisprung. **(falsch)** – Du verwechselst die Anwendung eines Kondoms mit der Pille.
  - Hilfe 1: Lies im Informationsmaterial: Bei jedem Sex; Regelschmerzen.
  - Hilfe 2: Eine Hülle ist kein Hormon.
  - Hilfe 3: Zu welchem Zeitpunkt entsteht die Barriere?
  - Hilfe 4: Die Regel hängt nicht von einer äußeren Hülle ab.
  - Hilfe 5: Passende Aussage: Jedes Mal von Anfang an anwenden; das Kondom verändert die Regel nicht. Die mechanische Methode wirkt beim Sex und greift nicht in den Zyklus ein.
- 3: Jedes Mal von Anfang an anwenden; das Kondom verändert die Regel nicht. **(richtig)** – Die mechanische Methode wirkt beim Sex und greift nicht in den Zyklus ein.
- Hilfen ohne Auswahl: Lies im Informationsmaterial: Bei jedem Sex; Regelschmerzen. → Vergleiche die Aussagen mit dem beschriebenen biologischen Mechanismus. → Zu welchem Zeitpunkt entsteht die Barriere? → Die Regel hängt nicht von einer äußeren Hülle ab. → Passende Aussage: Jedes Mal von Anfang an anwenden; das Kondom verändert die Regel nicht. Die mechanische Methode wirkt beim Sex und greift nicht in den Zyklus ein.
- **Nach Lösungshilfe:** Jemand benutzt Kondome korrekt und hat starke ungeklärte Regelschmerzen. Welche Aussage passt?
  - Die korrekte Anwendung lindert sicher die Schmerzen. (falsch) – Eine solche Wirkung ist nicht belegt. Kondome verändern den Zyklus nicht.
  - Kondome verursachen zwangsläufig die Schmerzen. (falsch) – Ein zeitlicher Zusammenhang beweist keine Ursache. Die Beschwerden bedürfen einer eigenen Abklärung.
  - Kondome verändern die Regel nicht; die Schmerzen sollten ärztlich abgeklärt werden. (richtig) – Der Schutz beim Sex und die Abklärung ungeklärter Beschwerden sind getrennte Fragen.

**Nach bestandener Prüfung – Papier:** Papier · 1B – Kondom: Ergänze die Felder 3, 4 genau wie angezeigt. Vergleiche deine Einträge.
- Feld 3 (1B-3, Schutz vor Infektionen): **Restrisiko**
- Feld 4 (1B-4, Bei jedem Sex): **von Anfang an**
Kein Code. Nach Vergleich „Weiter im Chat“.
Vergleich mit vollständiger Karte des eigenen Niveaus. Auf Papier „Karte kontrolliert“ markieren. Keine rückwirkende digitale Freigabe.
Nächstes Kapitel: 2A

## 2A – Kombinationspille: Hormone und Schutzwirkung

Informationsmaterial (auf dem iPad sichtbar, beim Antworten wieder aufrufbar):
- **Hormone und Eisprung:** Östrogen und Gestagen hemmen vor allem den Eisprung. Ohne Eisprung kann in diesem Zyklus keine Eizelle befruchtet werden.
- **Schutz vor Infektionen:** Die Zykluswirkung bildet keine Barriere gegen Krankheitserreger: kein STI-Schutz.

Ergänzender kurzer Fachhinweis: Die Hemmung des Eisprungs setzt wirksame Anwendung voraus. Der Einnahmeplan wird in 2B erklärt.

Bildimpuls: Welche Voraussetzung der Befruchtung wird verändert?

**2A-Q1-MSA** – Ein Modell zeigt einen unterdrückten Eisprung. Welche Ursache-Wirkungs-Kette passt zur Kombinationspille?
- 1: Hormone → mechanisch verschlossener Eileiter → Befruchtung verhindert. **(falsch)** – Die Pille verschließt keine Eileiter.
  - Hilfe 1: Lies im Informationsmaterial: Hormone und Eisprung.
  - Hilfe 2: Das Modell zeigt den Eisprung, keinen Verschluss.
  - Hilfe 3: Welche Hormone werden zugeführt und welcher Schritt verändert sich?
  - Hilfe 4: Die Wirkung setzt vor dem Zusammentreffen von Ei- und Samenzelle an.
  - Hilfe 5: Passende Aussage: Östrogen und Gestagen → Eisprung gehemmt → keine freigesetzte Eizelle zur Befruchtung. Bei unterdrücktem Eisprung steht keine freigesetzte Eizelle zur Befruchtung bereit.
- 2: Östrogen und Gestagen → Eisprung gehemmt → keine freigesetzte Eizelle zur Befruchtung. **(richtig)** – Bei unterdrücktem Eisprung steht keine freigesetzte Eizelle zur Befruchtung bereit.
- 3: Hormone → Spermien außen aufgefangen → Befruchtung verhindert. **(falsch)** – Du vermischst Hormonwirkung und Kondombarriere.
  - Hilfe 1: Lies im Informationsmaterial: Hormone und Eisprung.
  - Hilfe 2: Schau, ob die Pille eine äußere Hülle bildet.
  - Hilfe 3: Welche Hormone werden zugeführt und welcher Schritt verändert sich?
  - Hilfe 4: Die Wirkung setzt vor dem Zusammentreffen von Ei- und Samenzelle an.
  - Hilfe 5: Passende Aussage: Östrogen und Gestagen → Eisprung gehemmt → keine freigesetzte Eizelle zur Befruchtung. Bei unterdrücktem Eisprung steht keine freigesetzte Eizelle zur Befruchtung bereit.
- Hilfen ohne Auswahl: Lies im Informationsmaterial: Hormone und Eisprung. → Vergleiche die Aussagen mit dem beschriebenen biologischen Mechanismus. → Welche Hormone werden zugeführt und welcher Schritt verändert sich? → Die Wirkung setzt vor dem Zusammentreffen von Ei- und Samenzelle an. → Passende Aussage: Östrogen und Gestagen → Eisprung gehemmt → keine freigesetzte Eizelle zur Befruchtung. Bei unterdrücktem Eisprung steht keine freigesetzte Eizelle zur Befruchtung bereit.
- **Nach Lösungshilfe:** Eine Methode verhindert vor allem die Freisetzung der Eizelle. Welche Methode ist hier gemeint?
  - Kondom. (falsch) – Das Kondom hält Sperma zurück. Vergleiche den Wirkungsort.
  - Kupferspirale. (falsch) – Kupfer beeinträchtigt Spermien. Der beschriebene Mechanismus betrifft die Eizelle.
  - Kombinationspille. (richtig) – Ihre Hormone wirken vor allem auf den Eisprung.

**2A-Q2-MSA** – Die Pille hemmt den Eisprung bei korrekter Einnahme. Was lässt sich daraus über Infektionen ableiten?
- 1: Keine STI-Risikominderung durch die Pille; eine Erregerbarriere fehlt. **(richtig)** – Die Hemmung eines Zyklusschritts beeinflusst nicht den Kontakt mit Erregern beim Sex.
- 2: Der zuverlässige Schwangerschaftsschutz beweist auch STI-Schutz. **(falsch)** – Du vermischst zwei verschiedene Schutzwirkungen.
  - Hilfe 1: Lies im Informationsmaterial: Schutz vor Infektionen.
  - Hilfe 2: Prüfe das Wirkprinzip statt des Pearl-Index.
  - Hilfe 3: Was brauchen Krankheitserreger für eine Übertragung?
  - Hilfe 4: Eine verhinderte Befruchtung ist nicht dasselbe wie eine verhinderte Infektion.
  - Hilfe 5: Passende Aussage: Keine STI-Risikominderung durch die Pille; eine Erregerbarriere fehlt. Die Hemmung eines Zyklusschritts beeinflusst nicht den Kontakt mit Erregern beim Sex.
- 3: Die Hormone fangen Krankheitserreger im Körper mechanisch ab. **(falsch)** – Hormone bilden keine solche Hülle.
  - Hilfe 1: Lies im Informationsmaterial: Schutz vor Infektionen.
  - Hilfe 2: Vergleiche Hormonwirkung und Barriere.
  - Hilfe 3: Was brauchen Krankheitserreger für eine Übertragung?
  - Hilfe 4: Eine verhinderte Befruchtung ist nicht dasselbe wie eine verhinderte Infektion.
  - Hilfe 5: Passende Aussage: Keine STI-Risikominderung durch die Pille; eine Erregerbarriere fehlt. Die Hemmung eines Zyklusschritts beeinflusst nicht den Kontakt mit Erregern beim Sex.
- Hilfen ohne Auswahl: Lies im Informationsmaterial: Schutz vor Infektionen. → Vergleiche die Aussagen mit dem beschriebenen biologischen Mechanismus. → Was brauchen Krankheitserreger für eine Übertragung? → Eine verhinderte Befruchtung ist nicht dasselbe wie eine verhinderte Infektion. → Passende Aussage: Keine STI-Risikominderung durch die Pille; eine Erregerbarriere fehlt. Die Hemmung eines Zyklusschritts beeinflusst nicht den Kontakt mit Erregern beim Sex.
- **Nach Lösungshilfe:** Zwei Tabellen geben Schwangerschaftsschutz und STI-Schutz an. Wo ist die Zykluswirkung der Pille relevant?
  - Nur beim STI-Schutz. (falsch) – Die Wirkweise betrifft eine Voraussetzung der Befruchtung. Betrachte den Eisprung.
  - Beim Schwangerschaftsschutz, nicht als Nachweis von STI-Schutz. (richtig) – Die Schutzwirkungen haben verschiedene biologische Voraussetzungen.
  - Bei beiden automatisch gleich. (falsch) – Ein gemeinsames Maß ist hier nicht belegt. Trenne die Vorgänge.

**Nach bestandener Prüfung – Papier:** Papier · 2A – Kombinationspille: Ergänze die Felder 1, 2 genau wie angezeigt. Vergleiche deine Einträge.
- Feld 1 (2A-1, Hormone und Eisprung): **Eisprung**
- Feld 2 (2A-2, Schutz vor Infektionen): **Barriere**

**Gedruckter Fachcheck:** Warum kann die Kombinationspille Schwangerschaften verhindern?
Markiere die passende Aussage. Begründe in wenigen Stichwörtern. Kehre zum Chat zurück und gib den Buchstaben ein.
Erwarteter Grund: Ohne Eisprung kann keine Eizelle befruchtet werden.
**2A-P-MSA** – Warum kann die Kombinationspille Schwangerschaften verhindern?
- A: Sie hemmt vor allem den Eisprung. **(richtig)** – Die markierte biologische Aussage passt. Ohne Eisprung kann keine Eizelle befruchtet werden. Deine eigene Begründung auf Papier wird nicht automatisch fachlich bewertet.
- B: Sie fängt Spermien vor der Scheide ab. **(falsch)** – Du beschreibst das Kondom statt der Pille.
  - Hilfe 1: Lies auf deiner Karte: Hormone und Eisprung; Schutz vor Infektionen.
  - Hilfe 2: Die Pille bildet keine äußere Hülle; sie wirkt auf den Zyklus.
  - Hilfe 3: Was fehlt, wenn keine Eizelle freigesetzt wird?
  - Hilfe 4: Die Pille wirkt vor allem auf den Eisprung; sie bildet keine Erregerbarriere.
  - Hilfe 5: Passende Aussage: A – Sie hemmt vor allem den Eisprung. Ohne Eisprung kann keine Eizelle befruchtet werden.
- C: Sie bildet eine Barriere gegen Erreger. **(falsch)** – Du leitest eine Erregerbarriere aus der Pillenwirkung ab.
  - Hilfe 1: Lies auf deiner Karte: Hormone und Eisprung; Schutz vor Infektionen.
  - Hilfe 2: Der Eisprung und der Kontakt mit Krankheitserregern sind getrennte Vorgänge.
  - Hilfe 3: Was fehlt, wenn keine Eizelle freigesetzt wird?
  - Hilfe 4: Die Pille wirkt vor allem auf den Eisprung; sie bildet keine Erregerbarriere.
  - Hilfe 5: Passende Aussage: A – Sie hemmt vor allem den Eisprung. Ohne Eisprung kann keine Eizelle befruchtet werden.
- Hilfen ohne Auswahl: Lies auf deiner Karte: Hormone und Eisprung; Schutz vor Infektionen. → Prüfe, welche Aussage durch die biologische Wirkweise gedeckt ist. → Was fehlt, wenn keine Eizelle freigesetzt wird? → Die Pille wirkt vor allem auf den Eisprung; sie bildet keine Erregerbarriere. → Passende Aussage: A – Sie hemmt vor allem den Eisprung. Ohne Eisprung kann keine Eizelle befruchtet werden.
- **Nach Lösungshilfe:** Die hormonelle Hemmung des Eisprungs gelingt. Welche Aussage ist richtig?
  - Auch jede Übertragung von Krankheitserregern wird verhindert. (falsch) – Das folgt aus der Zykluswirkung nicht. Erreger benötigen keinen Eisprung.
  - Sperma wird außerhalb des Körpers aufgefangen. (falsch) – Das ist die Kondomwirkung. Betrachte den Wirkungsort der Pille.
  - Es wird keine Eizelle zur Befruchtung freigesetzt; eine Erregerbarriere entsteht nicht. (richtig) – Die Wirkung auf den Zyklus ist kein STI-Schutz.
Kehre zum Chat zurück. Gib deinen Buchstaben ein, tippe auf „Code prüfen“ und danach auf „Nachricht senden“.
Nächstes Kapitel: 2B

## 2B – Kombinationspille: Anwendung und Verträglichkeit

Informationsmaterial (auf dem iPad sichtbar, beim Antworten wieder aufrufbar):
- **Regelmäßige Einnahme:** Regelmäßige Einnahme nach Plan; vergessene Tabletten können den Schwangerschaftsschutz verringern.
- **Persönliche Verträglichkeit:** Übelkeit und seltene ernste Risiken (z. B. Blutgerinnsel) sind möglich. Die Verträglichkeit ist individuell; Erfahrungen anderer sind nicht sicher übertragbar. Ärztliche Eignung klären.
- **Blutung und Regelschmerzen:** Blutungen und Regelschmerzen können schwächer werden, nicht garantiert. Starke ungeklärte Schmerzen ärztlich abklären lassen.

Bildimpuls: Unterscheide Anwendungsfehler und Verträglichkeit.

**2B-Q1-MSA** – Eine Pille hat in einer Studie einen niedrigen Pearl-Index. Warum kann der Schutz im Alltag dennoch geringer sein?
- 1: Ein niedriger Pearl-Index beweist gleichbleibende Sicherheit bei jeder Einnahme. **(falsch)** – Du behandelst einen Richtwert als Garantie.
  - Hilfe 1: Lies im Informationsmaterial: Regelmäßige Einnahme.
  - Hilfe 2: Denke an unterschiedliche Studienbedingungen.
  - Hilfe 3: Sind Wirkprinzip und tatsächliche Anwendung dasselbe?
  - Hilfe 4: Der Einnahmeplan ist eine Bedingung für den Schutz.
  - Hilfe 5: Passende Aussage: Vergessen oder andere Anwendungsfehler können den Schwangerschaftsschutz vermindern. Ein niedriger Studienwert garantiert keine identische Sicherheit bei fehlerhafter Anwendung.
- 2: Vergessen oder andere Anwendungsfehler können den Schwangerschaftsschutz vermindern. **(richtig)** – Ein niedriger Studienwert garantiert keine identische Sicherheit bei fehlerhafter Anwendung.
- 3: Die Pille wird bei vergessenen Einnahmen zur Barriere. **(falsch)** – Die Art der biologischen Wirkung wechselt nicht.
  - Hilfe 1: Lies im Informationsmaterial: Regelmäßige Einnahme.
  - Hilfe 2: Prüfe, welche Wirkung durch Einnahme aufrechterhalten wird.
  - Hilfe 3: Sind Wirkprinzip und tatsächliche Anwendung dasselbe?
  - Hilfe 4: Der Einnahmeplan ist eine Bedingung für den Schutz.
  - Hilfe 5: Passende Aussage: Vergessen oder andere Anwendungsfehler können den Schwangerschaftsschutz vermindern. Ein niedriger Studienwert garantiert keine identische Sicherheit bei fehlerhafter Anwendung.
- Hilfen ohne Auswahl: Lies im Informationsmaterial: Regelmäßige Einnahme. → Vergleiche die Aussagen mit dem beschriebenen biologischen Mechanismus. → Sind Wirkprinzip und tatsächliche Anwendung dasselbe? → Der Einnahmeplan ist eine Bedingung für den Schutz. → Passende Aussage: Vergessen oder andere Anwendungsfehler können den Schwangerschaftsschutz vermindern. Ein niedriger Studienwert garantiert keine identische Sicherheit bei fehlerhafter Anwendung.
- **Nach Lösungshilfe:** In einer Untersuchung wird die Pille immer nach Plan genommen; in einer anderen kommt Vergessen vor. Warum können die Werte abweichen?
  - Pearl-Index misst die Zahl der Infektionen. (falsch) – Der Index misst Schwangerschaften, nicht STI. Trenne die Messgrößen.
  - Die Anwendungsbedingungen unterscheiden sich. (richtig) – Vergessene Einnahmen können den Schutz mindern.
  - Die Hormone bilden dann automatisch eine äußere Hülle. (falsch) – Die Wirkweise ändert sich nicht in eine Barriere. Betrachte den Einnahmeplan.

**2B-Q2-MSA** – Eine Person berichtet von Übelkeit; eine andere von weniger Regelschmerzen. Was folgt fachlich?
- 1: Der zweite Bericht beweist eine sichere Schmerzlinderung für alle. **(falsch)** – Du verallgemeinerst einen möglichen Nutzen.
  - Hilfe 1: Lies im Informationsmaterial: Persönliche Verträglichkeit; Blutung und Regelschmerzen.
  - Hilfe 2: Unterscheide mögliche Wirkung und garantierte Wirkung.
  - Hilfe 3: Welche Aussagen betreffen einzelne Personen, welche eine allgemeine Wirkung?
  - Hilfe 4: Die medizinische Eignung wird durch persönliche Beratung geklärt.
  - Hilfe 5: Passende Aussage: Beide Erfahrungen sind möglich; die Eignung und Verträglichkeit müssen individuell geklärt werden. Individuelle Berichte zeigen Möglichkeiten, aber keine sichere Prognose für eine weitere Person.
- 2: Beide Erfahrungen sind möglich; die Eignung und Verträglichkeit müssen individuell geklärt werden. **(richtig)** – Individuelle Berichte zeigen Möglichkeiten, aber keine sichere Prognose für eine weitere Person.
- 3: Der erste Bericht widerlegt grundsätzlich die Pille. **(falsch)** – Du verallgemeinerst einen Einzelbericht.
  - Hilfe 1: Lies im Informationsmaterial: Persönliche Verträglichkeit; Blutung und Regelschmerzen.
  - Hilfe 2: Auch bei gleichem Präparat können Reaktionen unterschiedlich sein.
  - Hilfe 3: Welche Aussagen betreffen einzelne Personen, welche eine allgemeine Wirkung?
  - Hilfe 4: Die medizinische Eignung wird durch persönliche Beratung geklärt.
  - Hilfe 5: Passende Aussage: Beide Erfahrungen sind möglich; die Eignung und Verträglichkeit müssen individuell geklärt werden. Individuelle Berichte zeigen Möglichkeiten, aber keine sichere Prognose für eine weitere Person.
- Hilfen ohne Auswahl: Lies im Informationsmaterial: Persönliche Verträglichkeit; Blutung und Regelschmerzen. → Vergleiche die Aussagen mit dem beschriebenen biologischen Mechanismus. → Welche Aussagen betreffen einzelne Personen, welche eine allgemeine Wirkung? → Die medizinische Eignung wird durch persönliche Beratung geklärt. → Passende Aussage: Beide Erfahrungen sind möglich; die Eignung und Verträglichkeit müssen individuell geklärt werden. Individuelle Berichte zeigen Möglichkeiten, aber keine sichere Prognose für eine weitere Person.
- **Nach Lösungshilfe:** Eine Person hat starke, ungeklärte Regelschmerzen. Eine Bekannte berichtet von Linderung durch die Pille. Was ist fachlich gerechtfertigt?
  - Eine Linderung ist möglich, die Beschwerden und Eignung müssen individuell abgeklärt werden. (richtig) – Der Erfahrungsbericht klärt weder Ursache noch persönliche Verträglichkeit.
  - Die Ursache ist durch den Bericht bereits bekannt. (falsch) – Ein Fremdbericht ist keine Diagnose. Unterscheide Beobachtung und Ursache.
  - Die Linderung ist bei allen sicher. (falsch) – Ein möglicher Nutzen ist keine Garantie. Beachte individuelle Unterschiede.

**Nach bestandener Prüfung – Papier:** Papier · 2B – Kombinationspille: Ergänze die Felder 3, 4 genau wie angezeigt. Vergleiche deine Einträge.
- Feld 3 (2B-3, Regelmäßige Einnahme): **verringern**
- Feld 4 (2B-4, Persönliche Verträglichkeit): **individuell**
Kein Code. Nach Vergleich „Weiter im Chat“.
Vergleich mit vollständiger Karte des eigenen Niveaus. Auf Papier „Karte kontrolliert“ markieren. Keine rückwirkende digitale Freigabe.
Nächstes Kapitel: 3A

## 3A – Kupferspirale: Kupfer und Schutzwirkung

Informationsmaterial (auf dem iPad sichtbar, beim Antworten wieder aufrufbar):
- **Kupfer und Spermien:** Kupfer beeinträchtigt Beweglichkeit und Befruchtungsfähigkeit der Spermien. Hormonfrei; keine Hemmung des Eisprungs als Wirkprinzip.
- **Schutz vor Infektionen:** Kupfer wirkt auf Spermien, bildet aber keine Barriere gegen Krankheitserreger: kein STI-Schutz.

Ergänzender kurzer Fachhinweis: Hormonfreiheit ist eine Aussage über den Wirkmechanismus, keine Garantie für Beschwerdefreiheit.

Bildimpuls: Welche Fähigkeiten der Spermien sind betroffen?

**3A-Q1-MSA** – Welcher Mechanismus erklärt den Schwangerschaftsschutz der Kupferspirale?
- 1: Sie unterdrückt den Eisprung durch Gestagen. **(falsch)** – Du verwechselst Kupfer und Hormonwirkung.
  - Hilfe 1: Lies im Informationsmaterial: Kupfer und Spermien.
  - Hilfe 2: Die Kupferspirale ist hormonfrei.
  - Hilfe 3: Welche Voraussetzung für die Befruchtung wird beeinträchtigt?
  - Hilfe 4: Die Wirkweise setzt nicht als Hormon am Eisprung an.
  - Hilfe 5: Passende Aussage: Freigesetztes Kupfer beeinträchtigt Beweglichkeit und Befruchtungsfähigkeit von Spermien. Die hormonfreie Methode wirkt auf Spermien und erschwert eine Befruchtung.
- 2: Sie wirkt als geschlossene mechanische Barriere vor der Scheide. **(falsch)** – Du beschreibst die Kondomhülle.
  - Hilfe 1: Lies im Informationsmaterial: Kupfer und Spermien.
  - Hilfe 2: Die Spirale liegt in der Gebärmutter.
  - Hilfe 3: Welche Voraussetzung für die Befruchtung wird beeinträchtigt?
  - Hilfe 4: Die Wirkweise setzt nicht als Hormon am Eisprung an.
  - Hilfe 5: Passende Aussage: Freigesetztes Kupfer beeinträchtigt Beweglichkeit und Befruchtungsfähigkeit von Spermien. Die hormonfreie Methode wirkt auf Spermien und erschwert eine Befruchtung.
- 3: Freigesetztes Kupfer beeinträchtigt Beweglichkeit und Befruchtungsfähigkeit von Spermien. **(richtig)** – Die hormonfreie Methode wirkt auf Spermien und erschwert eine Befruchtung.
- Hilfen ohne Auswahl: Lies im Informationsmaterial: Kupfer und Spermien. → Vergleiche die Aussagen mit dem beschriebenen biologischen Mechanismus. → Welche Voraussetzung für die Befruchtung wird beeinträchtigt? → Die Wirkweise setzt nicht als Hormon am Eisprung an. → Passende Aussage: Freigesetztes Kupfer beeinträchtigt Beweglichkeit und Befruchtungsfähigkeit von Spermien. Die hormonfreie Methode wirkt auf Spermien und erschwert eine Befruchtung.
- **Nach Lösungshilfe:** Eine Methode enthält keine Hormone und beeinträchtigt die Beweglichkeit von Spermien in der Gebärmutter. Welche passt?
  - Kombinationspille. (falsch) – Sie hemmt vor allem den Eisprung. Vergleiche die Wirkprinzipien.
  - Kondom. (falsch) – Es hält Sperma mechanisch zurück. Beachte den beschriebenen Wirkungsort.
  - Kupferspirale. (richtig) – Kupfer wirkt auf Spermien; das ist keine hormonelle Zyklushemmung.

**3A-Q2-MSA** – Was lässt sich aus der Wirkung von Kupfer auf Spermien fachlich ableiten?
- 1: Ein Beitrag zum Schwangerschaftsschutz, aber kein STI-Schutz. **(richtig)** – Kupfer beeinträchtigt Spermien; daraus folgt keine geeignete Barriere gegen übertragene Krankheitserreger.
- 2: Die Wirkung belegt vollständigen Schutz vor sexuell übertragbaren Erregern. **(falsch)** – Die Schlussfolgerung geht über den Mechanismus hinaus.
  - Hilfe 1: Lies im Informationsmaterial: Schutz vor Infektionen.
  - Hilfe 2: Suche nach einer belegten Barriere gegen Erreger.
  - Hilfe 3: Welcher biologische Vorgang wird gestört?
  - Hilfe 4: Befruchtung und Erregerübertragung sind unterschiedliche Vorgänge.
  - Hilfe 5: Passende Aussage: Ein Beitrag zum Schwangerschaftsschutz, aber kein STI-Schutz. Kupfer beeinträchtigt Spermien; daraus folgt keine geeignete Barriere gegen übertragene Krankheitserreger.
- 3: Die Spirale schützt nur vor STI, nicht vor Schwangerschaft. **(falsch)** – Du kehrst die Schutzwirkungen um.
  - Hilfe 1: Lies im Informationsmaterial: Schutz vor Infektionen.
  - Hilfe 2: Lies die Wirkung auf Spermien.
  - Hilfe 3: Welcher biologische Vorgang wird gestört?
  - Hilfe 4: Befruchtung und Erregerübertragung sind unterschiedliche Vorgänge.
  - Hilfe 5: Passende Aussage: Ein Beitrag zum Schwangerschaftsschutz, aber kein STI-Schutz. Kupfer beeinträchtigt Spermien; daraus folgt keine geeignete Barriere gegen übertragene Krankheitserreger.
- Hilfen ohne Auswahl: Lies im Informationsmaterial: Schutz vor Infektionen. → Vergleiche die Aussagen mit dem beschriebenen biologischen Mechanismus. → Welcher biologische Vorgang wird gestört? → Befruchtung und Erregerübertragung sind unterschiedliche Vorgänge. → Passende Aussage: Ein Beitrag zum Schwangerschaftsschutz, aber kein STI-Schutz. Kupfer beeinträchtigt Spermien; daraus folgt keine geeignete Barriere gegen übertragene Krankheitserreger.
- **Nach Lösungshilfe:** Eine Untersuchung zeigt, dass Kupfer die Beweglichkeit von Spermien vermindert. Was wurde damit nicht nachgewiesen?
  - Dass Spermien Zellen sind. (falsch) – Diese Aussage ist nicht das gesuchte Schutzziel. Unterscheide Befruchtung und Erregerübertragung.
  - Verminderung von STI-Übertragungen. (richtig) – Der beschriebene Befund betrifft Spermien, nicht Krankheitserreger.
  - Eine Wirkung auf Spermien. (falsch) – Genau das wurde beschrieben. Suche die nicht untersuchte Schutzwirkung.

**Nach bestandener Prüfung – Papier:** Papier · 3A – Kupferspirale: Ergänze die Felder 1, 2 genau wie angezeigt. Vergleiche deine Einträge.
- Feld 1 (3A-1, Kupfer und Spermien): **Befruchtungsfähigkeit**
- Feld 2 (3A-2, Schutz vor Infektionen): **Barriere**

**Gedruckter Fachcheck:** Wie schützt die Kupferspirale vor Schwangerschaft?
Markiere die passende Aussage. Begründe in wenigen Stichwörtern. Kehre zum Chat zurück und gib den Buchstaben ein.
Erwarteter Grund: Kupfer beeinträchtigt Beweglichkeit und Befruchtungsfähigkeit von Spermien.
**3A-P-MSA** – Wie schützt die Kupferspirale vor Schwangerschaft?
- A: Sie setzt Hormone frei. **(falsch)** – Du verwechselst Kupfer und Hormone.
  - Hilfe 1: Lies auf deiner Karte: Kupfer und Spermien; Schutz vor Infektionen.
  - Hilfe 2: Die Kupferspirale enthält keine Hormone.
  - Hilfe 3: Welche Fähigkeit der Spermien wird beeinträchtigt?
  - Hilfe 4: Kupfer wirkt ohne Hormone auf Spermien. Daraus folgt kein STI-Schutz.
  - Hilfe 5: Passende Aussage: C – Kupfer beeinträchtigt Spermien. Kupfer beeinträchtigt Beweglichkeit und Befruchtungsfähigkeit von Spermien.
- B: Sie verschließt die Gebärmutter. **(falsch)** – Du deutest die Spirale als Verschluss.
  - Hilfe 1: Lies auf deiner Karte: Kupfer und Spermien; Schutz vor Infektionen.
  - Hilfe 2: Sie liegt in der Gebärmutter; die Abgabe von Kupfer ist entscheidend.
  - Hilfe 3: Welche Fähigkeit der Spermien wird beeinträchtigt?
  - Hilfe 4: Kupfer wirkt ohne Hormone auf Spermien. Daraus folgt kein STI-Schutz.
  - Hilfe 5: Passende Aussage: C – Kupfer beeinträchtigt Spermien. Kupfer beeinträchtigt Beweglichkeit und Befruchtungsfähigkeit von Spermien.
- C: Kupfer beeinträchtigt Spermien. **(richtig)** – Die markierte biologische Aussage passt. Kupfer beeinträchtigt Beweglichkeit und Befruchtungsfähigkeit von Spermien. Deine eigene Begründung auf Papier wird nicht automatisch fachlich bewertet.
- Hilfen ohne Auswahl: Lies auf deiner Karte: Kupfer und Spermien; Schutz vor Infektionen. → Prüfe, welche Aussage durch die biologische Wirkweise gedeckt ist. → Welche Fähigkeit der Spermien wird beeinträchtigt? → Kupfer wirkt ohne Hormone auf Spermien. Daraus folgt kein STI-Schutz. → Passende Aussage: C – Kupfer beeinträchtigt Spermien. Kupfer beeinträchtigt Beweglichkeit und Befruchtungsfähigkeit von Spermien.
- **Nach Lösungshilfe:** Ein Modell zeigt Spermien mit verminderter Beweglichkeit durch Kupfer. Was wird damit erklärt?
  - Eine sichere Unterdrückung des Eisprungs durch Hormone. (falsch) – Kupfer ist kein Hormon. Prüfe den dargestellten Mechanismus.
  - Ein Mechanismus gegen Befruchtung, kein STI-Schutz. (richtig) – Die Kupferwirkung betrifft Spermien und beweist keine Erregerbarriere.
  - Eine vollständige Verhinderung von STI. (falsch) – Das Modell zeigt Spermien, nicht Erregerübertragung. Grenze die Aussage ein.
Kehre zum Chat zurück. Gib deinen Buchstaben ein, tippe auf „Code prüfen“ und danach auf „Nachricht senden“.
Nächstes Kapitel: 3B

## 3B – Kupferspirale: Alltag und Einlage

Informationsmaterial (auf dem iPad sichtbar, beim Antworten wieder aufrufbar):
- **Schutz im Alltag:** Nach Einsetzen längerfristig sehr zuverlässiger Schutz; keine tägliche Einnahme. Dauer modellabhängig, Lagekontrollen in der Praxis.
- **Einsetzen und Entscheidung:** Ärztliches Einsetzen in die Gebärmutter kann schmerzhaft sein. Medizinische Eignung und persönliche Zustimmung vorher klären.
- **Blutung und Regelschmerzen:** Blutungen und Regelschmerzen können stärker werden. Individuelle Auswirkung offen. Starke ungeklärte Schmerzen ärztlich abklären lassen.

Bildimpuls: Welche Alltagseigenschaft unterscheidet die Spirale von der Pille?

**3B-Q1-MSA** – Welche Voraussetzung und welche Alltagswirkung müssen getrennt betrachtet werden?
- 1: Da keine tägliche Einnahme nötig ist, entfällt die ärztliche Eignungsprüfung. **(falsch)** – Du leitest aus einfacher Anwendung eine medizinische Eignung ab.
  - Hilfe 1: Lies im Informationsmaterial: Schutz im Alltag; Einsetzen und Entscheidung.
  - Hilfe 2: Voraussetzungen vor und Alltag nach dem Einsetzen sind verschieden.
  - Hilfe 3: Was muss vor der Langzeitwirkung geklärt sein?
  - Hilfe 4: Kein tägliches Einnehmen heißt nicht keine medizinische Begleitung.
  - Hilfe 5: Passende Aussage: Ärztliches Einsetzen nach Eignungsprüfung und Zustimmung; danach längerfristiger Schutz ohne tägliche Einnahme. Der Vorteil geringer täglicher Anwendungsanforderungen ersetzt weder Beratung noch die Entscheidung zur Einlage.
- 2: Die Person muss sie täglich selbst neu einsetzen. **(falsch)** – Du verwechselst eine Langzeitmethode mit einer kurzfristigen Anwendung.
  - Hilfe 1: Lies im Informationsmaterial: Schutz im Alltag; Einsetzen und Entscheidung.
  - Hilfe 2: Lies den Abschnitt zum Einsetzen.
  - Hilfe 3: Was muss vor der Langzeitwirkung geklärt sein?
  - Hilfe 4: Kein tägliches Einnehmen heißt nicht keine medizinische Begleitung.
  - Hilfe 5: Passende Aussage: Ärztliches Einsetzen nach Eignungsprüfung und Zustimmung; danach längerfristiger Schutz ohne tägliche Einnahme. Der Vorteil geringer täglicher Anwendungsanforderungen ersetzt weder Beratung noch die Entscheidung zur Einlage.
- 3: Ärztliches Einsetzen nach Eignungsprüfung und Zustimmung; danach längerfristiger Schutz ohne tägliche Einnahme. **(richtig)** – Der Vorteil geringer täglicher Anwendungsanforderungen ersetzt weder Beratung noch die Entscheidung zur Einlage.
- Hilfen ohne Auswahl: Lies im Informationsmaterial: Schutz im Alltag; Einsetzen und Entscheidung. → Vergleiche die Aussagen mit dem beschriebenen biologischen Mechanismus. → Was muss vor der Langzeitwirkung geklärt sein? → Kein tägliches Einnehmen heißt nicht keine medizinische Begleitung. → Passende Aussage: Ärztliches Einsetzen nach Eignungsprüfung und Zustimmung; danach längerfristiger Schutz ohne tägliche Einnahme. Der Vorteil geringer täglicher Anwendungsanforderungen ersetzt weder Beratung noch die Entscheidung zur Einlage.
- **Nach Lösungshilfe:** Eine Person stimmt dem ärztlichen Einsetzen nicht zu, obwohl es medizinisch möglich wäre. Was folgt?
  - Weil keine Tabletten nötig sind, ist die Zustimmung unnötig. (falsch) – Die Anwendung sagt nichts über Einwilligung aus. Prüfe die Voraussetzungen für das Einsetzen.
  - Medizinische Eignung ist keine Zustimmung. (richtig) – Eine Einlage benötigt freiwillige Zustimmung.
  - Die medizinische Eignung ersetzt die persönliche Entscheidung. (falsch) – Du vermischst zwei Voraussetzungen. Trenne Eignung und Zustimmung.

**3B-Q2-MSA** – Ein Informationstext sagt: „Die Kupferspirale wirkt hormonfrei.“ Welche weitere Aussage ist vereinbar?
- 1: Kupfer lindert Regelschmerzen immer. **(falsch)** – Die Aussage ist nicht durch die Fachinformation gedeckt.
  - Hilfe 1: Lies im Informationsmaterial: Blutung und Regelschmerzen; Einsetzen und Entscheidung.
  - Hilfe 2: Beachte mögliche Verstärkung.
  - Hilfe 3: Was bedeutet hormonfrei genau, und worüber sagt das nichts Sicheres?
  - Hilfe 4: Wirkprinzip und mögliche Beschwerden sind verschiedene Eigenschaften.
  - Hilfe 5: Passende Aussage: Blutungen und Regelschmerzen können stärker werden; starke ungeklärte Beschwerden sollten ärztlich abgeklärt werden. Hormonfreiheit schließt Auswirkungen auf Blutung und Schmerzen nicht aus.
- 2: Blutungen und Regelschmerzen können stärker werden; starke ungeklärte Beschwerden sollten ärztlich abgeklärt werden. **(richtig)** – Hormonfreiheit schließt Auswirkungen auf Blutung und Schmerzen nicht aus.
- 3: Hormonfrei bedeutet zwangsläufig beschwerdefrei. **(falsch)** – Du leitest eine Nebenwirkungsfreiheit aus dem Wirkprinzip ab.
  - Hilfe 1: Lies im Informationsmaterial: Blutung und Regelschmerzen; Einsetzen und Entscheidung.
  - Hilfe 2: Prüfe die Informationen zur Regel getrennt.
  - Hilfe 3: Was bedeutet hormonfrei genau, und worüber sagt das nichts Sicheres?
  - Hilfe 4: Wirkprinzip und mögliche Beschwerden sind verschiedene Eigenschaften.
  - Hilfe 5: Passende Aussage: Blutungen und Regelschmerzen können stärker werden; starke ungeklärte Beschwerden sollten ärztlich abgeklärt werden. Hormonfreiheit schließt Auswirkungen auf Blutung und Schmerzen nicht aus.
- Hilfen ohne Auswahl: Lies im Informationsmaterial: Blutung und Regelschmerzen; Einsetzen und Entscheidung. → Vergleiche die Aussagen mit dem beschriebenen biologischen Mechanismus. → Was bedeutet hormonfrei genau, und worüber sagt das nichts Sicheres? → Wirkprinzip und mögliche Beschwerden sind verschiedene Eigenschaften. → Passende Aussage: Blutungen und Regelschmerzen können stärker werden; starke ungeklärte Beschwerden sollten ärztlich abgeklärt werden. Hormonfreiheit schließt Auswirkungen auf Blutung und Schmerzen nicht aus.
- **Nach Lösungshilfe:** Eine Person hat mit der Kupferspirale keine stärkeren Schmerzen. Welche Folgerung ist zulässig?
  - Das ist möglich; andere Personen können anders reagieren. (richtig) – Mögliche Beschwerden sind nicht bei allen gleich.
  - Niemand kann dadurch stärkere Schmerzen bekommen. (falsch) – Du verallgemeinerst eine Einzelerfahrung. Trenne Möglichkeit und Garantie.
  - Starke ungeklärte Schmerzen brauchen nie Abklärung. (falsch) – Das folgt aus der Einzelerfahrung nicht. Die Ursache bleibt eine eigene Frage.

**Nach bestandener Prüfung – Papier:** Papier · 3B – Kupferspirale: Ergänze die Felder 3, 4 genau wie angezeigt. Vergleiche deine Einträge.
- Feld 3 (3B-3, Schutz im Alltag): **tägliche Einnahme**
- Feld 4 (3B-4, Blutung und Regelschmerzen): **stärker**
Kein Code. Nach Vergleich „Weiter im Chat“.
Vergleich mit vollständiger Karte des eigenen Niveaus. Auf Papier „Karte kontrolliert“ markieren. Keine rückwirkende digitale Freigabe.
Nächstes Kapitel: 4A

## 4A – Hormonspirale: Hormon und Schutzwirkung

Informationsmaterial (auf dem iPad sichtbar, beim Antworten wieder aufrufbar):
- **Hormon und Schleim am Gebärmutterhals:** Das Gestagen macht den Schleim am Gebärmutterhals für Spermien schwer durchlässig. Dadurch wirkt sie anders als die Kombinationspille.
- **Schutz vor Infektionen:** Der Schleim erschwert Spermien den Weg, bietet aber keinen STI-Schutz.

Ergänzender kurzer Fachhinweis: Zum Vergleich: Die Kombinationspille hemmt vor allem den Eisprung.

Bildimpuls: Erkläre die Wirkungskette.

**4A-Q1-MSA** – Welche Wirkungskette beschreibt die Hormonspirale passend?
- 1: Gestagen → Schleim am Gebärmutterhals schwerer durchlässig → Spermien kommen schwerer hindurch. **(richtig)** – Die Hormonspirale wirkt vor allem über den Zervixschleim.
- 2: Gestagen → Kupferabgabe → Spermien mechanisch aufgefangen. **(falsch)** – Du vermischst drei Wirkprinzipien.
  - Hilfe 1: Lies im Informationsmaterial: Hormon und Schleim am Gebärmutterhals.
  - Hilfe 2: Trenne Hormon, Kupfer und Hülle.
  - Hilfe 3: Was verändert sich zwischen Scheide und Gebärmutter?
  - Hilfe 4: Die Hormonspirale ist weder eine äußere Hülle noch eine Kupfermethode.
  - Hilfe 5: Passende Aussage: Gestagen → Schleim am Gebärmutterhals schwerer durchlässig → Spermien kommen schwerer hindurch. Die Hormonspirale wirkt vor allem über den Zervixschleim.
- 3: Gestagen → ausschließlich Hemmung des Eisprungs wie bei jeder Pille. **(falsch)** – Du setzt verschiedene hormonelle Methoden gleich.
  - Hilfe 1: Lies im Informationsmaterial: Hormon und Schleim am Gebärmutterhals.
  - Hilfe 2: Die Fachinformation hebt den Schleim am Gebärmutterhals hervor.
  - Hilfe 3: Was verändert sich zwischen Scheide und Gebärmutter?
  - Hilfe 4: Die Hormonspirale ist weder eine äußere Hülle noch eine Kupfermethode.
  - Hilfe 5: Passende Aussage: Gestagen → Schleim am Gebärmutterhals schwerer durchlässig → Spermien kommen schwerer hindurch. Die Hormonspirale wirkt vor allem über den Zervixschleim.
- Hilfen ohne Auswahl: Lies im Informationsmaterial: Hormon und Schleim am Gebärmutterhals. → Vergleiche die Aussagen mit dem beschriebenen biologischen Mechanismus. → Was verändert sich zwischen Scheide und Gebärmutter? → Die Hormonspirale ist weder eine äußere Hülle noch eine Kupfermethode. → Passende Aussage: Gestagen → Schleim am Gebärmutterhals schwerer durchlässig → Spermien kommen schwerer hindurch. Die Hormonspirale wirkt vor allem über den Zervixschleim.
- **Nach Lösungshilfe:** Ein Modell zeigt erschwerten Spermien-Durchtritt am Gebärmutterhals durch ein Hormon. Welche Methode passt am besten?
  - Kondom. (falsch) – Die Hülle wirkt außerhalb des Körpers. Beachte die gezeigte Struktur.
  - Hormonspirale. (richtig) – Gestagen verändert vor allem den Schleim am Gebärmutterhals.
  - Kupferspirale. (falsch) – Diese wirkt durch Kupfer auf Spermien. Achte auf den Wirkstoff im Modell.

**4A-Q2-MSA** – Warum kann man aus dem erschwerten Spermien-Durchtritt keinen STI-Schutz ableiten?
- 1: Alle Krankheitserreger sind Spermien. **(falsch)** – Du setzt unterschiedliche biologische Einheiten gleich.
  - Hilfe 1: Lies im Informationsmaterial: Schutz vor Infektionen.
  - Hilfe 2: Spermien sind Keimzellen, Krankheitserreger sind etwas anderes.
  - Hilfe 3: Welche biologische Größe beschreibt das Modell und welche nicht?
  - Hilfe 4: Schutz gegen Schwangerschaft und Schutz gegen STI müssen getrennt geprüft werden.
  - Hilfe 5: Passende Aussage: Die Wirkung betrifft den Weg der Spermien, nicht allgemein die Übertragung von Krankheitserregern. Der Schleimmechanismus ist ein Beitrag zur Verhütung, aber kein Nachweis von Schutz gegen Infektionen.
- 2: Ein hoher Schwangerschaftsschutz beweist eine Erregerbarriere. **(falsch)** – Du vermischst die Messgrößen.
  - Hilfe 1: Lies im Informationsmaterial: Schutz vor Infektionen.
  - Hilfe 2: Der Pearl-Index erfasst keine Infektionen.
  - Hilfe 3: Welche biologische Größe beschreibt das Modell und welche nicht?
  - Hilfe 4: Schutz gegen Schwangerschaft und Schutz gegen STI müssen getrennt geprüft werden.
  - Hilfe 5: Passende Aussage: Die Wirkung betrifft den Weg der Spermien, nicht allgemein die Übertragung von Krankheitserregern. Der Schleimmechanismus ist ein Beitrag zur Verhütung, aber kein Nachweis von Schutz gegen Infektionen.
- 3: Die Wirkung betrifft den Weg der Spermien, nicht allgemein die Übertragung von Krankheitserregern. **(richtig)** – Der Schleimmechanismus ist ein Beitrag zur Verhütung, aber kein Nachweis von Schutz gegen Infektionen.
- Hilfen ohne Auswahl: Lies im Informationsmaterial: Schutz vor Infektionen. → Vergleiche die Aussagen mit dem beschriebenen biologischen Mechanismus. → Welche biologische Größe beschreibt das Modell und welche nicht? → Schutz gegen Schwangerschaft und Schutz gegen STI müssen getrennt geprüft werden. → Passende Aussage: Die Wirkung betrifft den Weg der Spermien, nicht allgemein die Übertragung von Krankheitserregern. Der Schleimmechanismus ist ein Beitrag zur Verhütung, aber kein Nachweis von Schutz gegen Infektionen.
- **Nach Lösungshilfe:** Ein Bild zeigt weniger durch den Schleim gelangende Spermien. Welche Untersuchung wäre für STI-Schutz zusätzlich nötig?
  - Nur eine weitere Messung der Beweglichkeit von Spermien. (falsch) – Auch eine zweite Spermienmessung belegt keine Erregerübertragung. Frage nach dem anderen Schutzziel.
  - Nur der Pearl-Index. (falsch) – Der Index misst Schwangerschaften. Trenne die beiden Schutzziele.
  - Eine geeignete Untersuchung zur Übertragung von Krankheitserregern. (richtig) – Die Abbildung zeigt Spermien, keine Daten zum STI-Risiko.

**Nach bestandener Prüfung – Papier:** Papier · 4A – Hormonspirale: Ergänze die Felder 1, 2 genau wie angezeigt. Vergleiche deine Einträge.
- Feld 1 (4A-1, Hormon und Schleim am Gebärmutterhals): **Spermien**
- Feld 2 (4A-2, Schutz vor Infektionen): **keinen STI-Schutz**

**Gedruckter Fachcheck:** Warum schützt die Hormonspirale vor Schwangerschaften?
Markiere die passende Aussage. Begründe in wenigen Stichwörtern. Kehre zum Chat zurück und gib den Buchstaben ein.
Erwarteter Grund: Der veränderte Schleim erschwert Spermien den Weg.
**4A-P-MSA** – Warum schützt die Hormonspirale vor Schwangerschaften?
- A: Sie hält Sperma außerhalb des Körpers zurück. **(falsch)** – Du beschreibst die äußere Kondomhülle.
  - Hilfe 1: Lies auf deiner Karte: Hormon und Schleim am Gebärmutterhals; Schutz vor Infektionen.
  - Hilfe 2: Die Hormonspirale wirkt im Körper am Gebärmutterhals.
  - Hilfe 3: Welche Struktur verändert das Gestagen?
  - Hilfe 4: Der Schleim wird schwerer durchlässig für Spermien; das belegt keinen STI-Schutz.
  - Hilfe 5: Passende Aussage: B – Gestagen verändert den Schleim am Gebärmutterhals. Der veränderte Schleim erschwert Spermien den Weg.
- B: Gestagen verändert den Schleim am Gebärmutterhals. **(richtig)** – Die markierte biologische Aussage passt. Der veränderte Schleim erschwert Spermien den Weg. Deine eigene Begründung auf Papier wird nicht automatisch fachlich bewertet.
- C: Sie wirkt ausschließlich durch Kupfer. **(falsch)** – Du verwechselst die Hormonspirale mit der Kupferspirale.
  - Hilfe 1: Lies auf deiner Karte: Hormon und Schleim am Gebärmutterhals; Schutz vor Infektionen.
  - Hilfe 2: Die Hormonspirale gibt ein Gestagen ab.
  - Hilfe 3: Welche Struktur verändert das Gestagen?
  - Hilfe 4: Der Schleim wird schwerer durchlässig für Spermien; das belegt keinen STI-Schutz.
  - Hilfe 5: Passende Aussage: B – Gestagen verändert den Schleim am Gebärmutterhals. Der veränderte Schleim erschwert Spermien den Weg.
- Hilfen ohne Auswahl: Lies auf deiner Karte: Hormon und Schleim am Gebärmutterhals; Schutz vor Infektionen. → Prüfe, welche Aussage durch die biologische Wirkweise gedeckt ist. → Welche Struktur verändert das Gestagen? → Der Schleim wird schwerer durchlässig für Spermien; das belegt keinen STI-Schutz. → Passende Aussage: B – Gestagen verändert den Schleim am Gebärmutterhals. Der veränderte Schleim erschwert Spermien den Weg.
- **Nach Lösungshilfe:** In einem Modell verändert Gestagen den Schleim am Gebärmutterhals. Welche Aussage passt?
  - Spermien können schwerer hindurchgelangen; STI-Schutz ist dadurch nicht belegt. (richtig) – Das Modell betrifft den Spermienweg, nicht den Schutz vor Infektionen.
  - Der Gebärmutterhals ist ein vollständig dichter Verschluss für alle Erreger. (falsch) – Der Schleim wird schwerer durchlässig, nicht als vollständiger Verschluss dargestellt. Unterscheide Erschweren und Verhindern.
  - Die Hormonspirale enthält als Wirkstoff nur Kupfer. (falsch) – Das ist die andere Spiralenart. Beachte den Wirkstoff im Modell.
Kehre zum Chat zurück. Gib deinen Buchstaben ein, tippe auf „Code prüfen“ und danach auf „Nachricht senden“.
Nächstes Kapitel: 4B

## 4B – Hormonspirale: Alltag und Einlage

Informationsmaterial (auf dem iPad sichtbar, beim Antworten wieder aufrufbar):
- **Schutz im Alltag:** Längerfristige Hormonabgabe; sehr zuverlässiger Schwangerschaftsschutz ohne tägliche Einnahme. Lagekontrolle in der Praxis.
- **Einsetzen und Entscheidung:** Ärztliches Einsetzen in die Gebärmutter kann schmerzhaft sein. Medizinische Eignung und persönliche Zustimmung vorher klären.
- **Blutung und Regelschmerzen:** Blutungen können zunächst unregelmäßig sein; später können Blutung und Schmerzen schwächer werden. Keine Garantie. Starke ungeklärte Schmerzen ärztlich abklären lassen.

Ergänzender kurzer Fachhinweis: Zum Vergleich: Mit Kupfer können Blutungen und Regelschmerzen stärker werden. Die Kombinationspille wird regelmäßig nach Einnahmeplan genommen.

Bildimpuls: Vergleiche die Anwendung mit der Pille und die möglichen Beschwerden mit der Kupferspirale.

**4B-Q1-MSA** – Welche Aussage trennt Hormonwirkung und Art der Anwendung?
- 1: Die Hormonspirale gibt ein Gestagen langfristig ab; die Kombinationspille wird regelmäßig nach Plan eingenommen. **(richtig)** – Hormone können über verschiedene Anwendungsformen bereitgestellt werden. Die Einlage erfordert Eignung und Zustimmung.
- 2: Beide erfordern täglich eine Tablette. **(falsch)** – Du setzt den Wirkstoff mit der Anwendungsform gleich.
  - Hilfe 1: Lies im Informationsmaterial: Schutz im Alltag; Einsetzen und Entscheidung.
  - Hilfe 2: Vergleiche die Langzeitabgabe mit der Tabletteneinnahme.
  - Hilfe 3: Wie gelangt das Hormon bei beiden Methoden zur Wirkung?
  - Hilfe 4: Hormonhaltig bedeutet nicht automatisch täglich einzunehmen.
  - Hilfe 5: Passende Aussage: Die Hormonspirale gibt ein Gestagen langfristig ab; die Kombinationspille wird regelmäßig nach Plan eingenommen. Hormone können über verschiedene Anwendungsformen bereitgestellt werden. Die Einlage erfordert Eignung und Zustimmung.
- 3: Weil sie langfristig wirkt, braucht die Hormonspirale kein ärztliches Einsetzen. **(falsch)** – Du verwechselst den Vorteil im Alltag mit einer Voraussetzung der Methode.
  - Hilfe 1: Lies im Informationsmaterial: Schutz im Alltag; Einsetzen und Entscheidung.
  - Hilfe 2: Prüfe den Abschnitt „Einsetzen und Entscheidung“.
  - Hilfe 3: Wie gelangt das Hormon bei beiden Methoden zur Wirkung?
  - Hilfe 4: Hormonhaltig bedeutet nicht automatisch täglich einzunehmen.
  - Hilfe 5: Passende Aussage: Die Hormonspirale gibt ein Gestagen langfristig ab; die Kombinationspille wird regelmäßig nach Plan eingenommen. Hormone können über verschiedene Anwendungsformen bereitgestellt werden. Die Einlage erfordert Eignung und Zustimmung.
- Hilfen ohne Auswahl: Lies im Informationsmaterial: Schutz im Alltag; Einsetzen und Entscheidung. → Vergleiche die Aussagen mit dem beschriebenen biologischen Mechanismus. → Wie gelangt das Hormon bei beiden Methoden zur Wirkung? → Hormonhaltig bedeutet nicht automatisch täglich einzunehmen. → Passende Aussage: Die Hormonspirale gibt ein Gestagen langfristig ab; die Kombinationspille wird regelmäßig nach Plan eingenommen. Hormone können über verschiedene Anwendungsformen bereitgestellt werden. Die Einlage erfordert Eignung und Zustimmung.
- **Nach Lösungshilfe:** Eine Hormonspirale liegt bereits korrekt. Welche Aussage über den Alltag passt?
  - Die Lage ist ab dann grundsätzlich unwichtig. (falsch) – Der korrekte Sitz gehört zu den Voraussetzungen. Kontrollen sind nicht dasselbe wie tägliche Einnahme.
  - Keine tägliche Tablette; Lagekontrollen bleiben sinnvoll bzw. vorgesehen. (richtig) – Die langfristige Abgabe ersetzt tägliche Einnahme, nicht medizinische Betreuung.
  - Täglich muss eine weitere Hormonspirale eingelegt werden. (falsch) – Sie ist eine Langzeitmethode. Prüfe die Anwendungsform.

**4B-Q2-MSA** – Welche Aussage vergleicht die möglichen Auswirkungen der beiden Spiralen korrekt?
- 1: Da beide in der Gebärmutter liegen, sind ihre Auswirkungen sicher identisch. **(falsch)** – Du schließt aus dem gemeinsamen Ort auf gleiche Wirkung.
  - Hilfe 1: Lies im Informationsmaterial: Blutung und Regelschmerzen; Einsetzen und Entscheidung.
  - Hilfe 2: Kupfer und Gestagen wirken unterschiedlich.
  - Hilfe 3: Welche Richtung der möglichen Veränderung wird bei welcher Methode beschrieben?
  - Hilfe 4: Beide Aussagen enthalten das Wort „kann“.
  - Hilfe 5: Passende Aussage: Kupfer kann Schmerzen verstärken, eine Hormonspirale kann sie später lindern; die individuelle Reaktion bleibt offen. Die Methoden können unterschiedliche Auswirkungen auf Blutung und Schmerz haben. Keine dieser Möglichkeiten ist garantiert.
- 2: Kupfer kann Schmerzen verstärken, eine Hormonspirale kann sie später lindern; die individuelle Reaktion bleibt offen. **(richtig)** – Die Methoden können unterschiedliche Auswirkungen auf Blutung und Schmerz haben. Keine dieser Möglichkeiten ist garantiert.
- 3: Kupfer lindert immer, Hormone verstärken immer. **(falsch)** – Du vertauschst die möglichen Wirkungen und verallgemeinerst sie.
  - Hilfe 1: Lies im Informationsmaterial: Blutung und Regelschmerzen; Einsetzen und Entscheidung.
  - Hilfe 2: Vergleiche beide Kartenabschnitte zur Regel.
  - Hilfe 3: Welche Richtung der möglichen Veränderung wird bei welcher Methode beschrieben?
  - Hilfe 4: Beide Aussagen enthalten das Wort „kann“.
  - Hilfe 5: Passende Aussage: Kupfer kann Schmerzen verstärken, eine Hormonspirale kann sie später lindern; die individuelle Reaktion bleibt offen. Die Methoden können unterschiedliche Auswirkungen auf Blutung und Schmerz haben. Keine dieser Möglichkeiten ist garantiert.
- Hilfen ohne Auswahl: Lies im Informationsmaterial: Blutung und Regelschmerzen; Einsetzen und Entscheidung. → Vergleiche die Aussagen mit dem beschriebenen biologischen Mechanismus. → Welche Richtung der möglichen Veränderung wird bei welcher Methode beschrieben? → Beide Aussagen enthalten das Wort „kann“. → Passende Aussage: Kupfer kann Schmerzen verstärken, eine Hormonspirale kann sie später lindern; die individuelle Reaktion bleibt offen. Die Methoden können unterschiedliche Auswirkungen auf Blutung und Schmerz haben. Keine dieser Möglichkeiten ist garantiert.
- **Nach Lösungshilfe:** Eine Person berichtet über eine Linderung der Schmerzen durch eine Hormonspirale. Was lässt sich auf andere übertragen?
  - Eine Linderung ist bei allen sicher. (falsch) – Du verallgemeinerst die Einzelerfahrung. Trenne Möglichkeit und Gewissheit.
  - Die Zustimmung zur Einlage ist deshalb unwichtig. (falsch) – Ein möglicher Nutzen ersetzt keine Zustimmung. Die Entscheidung bleibt bei der Person.
  - Eine Linderung ist möglich, nicht garantiert; die individuelle Eignung bleibt zu klären. (richtig) – Eine Einzelerfahrung stützt eine Möglichkeit, keine sichere Prognose.

**Nach bestandener Prüfung – Papier:** Papier · 4B – Hormonspirale: Ergänze die Felder 3, 4 genau wie angezeigt. Vergleiche deine Einträge.
- Feld 3 (4B-3, Schutz im Alltag): **tägliche Einnahme**
- Feld 4 (4B-4, Blutung und Regelschmerzen): **schwächer**
Kein Code. Nach Vergleich „Weiter im Chat“.
Vergleich mit vollständiger Karte des eigenen Niveaus. Auf Papier „Karte kontrolliert“ markieren. Keine rückwirkende digitale Freigabe.
Nächstes Kapitel: Abschluss; Karten vollständig prüfen.

# AHR

## Pearl-Index
Der Pearl-Index ist eine Rate: Schwangerschaften pro 100 Frauenjahre der Anwendung. Im einfachen Beispiel entsprechen drei Schwangerschaften bei 100 Frauenjahren dem Wert 3. Kleinere Werte weisen unter vergleichbaren Studienbedingungen auf zuverlässigeren Schwangerschaftsschutz hin. Unterschiedliche Erfassung, Anwendungsfehler und Präparate können den Vergleich beeinflussen. Die Karten verwenden zusammengehörige historische Orientierungswerte. Nicht als individuelle Wahrscheinlichkeit oder Maß für STI-Schutz ausgeben.
**PI-Q1-AHR** – Zwei Pearl-Index-Angaben stammen aus Studien mit unterschiedlichen Anwendungsbedingungen. Welche Deutung ist fachlich vertretbar?
- 1: Die Werte liefern automatisch eine Rangfolge des STI-Schutzes. **(falsch)** – Du schließt auf eine andere, nicht gemessene Schutzwirkung.
  - Hilfe 1: Lies im Informationsmaterial: Pearl-Index (Definition auf jeder Karte).
  - Hilfe 2: Der Index misst Schwangerschaften, keine Erregerübertragung.
  - Hilfe 3: Welche Bedingungen könnten die erfassten Schwangerschaften beeinflussen?
  - Hilfe 4: Eine statistische Kennzahl lässt sich nicht unbesehen zwischen Studien übertragen.
  - Hilfe 5: Passende Aussage: Sie geben Orientierung zum Schwangerschaftsschutz; für einen direkten Vergleich müssen Studien- und Anwendungsbedingungen beachtet werden. Der Pearl-Index ist eine statistische Rate bezogen auf 100 Frauenjahre und keine individuelle Garantie. Andere Schutzwirkungen misst er nicht.
- 2: Sie geben Orientierung zum Schwangerschaftsschutz; für einen direkten Vergleich müssen Studien- und Anwendungsbedingungen beachtet werden. **(richtig)** – Der Pearl-Index ist eine statistische Rate bezogen auf 100 Frauenjahre und keine individuelle Garantie. Andere Schutzwirkungen misst er nicht.
- 3: Jede Person hat exakt die angegebene jährliche Schwangerschaftswahrscheinlichkeit. **(falsch)** – Du machst aus einer Studienkennzahl eine individuelle Prognose.
  - Hilfe 1: Lies im Informationsmaterial: Pearl-Index (Definition auf jeder Karte).
  - Hilfe 2: Vergleiche Gruppenwert und persönliche Wahrscheinlichkeit.
  - Hilfe 3: Welche Bedingungen könnten die erfassten Schwangerschaften beeinflussen?
  - Hilfe 4: Eine statistische Kennzahl lässt sich nicht unbesehen zwischen Studien übertragen.
  - Hilfe 5: Passende Aussage: Sie geben Orientierung zum Schwangerschaftsschutz; für einen direkten Vergleich müssen Studien- und Anwendungsbedingungen beachtet werden. Der Pearl-Index ist eine statistische Rate bezogen auf 100 Frauenjahre und keine individuelle Garantie. Andere Schutzwirkungen misst er nicht.
- Hilfen ohne Auswahl: Lies im Informationsmaterial: Pearl-Index (Definition auf jeder Karte). → Vergleiche die Aussagen mit dem beschriebenen biologischen Mechanismus. → Welche Bedingungen könnten die erfassten Schwangerschaften beeinflussen? → Eine statistische Kennzahl lässt sich nicht unbesehen zwischen Studien übertragen. → Passende Aussage: Sie geben Orientierung zum Schwangerschaftsschutz; für einen direkten Vergleich müssen Studien- und Anwendungsbedingungen beachtet werden. Der Pearl-Index ist eine statistische Rate bezogen auf 100 Frauenjahre und keine individuelle Garantie. Andere Schutzwirkungen misst er nicht.
- **Nach Lösungshilfe:** Was müsste zusätzlich bekannt sein, um unterschiedliche Pearl-Index-Angaben sinnvoll zu vergleichen?
  - Nur, ob beide Werte auf 100 Frauenjahre bezogen sind. (falsch) – Die gleiche Bezugsgröße allein reicht nicht. Welche Bedingungen können sich trotz gleicher Einheit unterscheiden?
  - Die Studien- und Anwendungsbedingungen. (richtig) – Eine gleiche Bezugsgröße allein macht verschiedene Untersuchungen nicht vollständig vergleichbar.
  - Die Zahl der STI allein. (falsch) – Diese Zahl gehört zu einer anderen Messgröße. Frage nach der Anwendung der Verhütungsmethode.

## 1A – Kondom: Material und Barriere

Informationsmaterial (auf dem iPad sichtbar, beim Antworten wieder aufrufbar):
- **Material und Allergie:** Latexallergie betrifft das Material, nicht die Methode. Geeignete synthetische Kondome ohne Latex (z. B. Polyurethan, Polyisopren) sind eine Alternative. Packungsangaben prüfen.
- **Barriere und Schwangerschaft:** Eine intakte, korrekt sitzende Hülle hält Sperma zurück: mechanische Barriere, hormonfrei.

Bildimpuls: Welche Angaben belegen Material und welche die Eignung?

**1A-Q1-AHR** – Ein Produkt trägt nur den Hinweis „latexfrei“. Was lässt sich daraus sicher ableiten?
- 1: Es enthält kein Latex; die Eignung zur Verhütung muss zusätzlich geprüft werden. **(richtig)** – Latexfreiheit ist eine Materialeigenschaft, aber allein kein Nachweis von Verhütungssicherheit.
- 2: Es bietet automatisch dieselbe Verhütungssicherheit wie jedes geeignete Kondom. **(falsch)** – Du verallgemeinerst eine einzelne Materialangabe.
  - Hilfe 1: Lies im Informationsmaterial: Material und Allergie.
  - Hilfe 2: Welche zweite Angabe muss auf einem geeigneten Produkt geprüft werden?
  - Hilfe 3: Trennt die Angabe etwas über Zusammensetzung von etwas über Funktion?
  - Hilfe 4: Eine Materialangabe ist noch keine Zweck- oder Wirksamkeitsangabe.
  - Hilfe 5: Passende Aussage: Es enthält kein Latex; die Eignung zur Verhütung muss zusätzlich geprüft werden. Latexfreiheit ist eine Materialeigenschaft, aber allein kein Nachweis von Verhütungssicherheit.
- 3: Ein latexfreies Produkt kann grundsätzlich keine Barriere bilden. **(falsch)** – Du machst die mechanische Wirkung von Latex allein abhängig.
  - Hilfe 1: Lies im Informationsmaterial: Material und Allergie.
  - Hilfe 2: Es kommt darauf an, ob die Hülle für die Aufgabe geeignet ist.
  - Hilfe 3: Trennt die Angabe etwas über Zusammensetzung von etwas über Funktion?
  - Hilfe 4: Eine Materialangabe ist noch keine Zweck- oder Wirksamkeitsangabe.
  - Hilfe 5: Passende Aussage: Es enthält kein Latex; die Eignung zur Verhütung muss zusätzlich geprüft werden. Latexfreiheit ist eine Materialeigenschaft, aber allein kein Nachweis von Verhütungssicherheit.
- Hilfen ohne Auswahl: Lies im Informationsmaterial: Material und Allergie. → Vergleiche die Aussagen mit dem beschriebenen biologischen Mechanismus. → Trennt die Angabe etwas über Zusammensetzung von etwas über Funktion? → Eine Materialangabe ist noch keine Zweck- oder Wirksamkeitsangabe. → Passende Aussage: Es enthält kein Latex; die Eignung zur Verhütung muss zusätzlich geprüft werden. Latexfreiheit ist eine Materialeigenschaft, aber allein kein Nachweis von Verhütungssicherheit.
- **Nach Lösungshilfe:** Ein latexfreies Produkt ist nicht zur Verhütung ausgewiesen. Was folgt aus dem Etikett allein?
  - Es muss Hormone enthalten. (falsch) – Latexfreiheit sagt nichts über Hormone aus. Prüfe, welche Eigenschaft überhaupt angegeben wurde.
  - Eine Verhütungswirkung ist daraus nicht nachgewiesen. (richtig) – Materialangabe und nachgewiesene Eignung sind nicht dasselbe.
  - Es schützt nachweislich vor Schwangerschaft. (falsch) – Die Angabe zur Eignung fehlt. Trenne Material von nachgewiesener Funktion.

**1A-Q2-AHR** – Welche Erklärung verknüpft Wirkprinzip und Voraussetzung korrekt?
- 1: Die Hülle verhindert die Bildung von Spermien. **(falsch)** – Du verwechselst den Weg vorhandener Spermien mit ihrer Bildung.
  - Hilfe 1: Lies im Informationsmaterial: Barriere und Schwangerschaft.
  - Hilfe 2: Wo wirkt die Hülle räumlich?
  - Hilfe 3: An welcher Stelle wird der Weg zur Eizelle unterbrochen?
  - Hilfe 4: Eine Aussage zur Barriere muss auch ihre Intaktheit berücksichtigen.
  - Hilfe 5: Passende Aussage: Eine korrekt sitzende, intakte Hülle hält Sperma zurück; ihre Wirksamkeit hängt von der Barriere ab. Die Barriere verändert weder Eisprung noch Befruchtungsfähigkeit, sondern den Weg der Spermien.
- 2: Der Schutz beruht auf der Hemmung des Eisprungs. **(falsch)** – Du beschreibst die Kombinationspille.
  - Hilfe 1: Lies im Informationsmaterial: Barriere und Schwangerschaft.
  - Hilfe 2: Mechanische und hormonelle Wirkung sind verschieden.
  - Hilfe 3: An welcher Stelle wird der Weg zur Eizelle unterbrochen?
  - Hilfe 4: Eine Aussage zur Barriere muss auch ihre Intaktheit berücksichtigen.
  - Hilfe 5: Passende Aussage: Eine korrekt sitzende, intakte Hülle hält Sperma zurück; ihre Wirksamkeit hängt von der Barriere ab. Die Barriere verändert weder Eisprung noch Befruchtungsfähigkeit, sondern den Weg der Spermien.
- 3: Eine korrekt sitzende, intakte Hülle hält Sperma zurück; ihre Wirksamkeit hängt von der Barriere ab. **(richtig)** – Die Barriere verändert weder Eisprung noch Befruchtungsfähigkeit, sondern den Weg der Spermien.
- Hilfen ohne Auswahl: Lies im Informationsmaterial: Barriere und Schwangerschaft. → Vergleiche die Aussagen mit dem beschriebenen biologischen Mechanismus. → An welcher Stelle wird der Weg zur Eizelle unterbrochen? → Eine Aussage zur Barriere muss auch ihre Intaktheit berücksichtigen. → Passende Aussage: Eine korrekt sitzende, intakte Hülle hält Sperma zurück; ihre Wirksamkeit hängt von der Barriere ab. Die Barriere verändert weder Eisprung noch Befruchtungsfähigkeit, sondern den Weg der Spermien.
- **Nach Lösungshilfe:** Ein intaktes Kondom rutscht ab. Welche Voraussetzung ist verletzt?
  - Der Zyklus wird hormonell verändert. (falsch) – Abrutschen betrifft nicht den Zyklus. Denke an die Hüllenfunktion.
  - Die Spermien werden neu gebildet. (falsch) – Die Spermienbildung wird nicht verändert. Betrachte den Weg vorhandener Spermien.
  - Die Hülle sitzt nicht mehr richtig; Sperma kann austreten. (richtig) – Auch eine intakte Hülle schützt nur bei korrektem Sitz.

**Nach bestandener Prüfung – Papier:** Papier · 1A – Kondom: Ergänze die Felder 1, 2 genau wie angezeigt. Vergleiche deine Einträge.
- Feld 1 (1A-1, Material und Allergie): **synthetische**
- Feld 2 (1A-2, Barriere und Schwangerschaft): **Barriere**

**Gedruckter Fachcheck:** Ein Kondom ohne Latex: Welche Folgerung ist fachlich begründet?
Markiere die passende Aussage. Begründe in wenigen Stichwörtern. Kehre zum Chat zurück und gib den Buchstaben ein.
Erwarteter Grund: Die mechanische Barriere hängt von der Eignung und Intaktheit des Materials ab.
**1A-P-AHR** – Ein Kondom ohne Latex: Welche Folgerung ist fachlich begründet?
- A: Hormonfreiheit bedeutet fehlenden Schutz. **(falsch)** – Du setzt Hormonfreiheit mit fehlender Verhütung gleich.
  - Hilfe 1: Lies auf deiner Karte: Material und Allergie; Barriere und Schwangerschaft.
  - Hilfe 2: Prüfe die mechanische Funktion der Hülle.
  - Hilfe 3: Welche Aufgabe kann die Hülle unabhängig vom Material erfüllen?
  - Hilfe 4: Ein geeignetes Material hält Sperma mechanisch zurück. Hormonwirkung ist dafür nicht nötig.
  - Hilfe 5: Passende Aussage: B – Ein geeignetes Material kann dieselbe Barriere bilden. Die mechanische Barriere hängt von der Eignung und Intaktheit des Materials ab.
- B: Ein geeignetes Material kann dieselbe Barriere bilden. **(richtig)** – Die markierte biologische Aussage passt. Die mechanische Barriere hängt von der Eignung und Intaktheit des Materials ab. Deine eigene Begründung auf Papier wird nicht automatisch fachlich bewertet.
- C: Jedes latexfreie Material verhütet gleich zuverlässig. **(falsch)** – Du verallgemeinerst eine einzelne Materialeigenschaft.
  - Hilfe 1: Lies auf deiner Karte: Material und Allergie; Barriere und Schwangerschaft.
  - Hilfe 2: Latexfreiheit allein belegt noch keine Eignung zur Verhütung.
  - Hilfe 3: Welche Aufgabe kann die Hülle unabhängig vom Material erfüllen?
  - Hilfe 4: Ein geeignetes Material hält Sperma mechanisch zurück. Hormonwirkung ist dafür nicht nötig.
  - Hilfe 5: Passende Aussage: B – Ein geeignetes Material kann dieselbe Barriere bilden. Die mechanische Barriere hängt von der Eignung und Intaktheit des Materials ab.
- Hilfen ohne Auswahl: Lies auf deiner Karte: Material und Allergie; Barriere und Schwangerschaft. → Prüfe, welche Aussage durch die biologische Wirkweise gedeckt ist. → Welche Aufgabe kann die Hülle unabhängig vom Material erfüllen? → Ein geeignetes Material hält Sperma mechanisch zurück. Hormonwirkung ist dafür nicht nötig. → Passende Aussage: B – Ein geeignetes Material kann dieselbe Barriere bilden. Die mechanische Barriere hängt von der Eignung und Intaktheit des Materials ab.
- **Nach Lösungshilfe:** Ein als geeignet gekennzeichnetes latexfreies Kondom hat einen Riss. Was folgt?
  - Latexfreiheit garantiert trotzdem die Barriere. (falsch) – Die Hülle ist beschädigt. Prüfe die tatsächliche Barriere.
  - Das Kondom hemmt nun den Eisprung. (falsch) – Das ist keine Wirkung eines Kondoms. Trenne Hülle und Zyklus.
  - Die mechanische Barriere kann beeinträchtigt sein. (richtig) – Materialeignung und Intaktheit sind getrennte Voraussetzungen.
Kehre zum Chat zurück. Gib deinen Buchstaben ein, tippe auf „Code prüfen“ und danach auf „Nachricht senden“.
Nächstes Kapitel: 1B

## 1B – Kondom: Schutz und Alltag

Informationsmaterial (auf dem iPad sichtbar, beim Antworten wieder aufrufbar):
- **Schutz vor Infektionen:** Barriere gegen Sperma und viele Erreger: STI-Risiko sinkt, bleibt aber durch unbedeckte Haut und Anwendungsfehler bestehen. Naturmembran ist beim STI-Schutz nicht gleichwertig.
- **Bei jedem Sex:** Bei jedem Sex von Anfang an ein neues Kondom korrekt nutzen. Reißen oder Abrutschen mindert Schutz. Zuverlässigkeit hängt stark von der Anwendung ab.
- **Regelschmerzen:** Keine Veränderung der Regel. Starke, ungeklärte Regelschmerzen ärztlich abklären lassen.

Bildimpuls: Unterscheide die räumliche Grenze und die Anwendungsgrenze.

**1B-Q1-AHR** – Welche Aussage über ein geeignetes synthetisches latexfreies Kondom ist fachlich tragfähig?
- 1: Ein intaktes Kondom schließt alle Infektionen aus. **(falsch)** – Du verabsolutierst den Schutz.
  - Hilfe 1: Lies im Informationsmaterial: Schutz vor Infektionen.
  - Hilfe 2: Denke an nicht bedeckte Haut.
  - Hilfe 3: Welche Übertragungswege werden durch eine Barriere nicht vollständig abgedeckt?
  - Hilfe 4: Unterscheide Risikoverminderung, Restgefahr und Materialeignung.
  - Hilfe 5: Passende Aussage: Es kann das STI-Risiko senken; unbedeckte Haut und Anwendungsfehler begrenzen den Schutz. STI-Risikominderung ist weder eine Garantie noch allein aus Latexfreiheit ableitbar.
- 2: Es kann das STI-Risiko senken; unbedeckte Haut und Anwendungsfehler begrenzen den Schutz. **(richtig)** – STI-Risikominderung ist weder eine Garantie noch allein aus Latexfreiheit ableitbar.
- 3: Latexfreiheit allein beweist gleichwertigen STI-Schutz für jedes Material. **(falsch)** – Du überträgst den Schutz von geeigneten synthetischen Materialien auf alle latexfreien Materialien.
  - Hilfe 1: Lies im Informationsmaterial: Schutz vor Infektionen.
  - Hilfe 2: Die Eignung gegen Erreger muss gesondert betrachtet werden.
  - Hilfe 3: Welche Übertragungswege werden durch eine Barriere nicht vollständig abgedeckt?
  - Hilfe 4: Unterscheide Risikoverminderung, Restgefahr und Materialeignung.
  - Hilfe 5: Passende Aussage: Es kann das STI-Risiko senken; unbedeckte Haut und Anwendungsfehler begrenzen den Schutz. STI-Risikominderung ist weder eine Garantie noch allein aus Latexfreiheit ableitbar.
- Hilfen ohne Auswahl: Lies im Informationsmaterial: Schutz vor Infektionen. → Vergleiche die Aussagen mit dem beschriebenen biologischen Mechanismus. → Welche Übertragungswege werden durch eine Barriere nicht vollständig abgedeckt? → Unterscheide Risikoverminderung, Restgefahr und Materialeignung. → Passende Aussage: Es kann das STI-Risiko senken; unbedeckte Haut und Anwendungsfehler begrenzen den Schutz. STI-Risikominderung ist weder eine Garantie noch allein aus Latexfreiheit ableitbar.
- **Nach Lösungshilfe:** Zwei Produkte haben einen ähnlichen Schwangerschaftsschutz. Welche Information fehlt für den STI-Vergleich?
  - Nur der Pearl-Index. (falsch) – Der Pearl-Index misst keinen STI-Schutz. Suche den Unterschied zwischen beiden Schutzzielen.
  - Ob beide dasselbe Hormon enthalten. (falsch) – Hormone allein begründen keinen Erregerschutz. Frage nach der Barriere und ihrer Eignung.
  - Ob sie Übertragungen von Krankheitserregern ausreichend vermindern. (richtig) – Schwangerschaftsschutz ist kein Beleg für Erregerschutz.

**1B-Q2-AHR** – Warum ist die Zuverlässigkeit des Kondoms besonders von der Anwendung abhängig?
- 1: Bei jedem Sex muss die Barriere von Anfang an korrekt bestehen; Reißen oder Abrutschen kann sie unterbrechen. **(richtig)** – Mechanische Schutzwirkung hängt vom tatsächlichen Sitz und der Intaktheit bei jeder Anwendung ab.
- 2: Bei häufiger Anwendung hemmt es dauerhaft den Eisprung. **(falsch)** – Du verwechselst eine mechanische Anwendung mit einer Hormonwirkung.
  - Hilfe 1: Lies im Informationsmaterial: Bei jedem Sex; Regelschmerzen.
  - Hilfe 2: Das Kondom wirkt nicht dauerhaft auf den Zyklus.
  - Hilfe 3: Vergleiche das Wirkprinzip mit einem mehrjährig liegenden Verhütungsmittel.
  - Hilfe 4: Eine theoretisch wirksame Barriere kann durch ihre Anwendung beeinträchtigt werden.
  - Hilfe 5: Passende Aussage: Bei jedem Sex muss die Barriere von Anfang an korrekt bestehen; Reißen oder Abrutschen kann sie unterbrechen. Mechanische Schutzwirkung hängt vom tatsächlichen Sitz und der Intaktheit bei jeder Anwendung ab.
- 3: Der Pearl-Index garantiert Schutz unabhängig vom Sitz. **(falsch)** – Du deutest einen Richtwert als persönliche Garantie.
  - Hilfe 1: Lies im Informationsmaterial: Bei jedem Sex; Regelschmerzen.
  - Hilfe 2: Die Anwendungsbedingungen können die Zuverlässigkeit verändern.
  - Hilfe 3: Vergleiche das Wirkprinzip mit einem mehrjährig liegenden Verhütungsmittel.
  - Hilfe 4: Eine theoretisch wirksame Barriere kann durch ihre Anwendung beeinträchtigt werden.
  - Hilfe 5: Passende Aussage: Bei jedem Sex muss die Barriere von Anfang an korrekt bestehen; Reißen oder Abrutschen kann sie unterbrechen. Mechanische Schutzwirkung hängt vom tatsächlichen Sitz und der Intaktheit bei jeder Anwendung ab.
- Hilfen ohne Auswahl: Lies im Informationsmaterial: Bei jedem Sex; Regelschmerzen. → Vergleiche die Aussagen mit dem beschriebenen biologischen Mechanismus. → Vergleiche das Wirkprinzip mit einem mehrjährig liegenden Verhütungsmittel. → Eine theoretisch wirksame Barriere kann durch ihre Anwendung beeinträchtigt werden. → Passende Aussage: Bei jedem Sex muss die Barriere von Anfang an korrekt bestehen; Reißen oder Abrutschen kann sie unterbrechen. Mechanische Schutzwirkung hängt vom tatsächlichen Sitz und der Intaktheit bei jeder Anwendung ab.
- **Nach Lösungshilfe:** Jemand benutzt Kondome korrekt und hat starke ungeklärte Regelschmerzen. Welche Aussage passt?
  - Die korrekte Anwendung lindert sicher die Schmerzen. (falsch) – Eine solche Wirkung ist nicht belegt. Kondome verändern den Zyklus nicht.
  - Kondome verursachen zwangsläufig die Schmerzen. (falsch) – Ein zeitlicher Zusammenhang beweist keine Ursache. Die Beschwerden bedürfen einer eigenen Abklärung.
  - Kondome verändern die Regel nicht; die Schmerzen sollten ärztlich abgeklärt werden. (richtig) – Der Schutz beim Sex und die Abklärung ungeklärter Beschwerden sind getrennte Fragen.

**Nach bestandener Prüfung – Papier:** Papier · 1B – Kondom: Ergänze die Felder 3, 4 genau wie angezeigt. Vergleiche deine Einträge.
- Feld 3 (1B-3, Schutz vor Infektionen): **nicht gleichwertig**
- Feld 4 (1B-4, Bei jedem Sex): **von Anfang an**
Kein Code. Nach Vergleich „Weiter im Chat“.
Vergleich mit vollständiger Karte des eigenen Niveaus. Auf Papier „Karte kontrolliert“ markieren. Keine rückwirkende digitale Freigabe.
Nächstes Kapitel: 2A

## 2A – Kombinationspille: Hormone und Schutzwirkung

Informationsmaterial (auf dem iPad sichtbar, beim Antworten wieder aufrufbar):
- **Hormone und Eisprung:** Östrogen und Gestagen hemmen vor allem den Eisprung. Ohne Eisprung steht in diesem Zyklus keine befruchtbare Eizelle zur Verfügung.
- **Schutz vor Infektionen:** Zykluswirkung erzeugt keine Barriere für Krankheitserreger: kein STI-Schutz.

Ergänzender kurzer Fachhinweis: Wirkprinzip und korrekte Anwendung sind getrennt zu betrachten. Aus der Hemmung des Eisprungs folgt keine Anwendungsgarantie.

Bildimpuls: Welche Wirkung zeigt das Modell und welche zeigt es nicht?

**2A-Q1-AHR** – Welche Schlussfolgerung erklärt den Schwangerschaftsschutz der Kombinationspille, ohne ihn zu garantieren?
- 1: Weil der Eisprung gehemmt wird, ist eine Schwangerschaft bei jedem Einnahmeverhalten unmöglich. **(falsch)** – Du machst aus dem Wirkprinzip eine Anwendungsgarantie.
  - Hilfe 1: Lies im Informationsmaterial: Hormone und Eisprung.
  - Hilfe 2: Wirksamkeit und Einnahmebedingungen gehören zusammen.
  - Hilfe 3: Welche Bedingung für eine Befruchtung fällt bei unterdrücktem Eisprung weg?
  - Hilfe 4: Trenne Wirkprinzip von einer garantierten Wirkung.
  - Hilfe 5: Passende Aussage: Ihre Hormone hemmen vor allem den Eisprung; bei ausbleibendem Eisprung fehlt die freigesetzte Eizelle. Der Mechanismus erklärt Schutz unter wirksamer Anwendung, nicht hundertprozentige Sicherheit.
- 2: Ihre Hormone hemmen vor allem den Eisprung; bei ausbleibendem Eisprung fehlt die freigesetzte Eizelle. **(richtig)** – Der Mechanismus erklärt Schutz unter wirksamer Anwendung, nicht hundertprozentige Sicherheit.
- 3: Bei jeder Einnahme werden vorhandene Spermien mechanisch abgefangen. **(falsch)** – Du behauptest eine Barriere, die es bei der Pille nicht gibt.
  - Hilfe 1: Lies im Informationsmaterial: Hormone und Eisprung.
  - Hilfe 2: Betrachte die Wirkung auf den Zyklus.
  - Hilfe 3: Welche Bedingung für eine Befruchtung fällt bei unterdrücktem Eisprung weg?
  - Hilfe 4: Trenne Wirkprinzip von einer garantierten Wirkung.
  - Hilfe 5: Passende Aussage: Ihre Hormone hemmen vor allem den Eisprung; bei ausbleibendem Eisprung fehlt die freigesetzte Eizelle. Der Mechanismus erklärt Schutz unter wirksamer Anwendung, nicht hundertprozentige Sicherheit.
- Hilfen ohne Auswahl: Lies im Informationsmaterial: Hormone und Eisprung. → Vergleiche die Aussagen mit dem beschriebenen biologischen Mechanismus. → Welche Bedingung für eine Befruchtung fällt bei unterdrücktem Eisprung weg? → Trenne Wirkprinzip von einer garantierten Wirkung. → Passende Aussage: Ihre Hormone hemmen vor allem den Eisprung; bei ausbleibendem Eisprung fehlt die freigesetzte Eizelle. Der Mechanismus erklärt Schutz unter wirksamer Anwendung, nicht hundertprozentige Sicherheit.
- **Nach Lösungshilfe:** Eine Methode verhindert vor allem die Freisetzung der Eizelle. Welche Methode ist hier gemeint?
  - Kupferspirale. (falsch) – Kupfer beeinträchtigt Spermien. Der beschriebene Mechanismus betrifft die Eizelle.
  - Kombinationspille. (richtig) – Ihre Hormone wirken vor allem auf den Eisprung.
  - Kondom. (falsch) – Das Kondom hält Sperma zurück. Vergleiche den Wirkungsort.

**2A-Q2-AHR** – Welche Behauptung lässt sich mit dem Mechanismus der Kombinationspille begründet zurückweisen?
- 1: „Die Pille hemmt vor allem den Eisprung.“ **(falsch)** – Diese Aussage ist durch die Wirkweise gedeckt.
  - Hilfe 1: Lies im Informationsmaterial: Schutz vor Infektionen.
  - Hilfe 2: Suche stattdessen eine unzulässige Aussage über Infektionen.
  - Hilfe 3: Sind Eisprung und Erregerübertragung ursächlich gekoppelt?
  - Hilfe 4: Der Zyklusmechanismus belegt nur einen Beitrag zur Schwangerschaftsverhütung.
  - Hilfe 5: Passende Aussage: „Ein unterdrückter Eisprung verhindert auch die Übertragung von STI.“ Krankheitserreger brauchen für ihre Übertragung keinen Eisprung; die Pille erzeugt keine Barriere.
- 2: „Die Pille enthält Östrogen und Gestagen.“ **(falsch)** – Diese Aussage beschreibt die Zusammensetzung korrekt.
  - Hilfe 1: Lies im Informationsmaterial: Schutz vor Infektionen.
  - Hilfe 2: Welche Behauptung überschreitet die belegte Schutzwirkung?
  - Hilfe 3: Sind Eisprung und Erregerübertragung ursächlich gekoppelt?
  - Hilfe 4: Der Zyklusmechanismus belegt nur einen Beitrag zur Schwangerschaftsverhütung.
  - Hilfe 5: Passende Aussage: „Ein unterdrückter Eisprung verhindert auch die Übertragung von STI.“ Krankheitserreger brauchen für ihre Übertragung keinen Eisprung; die Pille erzeugt keine Barriere.
- 3: „Ein unterdrückter Eisprung verhindert auch die Übertragung von STI.“ **(richtig)** – Krankheitserreger brauchen für ihre Übertragung keinen Eisprung; die Pille erzeugt keine Barriere.
- Hilfen ohne Auswahl: Lies im Informationsmaterial: Schutz vor Infektionen. → Vergleiche die Aussagen mit dem beschriebenen biologischen Mechanismus. → Sind Eisprung und Erregerübertragung ursächlich gekoppelt? → Der Zyklusmechanismus belegt nur einen Beitrag zur Schwangerschaftsverhütung. → Passende Aussage: „Ein unterdrückter Eisprung verhindert auch die Übertragung von STI.“ Krankheitserreger brauchen für ihre Übertragung keinen Eisprung; die Pille erzeugt keine Barriere.
- **Nach Lösungshilfe:** Zwei Tabellen geben Schwangerschaftsschutz und STI-Schutz an. Wo ist die Zykluswirkung der Pille relevant?
  - Bei beiden automatisch gleich. (falsch) – Ein gemeinsames Maß ist hier nicht belegt. Trenne die Vorgänge.
  - Nur beim STI-Schutz. (falsch) – Die Wirkweise betrifft eine Voraussetzung der Befruchtung. Betrachte den Eisprung.
  - Beim Schwangerschaftsschutz, nicht als Nachweis von STI-Schutz. (richtig) – Die Schutzwirkungen haben verschiedene biologische Voraussetzungen.

**Nach bestandener Prüfung – Papier:** Papier · 2A – Kombinationspille: Ergänze die Felder 1, 2 genau wie angezeigt. Vergleiche deine Einträge.
- Feld 1 (2A-1, Hormone und Eisprung): **Eisprung**
- Feld 2 (2A-2, Schutz vor Infektionen): **Barriere**

**Gedruckter Fachcheck:** Welche Schlussfolgerung aus der Zykluswirkung ist korrekt?
Markiere die passende Aussage. Begründe in wenigen Stichwörtern. Kehre zum Chat zurück und gib den Buchstaben ein.
Erwarteter Grund: Hemmung des Eisprungs verhindert eine Befruchtung; keine Erregerbarriere.
**2A-P-AHR** – Welche Schlussfolgerung aus der Zykluswirkung ist korrekt?
- A: Ohne Eisprung kann keine Eizelle befruchtet werden. **(richtig)** – Die markierte biologische Aussage passt. Hemmung des Eisprungs verhindert eine Befruchtung; keine Erregerbarriere. Deine eigene Begründung auf Papier wird nicht automatisch fachlich bewertet.
- B: Die Zykluswirkung schließt eine STI-Übertragung aus. **(falsch)** – Du überträgst die Zykluswirkung auf STI.
  - Hilfe 1: Lies auf deiner Karte: Hormone und Eisprung; Schutz vor Infektionen.
  - Hilfe 2: Krankheitserreger brauchen keinen Eisprung für eine Übertragung.
  - Hilfe 3: Was fehlt, wenn keine Eizelle freigesetzt wird?
  - Hilfe 4: Die Pille wirkt vor allem auf den Eisprung; sie bildet keine Erregerbarriere.
  - Hilfe 5: Passende Aussage: A – Ohne Eisprung kann keine Eizelle befruchtet werden. Hemmung des Eisprungs verhindert eine Befruchtung; keine Erregerbarriere.
- C: Östrogen hält Spermien mechanisch zurück. **(falsch)** – Du gibst Östrogen eine mechanische Hüllenfunktion.
  - Hilfe 1: Lies auf deiner Karte: Hormone und Eisprung; Schutz vor Infektionen.
  - Hilfe 2: Das Hormon beeinflusst den Zyklus; es hält Spermien nicht als Hülle zurück.
  - Hilfe 3: Was fehlt, wenn keine Eizelle freigesetzt wird?
  - Hilfe 4: Die Pille wirkt vor allem auf den Eisprung; sie bildet keine Erregerbarriere.
  - Hilfe 5: Passende Aussage: A – Ohne Eisprung kann keine Eizelle befruchtet werden. Hemmung des Eisprungs verhindert eine Befruchtung; keine Erregerbarriere.
- Hilfen ohne Auswahl: Lies auf deiner Karte: Hormone und Eisprung; Schutz vor Infektionen. → Prüfe, welche Aussage durch die biologische Wirkweise gedeckt ist. → Was fehlt, wenn keine Eizelle freigesetzt wird? → Die Pille wirkt vor allem auf den Eisprung; sie bildet keine Erregerbarriere. → Passende Aussage: A – Ohne Eisprung kann keine Eizelle befruchtet werden. Hemmung des Eisprungs verhindert eine Befruchtung; keine Erregerbarriere.
- **Nach Lösungshilfe:** Die hormonelle Hemmung des Eisprungs gelingt. Welche Aussage ist richtig?
  - Sperma wird außerhalb des Körpers aufgefangen. (falsch) – Das ist die Kondomwirkung. Betrachte den Wirkungsort der Pille.
  - Es wird keine Eizelle zur Befruchtung freigesetzt; eine Erregerbarriere entsteht nicht. (richtig) – Die Wirkung auf den Zyklus ist kein STI-Schutz.
  - Auch jede Übertragung von Krankheitserregern wird verhindert. (falsch) – Das folgt aus der Zykluswirkung nicht. Erreger benötigen keinen Eisprung.
Kehre zum Chat zurück. Gib deinen Buchstaben ein, tippe auf „Code prüfen“ und danach auf „Nachricht senden“.
Nächstes Kapitel: 2B

## 2B – Kombinationspille: Anwendung und Verträglichkeit

Informationsmaterial (auf dem iPad sichtbar, beim Antworten wieder aufrufbar):
- **Regelmäßige Einnahme:** Nach Einnahmeplan regelmäßig anwenden. Vergessene Tabletten können den Schutz mindern; Anwendung und Wirkprinzip sind verschiedene Kriterien.
- **Persönliche Verträglichkeit:** Übelkeit und seltene ernste Risiken (z. B. Blutgerinnsel) sind möglich. Verträglichkeit ist individuell; Fremderfahrungen erlauben keine sichere Prognose. Medizinische Eignung ärztlich klären.
- **Blutung und Regelschmerzen:** Blutung und Regelschmerzen können abnehmen; keine sichere Prognose. Starke ungeklärte Schmerzen ärztlich abklären lassen.

Bildimpuls: Welche Beobachtungen erlauben keine sichere persönliche Prognose?

**2B-Q1-AHR** – Welche Aussage erklärt, warum ein Pearl-Index allein die Zuverlässigkeit im Alltag nicht vollständig beschreibt?
- 1: Wirkprinzip und Umsetzung des Einnahmeplans sind getrennte Kriterien; Anwendungsfehler können den Schutz mindern. **(richtig)** – Studienbedingungen und tatsächliche Einnahme beeinflussen die beobachtete Verhütungssicherheit.
- 2: Die Hormone machen Anwendungsfehler bedeutungslos. **(falsch)** – Du übersiehst die Voraussetzung der regelmäßigen Einnahme.
  - Hilfe 1: Lies im Informationsmaterial: Regelmäßige Einnahme.
  - Hilfe 2: Die Hemmung des Eisprungs hängt von wirksamer Anwendung ab.
  - Hilfe 3: Was misst der Zahlenwert, und welche Bedingungen können zwischen Gruppen verschieden sein?
  - Hilfe 4: Ein Tabellenwert ersetzt keine Information über die Anwendung.
  - Hilfe 5: Passende Aussage: Wirkprinzip und Umsetzung des Einnahmeplans sind getrennte Kriterien; Anwendungsfehler können den Schutz mindern. Studienbedingungen und tatsächliche Einnahme beeinflussen die beobachtete Verhütungssicherheit.
- 3: Bei kleinerem Pearl-Index ist auch der STI-Schutz größer. **(falsch)** – Du leitest eine andere Schutzwirkung aus dem Index ab.
  - Hilfe 1: Lies im Informationsmaterial: Regelmäßige Einnahme.
  - Hilfe 2: Der Index betrifft Schwangerschaften.
  - Hilfe 3: Was misst der Zahlenwert, und welche Bedingungen können zwischen Gruppen verschieden sein?
  - Hilfe 4: Ein Tabellenwert ersetzt keine Information über die Anwendung.
  - Hilfe 5: Passende Aussage: Wirkprinzip und Umsetzung des Einnahmeplans sind getrennte Kriterien; Anwendungsfehler können den Schutz mindern. Studienbedingungen und tatsächliche Einnahme beeinflussen die beobachtete Verhütungssicherheit.
- Hilfen ohne Auswahl: Lies im Informationsmaterial: Regelmäßige Einnahme. → Vergleiche die Aussagen mit dem beschriebenen biologischen Mechanismus. → Was misst der Zahlenwert, und welche Bedingungen können zwischen Gruppen verschieden sein? → Ein Tabellenwert ersetzt keine Information über die Anwendung. → Passende Aussage: Wirkprinzip und Umsetzung des Einnahmeplans sind getrennte Kriterien; Anwendungsfehler können den Schutz mindern. Studienbedingungen und tatsächliche Einnahme beeinflussen die beobachtete Verhütungssicherheit.
- **Nach Lösungshilfe:** In einer Untersuchung wird die Pille immer nach Plan genommen; in einer anderen kommt Vergessen vor. Warum können die Werte abweichen?
  - Die Anwendungsbedingungen unterscheiden sich. (richtig) – Vergessene Einnahmen können den Schutz mindern.
  - Die Hormone bilden dann automatisch eine äußere Hülle. (falsch) – Die Wirkweise ändert sich nicht in eine Barriere. Betrachte den Einnahmeplan.
  - Pearl-Index misst die Zahl der Infektionen. (falsch) – Der Index misst Schwangerschaften, nicht STI. Trenne die Messgrößen.

**2B-Q2-AHR** – Welche Schlussfolgerung ist durch zwei unterschiedliche Erfahrungsberichte begründet?
- 1: Sie zeigen mögliche unterschiedliche Reaktionen, erlauben aber keine sichere individuelle Prognose. **(richtig)** – Eine Einzelerfahrung kann Fragen für die Beratung begründen, ersetzt aber keine individuelle medizinische Eignungsprüfung.
- 2: Ein Bericht über Übelkeit beweist eine allgemeine Unverträglichkeit. **(falsch)** – Du schließt von einer Person auf alle.
  - Hilfe 1: Lies im Informationsmaterial: Persönliche Verträglichkeit; Blutung und Regelschmerzen.
  - Hilfe 2: Betrachte die individuelle Streuung.
  - Hilfe 3: Welche Information fehlt, um auf eine weitere Person zu schließen?
  - Hilfe 4: Trenne Beobachtung, mögliche Wirkung und Prognose.
  - Hilfe 5: Passende Aussage: Sie zeigen mögliche unterschiedliche Reaktionen, erlauben aber keine sichere individuelle Prognose. Eine Einzelerfahrung kann Fragen für die Beratung begründen, ersetzt aber keine individuelle medizinische Eignungsprüfung.
- 3: Ein Bericht über schwächere Blutungen beweist, dass ungeklärte starke Schmerzen keine Abklärung brauchen. **(falsch)** – Du ersetzt die medizinische Klärung durch einen Erfahrungsbericht.
  - Hilfe 1: Lies im Informationsmaterial: Persönliche Verträglichkeit; Blutung und Regelschmerzen.
  - Hilfe 2: Die Ursache der Beschwerden bleibt eine eigene Frage.
  - Hilfe 3: Welche Information fehlt, um auf eine weitere Person zu schließen?
  - Hilfe 4: Trenne Beobachtung, mögliche Wirkung und Prognose.
  - Hilfe 5: Passende Aussage: Sie zeigen mögliche unterschiedliche Reaktionen, erlauben aber keine sichere individuelle Prognose. Eine Einzelerfahrung kann Fragen für die Beratung begründen, ersetzt aber keine individuelle medizinische Eignungsprüfung.
- Hilfen ohne Auswahl: Lies im Informationsmaterial: Persönliche Verträglichkeit; Blutung und Regelschmerzen. → Vergleiche die Aussagen mit dem beschriebenen biologischen Mechanismus. → Welche Information fehlt, um auf eine weitere Person zu schließen? → Trenne Beobachtung, mögliche Wirkung und Prognose. → Passende Aussage: Sie zeigen mögliche unterschiedliche Reaktionen, erlauben aber keine sichere individuelle Prognose. Eine Einzelerfahrung kann Fragen für die Beratung begründen, ersetzt aber keine individuelle medizinische Eignungsprüfung.
- **Nach Lösungshilfe:** Eine Person hat starke, ungeklärte Regelschmerzen. Eine Bekannte berichtet von Linderung durch die Pille. Was ist fachlich gerechtfertigt?
  - Die Linderung ist bei allen sicher. (falsch) – Ein möglicher Nutzen ist keine Garantie. Beachte individuelle Unterschiede.
  - Eine Linderung ist möglich, die Beschwerden und Eignung müssen individuell abgeklärt werden. (richtig) – Der Erfahrungsbericht klärt weder Ursache noch persönliche Verträglichkeit.
  - Die Ursache ist durch den Bericht bereits bekannt. (falsch) – Ein Fremdbericht ist keine Diagnose. Unterscheide Beobachtung und Ursache.

**Nach bestandener Prüfung – Papier:** Papier · 2B – Kombinationspille: Ergänze die Felder 3, 4 genau wie angezeigt. Vergleiche deine Einträge.
- Feld 3 (2B-3, Regelmäßige Einnahme): **mindern**
- Feld 4 (2B-4, Persönliche Verträglichkeit): **individuell**
Kein Code. Nach Vergleich „Weiter im Chat“.
Vergleich mit vollständiger Karte des eigenen Niveaus. Auf Papier „Karte kontrolliert“ markieren. Keine rückwirkende digitale Freigabe.
Nächstes Kapitel: 3A

## 3A – Kupferspirale: Kupfer und Schutzwirkung

Informationsmaterial (auf dem iPad sichtbar, beim Antworten wieder aufrufbar):
- **Kupfer und Spermien:** Kupfer beeinträchtigt Beweglichkeit und Befruchtungsfähigkeit der Spermien. Hormonfrei; Eisprung wird nicht als Wirkprinzip gehemmt.
- **Schutz vor Infektionen:** Wirkung auf Spermien bedeutet keine Barriere gegen Erreger: kein STI-Schutz.

Ergänzender kurzer Fachhinweis: Hormonfreiheit garantiert keine Beschwerdefreiheit. Blutungen und Regelschmerzen können stärker werden; die Auswirkung ist individuell. Vertiefung in 3B. Zum Vergleich: Die Kombinationspille hemmt vor allem den Eisprung.

Bildimpuls: Grenze die Kupferwirkung von Hormonwirkung und Barriere ab.

**3A-Q1-AHR** – Welche Aussage grenzt Kupferspirale und Kombinationspille korrekt voneinander ab?
- 1: Beide wirken hauptsächlich durch die Hemmung des Eisprungs. **(falsch)** – Du setzt verschiedene Mechanismen gleich.
  - Hilfe 1: Lies im Informationsmaterial: Kupfer und Spermien.
  - Hilfe 2: Vergleiche Spermien und Eizelle.
  - Hilfe 3: Welche Zelle oder welcher Vorgang ist bei jeder Methode primär betroffen?
  - Hilfe 4: Kupfer ist kein Hormon und hemmt den Eisprung nicht als Wirkprinzip.
  - Hilfe 5: Passende Aussage: Kupfer beeinträchtigt Spermien; die Kombinationspille hemmt vor allem den Eisprung. Beide erschweren Befruchtung über unterschiedliche biologische Voraussetzungen.
- 2: Beide halten Sperma außerhalb des Körpers mechanisch zurück. **(falsch)** – Du ordnest beiden eine Kondombarriere zu.
  - Hilfe 1: Lies im Informationsmaterial: Kupfer und Spermien.
  - Hilfe 2: Betrachte die räumlichen Wirkungsorte.
  - Hilfe 3: Welche Zelle oder welcher Vorgang ist bei jeder Methode primär betroffen?
  - Hilfe 4: Kupfer ist kein Hormon und hemmt den Eisprung nicht als Wirkprinzip.
  - Hilfe 5: Passende Aussage: Kupfer beeinträchtigt Spermien; die Kombinationspille hemmt vor allem den Eisprung. Beide erschweren Befruchtung über unterschiedliche biologische Voraussetzungen.
- 3: Kupfer beeinträchtigt Spermien; die Kombinationspille hemmt vor allem den Eisprung. **(richtig)** – Beide erschweren Befruchtung über unterschiedliche biologische Voraussetzungen.
- Hilfen ohne Auswahl: Lies im Informationsmaterial: Kupfer und Spermien. → Vergleiche die Aussagen mit dem beschriebenen biologischen Mechanismus. → Welche Zelle oder welcher Vorgang ist bei jeder Methode primär betroffen? → Kupfer ist kein Hormon und hemmt den Eisprung nicht als Wirkprinzip. → Passende Aussage: Kupfer beeinträchtigt Spermien; die Kombinationspille hemmt vor allem den Eisprung. Beide erschweren Befruchtung über unterschiedliche biologische Voraussetzungen.
- **Nach Lösungshilfe:** Eine Methode enthält keine Hormone und beeinträchtigt die Beweglichkeit von Spermien in der Gebärmutter. Welche passt?
  - Kombinationspille. (falsch) – Sie hemmt vor allem den Eisprung. Vergleiche die Wirkprinzipien.
  - Kondom. (falsch) – Es hält Sperma mechanisch zurück. Beachte den beschriebenen Wirkungsort.
  - Kupferspirale. (richtig) – Kupfer wirkt auf Spermien; das ist keine hormonelle Zyklushemmung.

**3A-Q2-AHR** – Welche Aussage trennt Beobachtung und Schlussfolgerung angemessen?
- 1: Da Kupfer hormonfrei ist, muss es beide Schutzziele erfüllen. **(falsch)** – Aus Hormonfreiheit folgt keine Erregerbarriere.
  - Hilfe 1: Lies im Informationsmaterial: Schutz vor Infektionen.
  - Hilfe 2: Prüfe das konkrete Wirkprinzip.
  - Hilfe 3: Welche Art von Zellen betrifft die Information und welche Schutzwirkung wird geprüft?
  - Hilfe 4: Eine Wirkung auf Spermien ist kein Befund über die Übertragung von Krankheitserregern.
  - Hilfe 5: Passende Aussage: Beeinträchtigte Spermien erklären den Schwangerschaftsschutz; die Wirkung beweist keinen STI-Schutz. Die nachgewiesene Wirkung auf eine Zellart erlaubt keine pauschale Übertragung auf Erreger.
- 2: Beeinträchtigte Spermien erklären den Schwangerschaftsschutz; die Wirkung beweist keinen STI-Schutz. **(richtig)** – Die nachgewiesene Wirkung auf eine Zellart erlaubt keine pauschale Übertragung auf Erreger.
- 3: Ein wirksames Verhütungsmittel muss Krankheitserreger zurückhalten. **(falsch)** – Du machst eine Erregerbarriere zur Voraussetzung jeder Verhütung.
  - Hilfe 1: Lies im Informationsmaterial: Schutz vor Infektionen.
  - Hilfe 2: Es gibt unterschiedliche Mechanismen gegen Schwangerschaft.
  - Hilfe 3: Welche Art von Zellen betrifft die Information und welche Schutzwirkung wird geprüft?
  - Hilfe 4: Eine Wirkung auf Spermien ist kein Befund über die Übertragung von Krankheitserregern.
  - Hilfe 5: Passende Aussage: Beeinträchtigte Spermien erklären den Schwangerschaftsschutz; die Wirkung beweist keinen STI-Schutz. Die nachgewiesene Wirkung auf eine Zellart erlaubt keine pauschale Übertragung auf Erreger.
- Hilfen ohne Auswahl: Lies im Informationsmaterial: Schutz vor Infektionen. → Vergleiche die Aussagen mit dem beschriebenen biologischen Mechanismus. → Welche Art von Zellen betrifft die Information und welche Schutzwirkung wird geprüft? → Eine Wirkung auf Spermien ist kein Befund über die Übertragung von Krankheitserregern. → Passende Aussage: Beeinträchtigte Spermien erklären den Schwangerschaftsschutz; die Wirkung beweist keinen STI-Schutz. Die nachgewiesene Wirkung auf eine Zellart erlaubt keine pauschale Übertragung auf Erreger.
- **Nach Lösungshilfe:** Eine Untersuchung zeigt, dass Kupfer die Beweglichkeit von Spermien vermindert. Was wurde damit nicht nachgewiesen?
  - Dass Spermien Zellen sind. (falsch) – Diese Aussage ist nicht das gesuchte Schutzziel. Unterscheide Befruchtung und Erregerübertragung.
  - Verminderung von STI-Übertragungen. (richtig) – Der beschriebene Befund betrifft Spermien, nicht Krankheitserreger.
  - Eine Wirkung auf Spermien. (falsch) – Genau das wurde beschrieben. Suche die nicht untersuchte Schutzwirkung.

**Nach bestandener Prüfung – Papier:** Papier · 3A – Kupferspirale: Ergänze die Felder 1, 2 genau wie angezeigt. Vergleiche deine Einträge.
- Feld 1 (3A-1, Kupfer und Spermien): **Befruchtungsfähigkeit**
- Feld 2 (3A-2, Schutz vor Infektionen): **kein STI-Schutz**

**Gedruckter Fachcheck:** Welche Aussage trennt die Wirkweise von ihren Grenzen?
Markiere die passende Aussage. Begründe in wenigen Stichwörtern. Kehre zum Chat zurück und gib den Buchstaben ein.
Erwarteter Grund: Die Wirkung auf Spermien ist keine Barriere gegen Krankheitserreger.
**3A-P-AHR** – Welche Aussage trennt die Wirkweise von ihren Grenzen?
- A: Hormonfreiheit verhindert Regelschmerzen. **(falsch)** – Du leitest Beschwerdefreiheit aus Hormonfreiheit ab.
  - Hilfe 1: Lies auf deiner Karte: Kupfer und Spermien; Schutz vor Infektionen.
  - Hilfe 2: Mögliche Auswirkungen auf Blutungen und Schmerzen sind unabhängig vom Hormonverzicht zu prüfen.
  - Hilfe 3: Welche Fähigkeit der Spermien wird beeinträchtigt?
  - Hilfe 4: Kupfer wirkt ohne Hormone auf Spermien. Daraus folgt kein STI-Schutz.
  - Hilfe 5: Passende Aussage: C – Kupfer beeinträchtigt Spermien; das ergibt keinen STI-Schutz. Die Wirkung auf Spermien ist keine Barriere gegen Krankheitserreger.
- B: Kupfer stoppt alle sexuell übertragbaren Erreger. **(falsch)** – Du verallgemeinerst eine Wirkung auf Spermien zu einem Schutz gegen alle Erreger.
  - Hilfe 1: Lies auf deiner Karte: Kupfer und Spermien; Schutz vor Infektionen.
  - Hilfe 2: Eine Wirkung auf Spermien ist kein Nachweis von STI-Schutz.
  - Hilfe 3: Welche Fähigkeit der Spermien wird beeinträchtigt?
  - Hilfe 4: Kupfer wirkt ohne Hormone auf Spermien. Daraus folgt kein STI-Schutz.
  - Hilfe 5: Passende Aussage: C – Kupfer beeinträchtigt Spermien; das ergibt keinen STI-Schutz. Die Wirkung auf Spermien ist keine Barriere gegen Krankheitserreger.
- C: Kupfer beeinträchtigt Spermien; das ergibt keinen STI-Schutz. **(richtig)** – Die markierte biologische Aussage passt. Die Wirkung auf Spermien ist keine Barriere gegen Krankheitserreger. Deine eigene Begründung auf Papier wird nicht automatisch fachlich bewertet.
- Hilfen ohne Auswahl: Lies auf deiner Karte: Kupfer und Spermien; Schutz vor Infektionen. → Prüfe, welche Aussage durch die biologische Wirkweise gedeckt ist. → Welche Fähigkeit der Spermien wird beeinträchtigt? → Kupfer wirkt ohne Hormone auf Spermien. Daraus folgt kein STI-Schutz. → Passende Aussage: C – Kupfer beeinträchtigt Spermien; das ergibt keinen STI-Schutz. Die Wirkung auf Spermien ist keine Barriere gegen Krankheitserreger.
- **Nach Lösungshilfe:** Ein Modell zeigt Spermien mit verminderter Beweglichkeit durch Kupfer. Was wird damit erklärt?
  - Ein Mechanismus gegen Befruchtung, kein STI-Schutz. (richtig) – Die Kupferwirkung betrifft Spermien und beweist keine Erregerbarriere.
  - Eine vollständige Verhinderung von STI. (falsch) – Das Modell zeigt Spermien, nicht Erregerübertragung. Grenze die Aussage ein.
  - Eine sichere Unterdrückung des Eisprungs durch Hormone. (falsch) – Kupfer ist kein Hormon. Prüfe den dargestellten Mechanismus.
Kehre zum Chat zurück. Gib deinen Buchstaben ein, tippe auf „Code prüfen“ und danach auf „Nachricht senden“.
Nächstes Kapitel: 3B

## 3B – Kupferspirale: Alltag und Einlage

Informationsmaterial (auf dem iPad sichtbar, beim Antworten wieder aufrufbar):
- **Schutz im Alltag:** Längerfristig sehr zuverlässige Wirkung ohne tägliche Einnahme; Dauer modellabhängig, Lagekontrollen in der Praxis.
- **Einsetzen und Entscheidung:** Ärztliches Einsetzen in die Gebärmutter kann schmerzhaft sein. Medizinische Eignung und freiwillige Zustimmung sind getrennt zu klären.
- **Blutung und Regelschmerzen:** Blutungen und Schmerzen können stärker werden. Hormonfreiheit garantiert keine Beschwerdefreiheit. Starke ungeklärte Schmerzen ärztlich abklären lassen.

Bildimpuls: Warum ersetzen Anwendungsvorteile keine Zustimmung oder Abklärung?

**3B-Q1-AHR** – Welche Aussage unterscheidet Anwendungsvorteil, medizinische Eignung und Zustimmung?
- 1: Die hohe Zuverlässigkeit ersetzt die Zustimmung. **(falsch)** – Du setzt eine Schutzwirkung mit der Einwilligung gleich.
  - Hilfe 1: Lies im Informationsmaterial: Schutz im Alltag; Einsetzen und Entscheidung.
  - Hilfe 2: Die Entscheidung liegt bei der betroffenen Person.
  - Hilfe 3: Ist eine medizinisch mögliche Einlage automatisch gewünscht?
  - Hilfe 4: Anwendung, Eignung und Zustimmung sind eigenständige Kriterien.
  - Hilfe 5: Passende Aussage: Die liegende Spirale benötigt keine tägliche Einnahme; Eignung und freiwillige Zustimmung müssen vor dem Einsetzen getrennt geklärt werden. Langfristiger Schutz ist eine fachliche Eigenschaft, die Entscheidung zur Einlage bleibt persönlich.
- 2: Die fehlende tägliche Einnahme beweist, dass keine Kontrollen nötig sind. **(falsch)** – Du verwechselst tägliche Anwendung mit medizinischer Betreuung.
  - Hilfe 1: Lies im Informationsmaterial: Schutz im Alltag; Einsetzen und Entscheidung.
  - Hilfe 2: Lagekontrollen sind ein anderer Vorgang.
  - Hilfe 3: Ist eine medizinisch mögliche Einlage automatisch gewünscht?
  - Hilfe 4: Anwendung, Eignung und Zustimmung sind eigenständige Kriterien.
  - Hilfe 5: Passende Aussage: Die liegende Spirale benötigt keine tägliche Einnahme; Eignung und freiwillige Zustimmung müssen vor dem Einsetzen getrennt geklärt werden. Langfristiger Schutz ist eine fachliche Eigenschaft, die Entscheidung zur Einlage bleibt persönlich.
- 3: Die liegende Spirale benötigt keine tägliche Einnahme; Eignung und freiwillige Zustimmung müssen vor dem Einsetzen getrennt geklärt werden. **(richtig)** – Langfristiger Schutz ist eine fachliche Eigenschaft, die Entscheidung zur Einlage bleibt persönlich.
- Hilfen ohne Auswahl: Lies im Informationsmaterial: Schutz im Alltag; Einsetzen und Entscheidung. → Vergleiche die Aussagen mit dem beschriebenen biologischen Mechanismus. → Ist eine medizinisch mögliche Einlage automatisch gewünscht? → Anwendung, Eignung und Zustimmung sind eigenständige Kriterien. → Passende Aussage: Die liegende Spirale benötigt keine tägliche Einnahme; Eignung und freiwillige Zustimmung müssen vor dem Einsetzen getrennt geklärt werden. Langfristiger Schutz ist eine fachliche Eigenschaft, die Entscheidung zur Einlage bleibt persönlich.
- **Nach Lösungshilfe:** Eine Person stimmt dem ärztlichen Einsetzen nicht zu, obwohl es medizinisch möglich wäre. Was folgt?
  - Weil keine Tabletten nötig sind, ist die Zustimmung unnötig. (falsch) – Die Anwendung sagt nichts über Einwilligung aus. Prüfe die Voraussetzungen für das Einsetzen.
  - Medizinische Eignung ist keine Zustimmung. (richtig) – Eine Einlage benötigt freiwillige Zustimmung.
  - Die medizinische Eignung ersetzt die persönliche Entscheidung. (falsch) – Du vermischst zwei Voraussetzungen. Trenne Eignung und Zustimmung.

**3B-Q2-AHR** – Welche Aussage ist angesichts unbekannter Ursachen starker Regelschmerzen fachlich gerechtfertigt?
- 1: Eine Verstärkung durch die Kupferspirale ist möglich; Beschwerden und Eignung müssen individuell abgeklärt werden. **(richtig)** – Der Wirkmechanismus erlaubt keine sichere Prognose für eine einzelne Person, und ungeklärte starke Beschwerden benötigen Abklärung.
- 2: Die Methode ist allein wegen möglicher Verstärkung für jede Person ausgeschlossen. **(falsch)** – Du machst aus einer Möglichkeit ein allgemeines Verbot.
  - Hilfe 1: Lies im Informationsmaterial: Blutung und Regelschmerzen; Einsetzen und Entscheidung.
  - Hilfe 2: Die Eignung ist individuell zu klären.
  - Hilfe 3: Was ist über die Ursache und die spätere individuelle Reaktion bekannt?
  - Hilfe 4: Unterscheide mögliche Wirkung, Prognose und medizinische Klärung.
  - Hilfe 5: Passende Aussage: Eine Verstärkung durch die Kupferspirale ist möglich; Beschwerden und Eignung müssen individuell abgeklärt werden. Der Wirkmechanismus erlaubt keine sichere Prognose für eine einzelne Person, und ungeklärte starke Beschwerden benötigen Abklärung.
- 3: Hormonfreiheit beweist sichere Schmerzlinderung. **(falsch)** – Eine Material- oder Wirkprinzipangabe ist kein Nachweis einer Linderung.
  - Hilfe 1: Lies im Informationsmaterial: Blutung und Regelschmerzen; Einsetzen und Entscheidung.
  - Hilfe 2: Die Karte beschreibt mögliche Zunahme von Beschwerden.
  - Hilfe 3: Was ist über die Ursache und die spätere individuelle Reaktion bekannt?
  - Hilfe 4: Unterscheide mögliche Wirkung, Prognose und medizinische Klärung.
  - Hilfe 5: Passende Aussage: Eine Verstärkung durch die Kupferspirale ist möglich; Beschwerden und Eignung müssen individuell abgeklärt werden. Der Wirkmechanismus erlaubt keine sichere Prognose für eine einzelne Person, und ungeklärte starke Beschwerden benötigen Abklärung.
- Hilfen ohne Auswahl: Lies im Informationsmaterial: Blutung und Regelschmerzen; Einsetzen und Entscheidung. → Vergleiche die Aussagen mit dem beschriebenen biologischen Mechanismus. → Was ist über die Ursache und die spätere individuelle Reaktion bekannt? → Unterscheide mögliche Wirkung, Prognose und medizinische Klärung. → Passende Aussage: Eine Verstärkung durch die Kupferspirale ist möglich; Beschwerden und Eignung müssen individuell abgeklärt werden. Der Wirkmechanismus erlaubt keine sichere Prognose für eine einzelne Person, und ungeklärte starke Beschwerden benötigen Abklärung.
- **Nach Lösungshilfe:** Eine Person hat mit der Kupferspirale keine stärkeren Schmerzen. Welche Folgerung ist zulässig?
  - Das ist möglich; andere Personen können anders reagieren. (richtig) – Mögliche Beschwerden sind nicht bei allen gleich.
  - Niemand kann dadurch stärkere Schmerzen bekommen. (falsch) – Du verallgemeinerst eine Einzelerfahrung. Trenne Möglichkeit und Garantie.
  - Starke ungeklärte Schmerzen brauchen nie Abklärung. (falsch) – Das folgt aus der Einzelerfahrung nicht. Die Ursache bleibt eine eigene Frage.

**Nach bestandener Prüfung – Papier:** Papier · 3B – Kupferspirale: Ergänze die Felder 3, 4 genau wie angezeigt. Vergleiche deine Einträge.
- Feld 3 (3B-3, Schutz im Alltag): **tägliche Einnahme**
- Feld 4 (3B-4, Blutung und Regelschmerzen): **stärker**
Kein Code. Nach Vergleich „Weiter im Chat“.
Vergleich mit vollständiger Karte des eigenen Niveaus. Auf Papier „Karte kontrolliert“ markieren. Keine rückwirkende digitale Freigabe.
Nächstes Kapitel: 4A

## 4A – Hormonspirale: Hormon und Schutzwirkung

Informationsmaterial (auf dem iPad sichtbar, beim Antworten wieder aufrufbar):
- **Hormon und Schleim am Gebärmutterhals:** Ein Gestagen macht vor allem den Schleim am Gebärmutterhals für Spermien schwer durchlässig. Andere Wirkweise als die Kombinationspille.
- **Schutz vor Infektionen:** Veränderter Schleim schützt nicht vor sexuell übertragbaren Infektionen: kein STI-Schutz.

Ergänzender kurzer Fachhinweis: Zum Vergleich: Die Kombinationspille hemmt vor allem den Eisprung. Das Modell zeigt hauptsächliche Wirkprinzipien.

Bildimpuls: Vergleiche den hauptsächlichen Wirkmechanismus mit dem der Pille und die Modellgrenze.

**4A-Q1-AHR** – Weshalb ist „beide enthalten Hormone, also wirken beide genau gleich“ keine tragfähige Erklärung für Pille und Hormonspirale?
- 1: Weil die Pille eine äußere mechanische Hülle bildet. **(falsch)** – Du beschreibst das Kondom.
  - Hilfe 1: Lies im Informationsmaterial: Hormon und Schleim am Gebärmutterhals.
  - Hilfe 2: Vergleiche die zwei inneren Wirkmechanismen.
  - Hilfe 3: Welche Struktur oder welcher Vorgang verändert sich jeweils vor allem?
  - Hilfe 4: Gemeinsame Hormonwirkung bedeutet nicht identische Wirkorte.
  - Hilfe 5: Passende Aussage: Bei der Kombinationspille steht die Hemmung des Eisprungs im Vordergrund, bei der Hormonspirale die Veränderung des Schleims. Hormonelle Methoden können unterschiedliche hauptsächliche Wirkmechanismen besitzen.
- 2: Bei der Kombinationspille steht die Hemmung des Eisprungs im Vordergrund, bei der Hormonspirale die Veränderung des Schleims. **(richtig)** – Hormonelle Methoden können unterschiedliche hauptsächliche Wirkmechanismen besitzen.
- 3: Weil die Hormonspirale keine Hormone enthält. **(falsch)** – Du verwechselst die Hormonspirale mit der Kupferspirale.
  - Hilfe 1: Lies im Informationsmaterial: Hormon und Schleim am Gebärmutterhals.
  - Hilfe 2: Lies, was die Hormonspirale abgibt.
  - Hilfe 3: Welche Struktur oder welcher Vorgang verändert sich jeweils vor allem?
  - Hilfe 4: Gemeinsame Hormonwirkung bedeutet nicht identische Wirkorte.
  - Hilfe 5: Passende Aussage: Bei der Kombinationspille steht die Hemmung des Eisprungs im Vordergrund, bei der Hormonspirale die Veränderung des Schleims. Hormonelle Methoden können unterschiedliche hauptsächliche Wirkmechanismen besitzen.
- Hilfen ohne Auswahl: Lies im Informationsmaterial: Hormon und Schleim am Gebärmutterhals. → Vergleiche die Aussagen mit dem beschriebenen biologischen Mechanismus. → Welche Struktur oder welcher Vorgang verändert sich jeweils vor allem? → Gemeinsame Hormonwirkung bedeutet nicht identische Wirkorte. → Passende Aussage: Bei der Kombinationspille steht die Hemmung des Eisprungs im Vordergrund, bei der Hormonspirale die Veränderung des Schleims. Hormonelle Methoden können unterschiedliche hauptsächliche Wirkmechanismen besitzen.
- **Nach Lösungshilfe:** Ein Modell zeigt erschwerten Spermien-Durchtritt am Gebärmutterhals durch ein Hormon. Welche Methode passt am besten?
  - Kondom. (falsch) – Die Hülle wirkt außerhalb des Körpers. Beachte die gezeigte Struktur.
  - Hormonspirale. (richtig) – Gestagen verändert vor allem den Schleim am Gebärmutterhals.
  - Kupferspirale. (falsch) – Diese wirkt durch Kupfer auf Spermien. Achte auf den Wirkstoff im Modell.

**4A-Q2-AHR** – Welche Grenze hat die Aussagekraft eines Modells zum zäheren Gebärmutterhalsschleim?
- 1: Es beweist einen vollständigen Schutz vor allen Infektionen. **(falsch)** – Du erweiterst die Aussagekraft über den dargestellten Mechanismus hinaus.
  - Hilfe 1: Lies im Informationsmaterial: Schutz vor Infektionen.
  - Hilfe 2: Suche im Modell nach einem Nachweis zur Erregerübertragung.
  - Hilfe 3: Was ist dargestellt, und welche Aussage geht darüber hinaus?
  - Hilfe 4: Ein Modell zur Schwangerschaftsverhütung ist kein Beleg für ein zweites Schutzziel.
  - Hilfe 5: Passende Aussage: Es erklärt den erschwerten Weg von Spermien, belegt aber keine Verminderung von STI-Übertragungen. Ein Modell eines bestimmten Mechanismus erklärt nur die dargestellte Wirkung; Erregerübertragung ist nicht geprüft.
- 2: Es erklärt keinerlei Beitrag zur Schwangerschaftsverhütung. **(falsch)** – Du unterschätzt die Aussage des Modells.
  - Hilfe 1: Lies im Informationsmaterial: Schutz vor Infektionen.
  - Hilfe 2: Betrachte den erschwerten Spermienweg.
  - Hilfe 3: Was ist dargestellt, und welche Aussage geht darüber hinaus?
  - Hilfe 4: Ein Modell zur Schwangerschaftsverhütung ist kein Beleg für ein zweites Schutzziel.
  - Hilfe 5: Passende Aussage: Es erklärt den erschwerten Weg von Spermien, belegt aber keine Verminderung von STI-Übertragungen. Ein Modell eines bestimmten Mechanismus erklärt nur die dargestellte Wirkung; Erregerübertragung ist nicht geprüft.
- 3: Es erklärt den erschwerten Weg von Spermien, belegt aber keine Verminderung von STI-Übertragungen. **(richtig)** – Ein Modell eines bestimmten Mechanismus erklärt nur die dargestellte Wirkung; Erregerübertragung ist nicht geprüft.
- Hilfen ohne Auswahl: Lies im Informationsmaterial: Schutz vor Infektionen. → Vergleiche die Aussagen mit dem beschriebenen biologischen Mechanismus. → Was ist dargestellt, und welche Aussage geht darüber hinaus? → Ein Modell zur Schwangerschaftsverhütung ist kein Beleg für ein zweites Schutzziel. → Passende Aussage: Es erklärt den erschwerten Weg von Spermien, belegt aber keine Verminderung von STI-Übertragungen. Ein Modell eines bestimmten Mechanismus erklärt nur die dargestellte Wirkung; Erregerübertragung ist nicht geprüft.
- **Nach Lösungshilfe:** Ein Bild zeigt weniger durch den Schleim gelangende Spermien. Welche Untersuchung wäre für STI-Schutz zusätzlich nötig?
  - Nur eine weitere Messung der Beweglichkeit von Spermien. (falsch) – Auch eine zweite Spermienmessung belegt keine Erregerübertragung. Frage nach dem anderen Schutzziel.
  - Nur der Pearl-Index. (falsch) – Der Index misst Schwangerschaften. Trenne die beiden Schutzziele.
  - Eine geeignete Untersuchung zur Übertragung von Krankheitserregern. (richtig) – Die Abbildung zeigt Spermien, keine Daten zum STI-Risiko.

**Nach bestandener Prüfung – Papier:** Papier · 4A – Hormonspirale: Ergänze die Felder 1, 2 genau wie angezeigt. Vergleiche deine Einträge.
- Feld 1 (4A-1, Hormon und Schleim am Gebärmutterhals): **schwer durchlässig**
- Feld 2 (4A-2, Schutz vor Infektionen): **kein STI-Schutz**

**Gedruckter Fachcheck:** Welche Aussage zur Hormonwirkung ist tragfähig?
Markiere die passende Aussage. Begründe in wenigen Stichwörtern. Kehre zum Chat zurück und gib den Buchstaben ein.
Erwarteter Grund: Die Hormonspirale wirkt vor allem am Gebärmutterhals; daraus folgt kein STI-Schutz.
**4A-P-AHR** – Welche Aussage zur Hormonwirkung ist tragfähig?
- A: Beide hormonellen Methoden wirken genau gleich. **(falsch)** – Du setzt hormonelle Methoden mit identischen Mechanismen gleich.
  - Hilfe 1: Lies auf deiner Karte: Hormon und Schleim am Gebärmutterhals; Schutz vor Infektionen.
  - Hilfe 2: Vergleiche Eisprunghemmung und veränderten Schleim.
  - Hilfe 3: Welche Struktur verändert das Gestagen?
  - Hilfe 4: Der Schleim wird schwerer durchlässig für Spermien; das belegt keinen STI-Schutz.
  - Hilfe 5: Passende Aussage: B – Gestagen erschwert Spermien den Weg durch den Schleim. Die Hormonspirale wirkt vor allem am Gebärmutterhals; daraus folgt kein STI-Schutz.
- B: Gestagen erschwert Spermien den Weg durch den Schleim. **(richtig)** – Die markierte biologische Aussage passt. Die Hormonspirale wirkt vor allem am Gebärmutterhals; daraus folgt kein STI-Schutz. Deine eigene Begründung auf Papier wird nicht automatisch fachlich bewertet.
- C: Zäher Schleim verhindert die Übertragung aller STI. **(falsch)** – Du überträgst die Spermienwirkung auf alle Erreger.
  - Hilfe 1: Lies auf deiner Karte: Hormon und Schleim am Gebärmutterhals; Schutz vor Infektionen.
  - Hilfe 2: Zäher Schleim belegt keinen STI-Schutz.
  - Hilfe 3: Welche Struktur verändert das Gestagen?
  - Hilfe 4: Der Schleim wird schwerer durchlässig für Spermien; das belegt keinen STI-Schutz.
  - Hilfe 5: Passende Aussage: B – Gestagen erschwert Spermien den Weg durch den Schleim. Die Hormonspirale wirkt vor allem am Gebärmutterhals; daraus folgt kein STI-Schutz.
- Hilfen ohne Auswahl: Lies auf deiner Karte: Hormon und Schleim am Gebärmutterhals; Schutz vor Infektionen. → Prüfe, welche Aussage durch die biologische Wirkweise gedeckt ist. → Welche Struktur verändert das Gestagen? → Der Schleim wird schwerer durchlässig für Spermien; das belegt keinen STI-Schutz. → Passende Aussage: B – Gestagen erschwert Spermien den Weg durch den Schleim. Die Hormonspirale wirkt vor allem am Gebärmutterhals; daraus folgt kein STI-Schutz.
- **Nach Lösungshilfe:** In einem Modell verändert Gestagen den Schleim am Gebärmutterhals. Welche Aussage passt?
  - Der Gebärmutterhals ist ein vollständig dichter Verschluss für alle Erreger. (falsch) – Der Schleim wird schwerer durchlässig, nicht als vollständiger Verschluss dargestellt. Unterscheide Erschweren und Verhindern.
  - Die Hormonspirale enthält als Wirkstoff nur Kupfer. (falsch) – Das ist die andere Spiralenart. Beachte den Wirkstoff im Modell.
  - Spermien können schwerer hindurchgelangen; STI-Schutz ist dadurch nicht belegt. (richtig) – Das Modell betrifft den Spermienweg, nicht den Schutz vor Infektionen.
Kehre zum Chat zurück. Gib deinen Buchstaben ein, tippe auf „Code prüfen“ und danach auf „Nachricht senden“.
Nächstes Kapitel: 4B

## 4B – Hormonspirale: Alltag und Einlage

Informationsmaterial (auf dem iPad sichtbar, beim Antworten wieder aufrufbar):
- **Schutz im Alltag:** Längerfristige Hormonabgabe, sehr zuverlässiger Schutz ohne tägliche Einnahme; Lagekontrollen in der Praxis.
- **Einsetzen und Entscheidung:** Ärztliches Einsetzen in die Gebärmutter kann schmerzhaft sein. Medizinische Eignung und freiwillige Zustimmung sind getrennt zu klären.
- **Blutung und Regelschmerzen:** Blutungen können zunächst unregelmäßig sein, später können Blutung und Schmerzen abnehmen. Keine sichere Linderung. Starke ungeklärte Schmerzen ärztlich abklären lassen.

Ergänzender kurzer Fachhinweis: Zum Vergleich: Mit Kupfer können Blutungen und Regelschmerzen stärker werden. Die Kombinationspille wird regelmäßig nach Einnahmeplan genommen.

Bildimpuls: Trenne mögliche Linderung, individuelle Eignung und persönliche Zustimmung.

**4B-Q1-AHR** – Welche Schlussfolgerung zur langfristigen Hormonabgabe ist tragfähig?
- 1: Weil sie Hormone enthält, gelten dieselben täglichen Einnahmeregeln wie bei der Pille. **(falsch)** – Du überträgst eine Anwendungsform auf eine andere.
  - Hilfe 1: Lies im Informationsmaterial: Schutz im Alltag; Einsetzen und Entscheidung.
  - Hilfe 2: Das Hormon wird aus der liegenden Spirale abgegeben.
  - Hilfe 3: Was gilt vor dem Einsetzen, was danach?
  - Hilfe 4: Langfristige Abgabe ist eine Eigenschaft der Anwendung und kein Nachweis individueller Eignung.
  - Hilfe 5: Passende Aussage: Tägliche Einnahme entfällt, aber medizinische Eignung, freiwillige Zustimmung und Kontrollen bleiben erforderlich. Geringer täglicher Anwendungsaufwand ersetzt keine individuellen Voraussetzungen oder Betreuung.
- 2: Tägliche Einnahme entfällt, aber medizinische Eignung, freiwillige Zustimmung und Kontrollen bleiben erforderlich. **(richtig)** – Geringer täglicher Anwendungsaufwand ersetzt keine individuellen Voraussetzungen oder Betreuung.
- 3: Langfristige Hormonabgabe beweist, dass die Methode zu jeder Person passt. **(falsch)** – Du verallgemeinerst die technische Anwendungseigenschaft.
  - Hilfe 1: Lies im Informationsmaterial: Schutz im Alltag; Einsetzen und Entscheidung.
  - Hilfe 2: Die Eignung muss individuell geprüft werden.
  - Hilfe 3: Was gilt vor dem Einsetzen, was danach?
  - Hilfe 4: Langfristige Abgabe ist eine Eigenschaft der Anwendung und kein Nachweis individueller Eignung.
  - Hilfe 5: Passende Aussage: Tägliche Einnahme entfällt, aber medizinische Eignung, freiwillige Zustimmung und Kontrollen bleiben erforderlich. Geringer täglicher Anwendungsaufwand ersetzt keine individuellen Voraussetzungen oder Betreuung.
- Hilfen ohne Auswahl: Lies im Informationsmaterial: Schutz im Alltag; Einsetzen und Entscheidung. → Vergleiche die Aussagen mit dem beschriebenen biologischen Mechanismus. → Was gilt vor dem Einsetzen, was danach? → Langfristige Abgabe ist eine Eigenschaft der Anwendung und kein Nachweis individueller Eignung. → Passende Aussage: Tägliche Einnahme entfällt, aber medizinische Eignung, freiwillige Zustimmung und Kontrollen bleiben erforderlich. Geringer täglicher Anwendungsaufwand ersetzt keine individuellen Voraussetzungen oder Betreuung.
- **Nach Lösungshilfe:** Eine Hormonspirale liegt bereits korrekt. Welche Aussage über den Alltag passt?
  - Keine tägliche Tablette; Lagekontrollen bleiben sinnvoll bzw. vorgesehen. (richtig) – Die langfristige Abgabe ersetzt tägliche Einnahme, nicht medizinische Betreuung.
  - Täglich muss eine weitere Hormonspirale eingelegt werden. (falsch) – Sie ist eine Langzeitmethode. Prüfe die Anwendungsform.
  - Die Lage ist ab dann grundsätzlich unwichtig. (falsch) – Der korrekte Sitz gehört zu den Voraussetzungen. Kontrollen sind nicht dasselbe wie tägliche Einnahme.

**4B-Q2-AHR** – Welche Aussage wahrt die Grenzen der Information zur möglichen Schmerzlinderung?
- 1: Blutungen und Schmerzen können nachlassen; weder die individuelle Wirkung noch die Eignung und Zustimmung zur Einlage sind damit geklärt. **(richtig)** – Mögliche Linderung ist ein fachlicher Gesichtspunkt, keine Garantie und kein Ersatz für Abklärung oder Zustimmung.
- 2: Die mögliche Linderung macht die Einlage unabhängig von der Zustimmung notwendig. **(falsch)** – Du leitest eine Verpflichtung aus einem möglichen Nutzen ab.
  - Hilfe 1: Lies im Informationsmaterial: Blutung und Regelschmerzen; Einsetzen und Entscheidung.
  - Hilfe 2: Persönliche Zustimmung ist eigenständig.
  - Hilfe 3: Welche Informationen fehlen für eine individuelle Prognose?
  - Hilfe 4: Unterscheide mögliche Wirkung, medizinische Eignung und persönliche Entscheidung.
  - Hilfe 5: Passende Aussage: Blutungen und Schmerzen können nachlassen; weder die individuelle Wirkung noch die Eignung und Zustimmung zur Einlage sind damit geklärt. Mögliche Linderung ist ein fachlicher Gesichtspunkt, keine Garantie und kein Ersatz für Abklärung oder Zustimmung.
- 3: Jede Person hat nach dem Einsetzen garantiert weniger Schmerzen. **(falsch)** – Du machst eine sichere Prognose ohne individuelle Daten.
  - Hilfe 1: Lies im Informationsmaterial: Blutung und Regelschmerzen; Einsetzen und Entscheidung.
  - Hilfe 2: Beachte die Formulierung „können“.
  - Hilfe 3: Welche Informationen fehlen für eine individuelle Prognose?
  - Hilfe 4: Unterscheide mögliche Wirkung, medizinische Eignung und persönliche Entscheidung.
  - Hilfe 5: Passende Aussage: Blutungen und Schmerzen können nachlassen; weder die individuelle Wirkung noch die Eignung und Zustimmung zur Einlage sind damit geklärt. Mögliche Linderung ist ein fachlicher Gesichtspunkt, keine Garantie und kein Ersatz für Abklärung oder Zustimmung.
- Hilfen ohne Auswahl: Lies im Informationsmaterial: Blutung und Regelschmerzen; Einsetzen und Entscheidung. → Vergleiche die Aussagen mit dem beschriebenen biologischen Mechanismus. → Welche Informationen fehlen für eine individuelle Prognose? → Unterscheide mögliche Wirkung, medizinische Eignung und persönliche Entscheidung. → Passende Aussage: Blutungen und Schmerzen können nachlassen; weder die individuelle Wirkung noch die Eignung und Zustimmung zur Einlage sind damit geklärt. Mögliche Linderung ist ein fachlicher Gesichtspunkt, keine Garantie und kein Ersatz für Abklärung oder Zustimmung.
- **Nach Lösungshilfe:** Eine Person berichtet über eine Linderung der Schmerzen durch eine Hormonspirale. Was lässt sich auf andere übertragen?
  - Die Zustimmung zur Einlage ist deshalb unwichtig. (falsch) – Ein möglicher Nutzen ersetzt keine Zustimmung. Die Entscheidung bleibt bei der Person.
  - Eine Linderung ist möglich, nicht garantiert; die individuelle Eignung bleibt zu klären. (richtig) – Eine Einzelerfahrung stützt eine Möglichkeit, keine sichere Prognose.
  - Eine Linderung ist bei allen sicher. (falsch) – Du verallgemeinerst die Einzelerfahrung. Trenne Möglichkeit und Gewissheit.

**Nach bestandener Prüfung – Papier:** Papier · 4B – Hormonspirale: Ergänze die Felder 3, 4 genau wie angezeigt. Vergleiche deine Einträge.
- Feld 3 (4B-3, Schutz im Alltag): **tägliche Einnahme**
- Feld 4 (4B-4, Blutung und Regelschmerzen): **abnehmen**
Kein Code. Nach Vergleich „Weiter im Chat“.
Vergleich mit vollständiger Karte des eigenen Niveaus. Auf Papier „Karte kontrolliert“ markieren. Keine rückwirkende digitale Freigabe.
Nächstes Kapitel: Abschluss; Karten vollständig prüfen.
